package tse.JavaBienEtToi.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import org.opencv.core.Point;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.SwingWorker;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.opencv.core.Mat;

import tse.JavaBienEtToi.gui.utils.FileChooser;
import tse.JavaBienEtToi.gui.utils.ImagePanel;
import tse.JavaBienEtToi.gui.utils.Jlabelmouse;
import tse.JavaBienEtToi.gui.utils.StretchIcon;
import tse.JavaBienEtToi.image.Image;
import tse.JavaBienEtToi.processing.Parameters;
import tse.JavaBienEtToi.processing.VideoProcessingData;
import tse.JavaBienEtToi.save.Load;
import tse.JavaBienEtToi.save.Save;
import tse.JavaBienEtToi.statistics.Statistic;
import tse.JavaBienEtToi.video.PlayPause;
import tse.JavaBienEtToi.video.Video;

/**
 * The main window. Display the video and handles most user interactions.
 * 
 * @author RaphaelChevasson
 * @author Terenui Rouby
 * @author Baptiste Wolff
 * 
 *         TODO : code using displayImage(Mat i) -> use displayImage(int n) and
 *         displayImage()
 */
public class GUI extends JFrame implements ActionListener, ChangeListener {
	/**
	 * Boolean used to allow the access to UI elements
	 */
	private boolean displayDevMode = true;// Decide de l'affichage ou non du mode developpeur
	private boolean displayStat = false;
	private boolean isVideoLoaded = false;// Decide de l'affichage ou non des boutons utilisables uniquement lorsque la video est chargé
	/**
	 * Video
	 */
	private PlayPause playPause;
	private Video video;
	/**
	 * Interest Zones
	 */
	private Statistic stat = new Statistic(0, 0);
	/**
	 * Processing
	 */
	private Parameters param = new Parameters();
	private VideoProcessingData videoProcessing = new VideoProcessingData();

	/**
	 *  UI elements 
	 */
	JFrame window = new JFrame();
	JPanel mainPanel, toolsPanel, devPanel;
	private JPanel videoPanel;
	JPanel videoNavSliderPanel;
	JPanel videoNavButtonsPanel;
	ImagePanel imagePanel;
	/**
	 * Detections tools buttons
	 */
	JButton displayInterestZones, startDetection, stopDetection,createInterestZone, resetInterestZones;
	/**
	 * Navigation buttons
	 */
	JButton nextFrame, previousFrame, pauseVideo, lastFrame, firstFrame;
	/**
	 * Stat and Dev buttons
	 */
	JButton processStatistics, openDevModeWindow;
	JLabel timeLabel;
	JSlider timeSlider;
	Jlabelmouse displayedImageLabel = new Jlabelmouse(this);
	/**
	 * File choosing mecanism
	 */
	JFileChooser fichier = new JFileChooser();
	/**
	 * Save buttons
	 */
	private JButton button_saveImage, button_saveInterestZones;
	/**
	 * Load buttons
	 */
	private JButton button_loadInterestZones,loadVideo, loadExempleVideo;

	/**
	 * create the GUI object and the main app window
	 */
	/**
	 * Define the different Colors used for the Background of the Buttons
	 */
	/**
	 * Button of the left panel and that can be used
	 */
	private Color c1 = Color.decode("#006699");
	/**
	 * Button of the navigation Panel
	 */
	private Color c2 = Color.decode("#FF6666");
	/**
	 * Button of the left panel and that cannot be used
	 */
	private Color c3=	Color.decode("#778899");
	/**
	 * Background of the left panel and of the waiting panel
	 */
	private Color c4=Color.decode("#3399CC");
	
	public GUI() {
		//// Video
		window.setIconImage(new ImageIcon("JavaBienEtToilogo.png").getImage());
		playPause = new PlayPause(this);
		// see https://docs.oracle.com/javase/tutorial/uiswing/components/panel.html
		//// UI elements
		// main panel
		mainPanel = new JPanel(new BorderLayout());
		window.add(mainPanel);

		// tools panel
		JPanel leftPanel = new JPanel(new BorderLayout());
		mainPanel.add(leftPanel, BorderLayout.WEST);
		toolsPanel = new JPanel(new GridLayout(0, 1, 0, 1)); // (rox, col, HGap, VGap)
																// here, we layout vertically
		imagePanel = new ImagePanel();
		leftPanel.add(imagePanel, BorderLayout.NORTH);
		// verticalement
		leftPanel.add(toolsPanel, BorderLayout.CENTER);
		toolsPanel.add(addLabel("Charger", 20, 2));
		loadVideo = addBouton("Ouvrir une vidéo", toolsPanel, c1);
		loadExempleVideo = addBouton("Utiliser la vidéo d'exemple", toolsPanel, c1);

		// Load
		button_loadInterestZones = addBouton("Charger des zones d'interêt", toolsPanel, c3);
		button_loadInterestZones.setEnabled(false);//disable while the video is not loaded
		// Save
		toolsPanel.add(addLabel("Sauvegarder", 20, 2));
		button_saveImage = addBouton("Sauvegarder l'image actuelle", toolsPanel, c3);
		button_saveImage.setEnabled(false);//disable while the video is not loaded
		button_saveInterestZones = addBouton("Sauvegarder les zones d'intérêt", toolsPanel, c3);
		button_saveInterestZones.setEnabled(false);//disable while the video is not loaded
		// Calcul Statistique
		toolsPanel.add(addLabel("CalculStatistique", 20, 2));
		processStatistics = addBouton("Calcul Statistique", toolsPanel, c3);
		processStatistics.setEnabled(false);//disable while the video is not loaded
		toolsPanel.add(addLabel("Zone d'Interet", 20, 2));
		displayInterestZones = addBouton("Afficher les zones d'intérêt", toolsPanel, c3);
		displayInterestZones.setEnabled(false);//disable while the video is not loaded
		createInterestZone = addBouton("Nouvelle zone d'intérêt", toolsPanel, c3);
		createInterestZone.setEnabled(false);//disable while the video is not loaded
		// creerZoneInteret.setIcon(new ImageIcon("new.png"));//icone google design
		resetInterestZones = addBouton("Supprimer les zones d'intérêt", toolsPanel, c3);
		resetInterestZones.setEnabled(false);//disable while the video is not loaded
		// resetZoneInteret.setIcon(new ImageIcon("del.png"));
		toolsPanel.add(addLabel("Detection", 20, 2));
		startDetection = addBouton("Détection de personnes", toolsPanel, c3);
		startDetection.setEnabled(false);//disable while the video is not loaded
		stopDetection = addBouton("Arréter la detection", toolsPanel, c3);
		stopDetection.setEnabled(false);//disable if the Detection didn't start

		// dev panel (below tools)
		if (displayDevMode) {
			devPanel = new JPanel(new GridLayout(0, 1, 0, 1)); // (rox, col, HGap, VGap) le tout sera ordonné //
																// verticalement
			leftPanel.add(devPanel, BorderLayout.SOUTH);
			devPanel.add(addLabel("Mode developpeur", 20, 2));
			openDevModeWindow = addBouton("Regler la détection", devPanel, c1);
		} else {
			devPanel = new JPanel();
			openDevModeWindow = new JButton();
		}
		// color
		leftPanel.setBackground(Color.white);
		toolsPanel.setBackground(c4);
		devPanel.setBackground(c4);

		// video panel
		videoPanel = new JPanel(new BorderLayout());
		mainPanel.add(getVideoPanel(), BorderLayout.CENTER);
		videoPanel.add(displayedImageLabel, BorderLayout.CENTER);
		// videoPanel.setBackground(Color.decode("#BBF136"));
		// video navigation panel
		JPanel videoNavPanel = new JPanel(new GridLayout(0, 1)); // le tout sera ordonné verticalement
		getVideoPanel().add(videoNavPanel, BorderLayout.SOUTH);
		// buttons
		videoNavButtonsPanel = new JPanel();
		videoNavPanel.add(videoNavButtonsPanel);
		// Bouton de Navigation de la vidéo dont les boutons sont des images provenant
		// de google design
		firstFrame = addBouton(videoNavButtonsPanel, c2);
		firstFrame.setIcon(new ImageIcon("reset.png"));
		previousFrame = addBouton(videoNavButtonsPanel, c2);
		previousFrame.setIcon(new ImageIcon("fastrewind.png"));
		pauseVideo = addBouton(videoNavButtonsPanel, c2);
		pauseVideo.setIcon(new ImageIcon("play.png"));
		nextFrame = addBouton(videoNavButtonsPanel, c2);
		nextFrame.setIcon(new ImageIcon("fastforward.png"));
		lastFrame = addBouton(videoNavButtonsPanel, c2);
		lastFrame.setIcon(new ImageIcon("lastframe.png"));
		timeLabel = new JLabel();
		videoNavButtonsPanel.add(timeLabel, BorderLayout.EAST);
		// time slider
		videoNavSliderPanel = new JPanel(new BorderLayout());
		videoNavPanel.add(videoNavSliderPanel);
		int initialValue = 0;
		timeSlider = new JSlider(JSlider.HORIZONTAL, 0, 50, initialValue);
		videoNavSliderPanel.add(timeSlider, BorderLayout.CENTER);
		timeSlider.addChangeListener(this);
		timeSlider.setEnabled(false); // disables while video is not loaded
		videoNavSliderPanel.setVisible(false);// disables while video is not loaded
		videoNavButtonsPanel.setVisible(false);// disables while video is not loaded
		// // color
		// videoNavButtonsPanel.setBackground(Color.decode("#FF0000"));
		// timeSlider.setBackground(Color.decode("#FF0000"));

		// fenetre
		// On utilise Graphics Environment pour pouvoir adapter la taille des fenetre en
		// fonction des écrans
		// get local graphics environment
		GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
		// get maximum window bounds
		Rectangle maximumWindowBounds = graphicsEnvironment.getMaximumWindowBounds();
		window.setTitle("Détection de personnes");
		window.setLocation(0, 0);// Set the location of the window on the left of the screen
		window.setSize((int) Math.round(maximumWindowBounds.getWidth() * 0.7),
				(int) Math.round(maximumWindowBounds.getHeight()));
		// fenetre.setLocationRelativeTo(null); // centrer la fenêtre
		// fenetre.setUndecorated(true); // masquer les contours et les boutons de
		// contrôle
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setVisible(true);
	}

	/**
	 * adds and return a button with given text to the given JPanel. If button is
	 * already declared, you have to erase it with the return value - ex : b =
	 * addBouton("foo", panel,Color.Blue).
	 * 
	 * @param text
	 *            text contained by the button
	 * @param parent
	 *            the JPanel containing the button
	 * @param c
	 *            the color you want for the background of the button
	 * @return the created button
	 */
	private JButton addBouton(String texte, JPanel parent, Color c) {
		JButton b = new JButton(texte); // create button
		Font f=new Font(Font.DIALOG, Font.PLAIN, 15);
		b.setFont(f);
		b.setBackground(c);
		b.setForeground(Color.white);
		b.setBorder(BorderFactory.createRaisedBevelBorder());
		parent.add(b); // add it to the GUI parent object
		b.addActionListener(this); // listen to its events
		return (b);
	}

	/**
	 * Enable all the button that are disable while the video is not loaded if the video is loaded
	 */
	private void enable_videoLoaded() {
		isVideoLoaded=true;
		button_loadInterestZones.setEnabled(isVideoLoaded);
		button_saveImage.setEnabled(isVideoLoaded);
		button_saveInterestZones.setEnabled(isVideoLoaded);
		processStatistics.setEnabled(isVideoLoaded);
		displayInterestZones.setEnabled(isVideoLoaded);
		createInterestZone.setEnabled(isVideoLoaded);
		resetInterestZones.setEnabled(isVideoLoaded);
		startDetection.setEnabled(isVideoLoaded);
		button_loadInterestZones.setBackground(c1);
		button_saveImage.setBackground(c1);
		button_saveInterestZones.setBackground(c1);
		processStatistics.setBackground(c1);
		displayInterestZones.setBackground(c1);;
		createInterestZone.setBackground(c1);;
		resetInterestZones.setBackground(c1);;
		startDetection.setBackground(c1);;
	}
	/**
	 * adds a button without text to the JPanel "parent" it will be used when the
	 * button will get a google design for example. If button is already declared,
	 * you have to erase it with the return value - ex : b = addBouton(
	 * panel,Color.Blue).
	 *
	 * @param parent
	 * @param c
	 *            the color you want for the background of the button
	 * @return button
	 */
	private JButton addBouton(JPanel parent, Color c) {
		JButton b = new JButton(); // create button
		b.setBackground(c);
		b.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
		parent.add(b); // add it to the GUI parent object
		b.addActionListener(this); // listen to its events
		return (b);
	}

	/**
	 * when a button is clicked
	 */
	public void actionPerformed(ActionEvent e) {
		// tools :
		if (e.getSource().equals(loadVideo)) {
			String file = FileChooser.getpath(window);
			if (file != "") {
				videoProcessing.getPersons().clear();
				// stat.getInterestAreas().clear();
				loadVideo(file);
				timeLabel.setText(video.time());
				displayImage(0);
			}
		}
		if (e.getSource().equals(loadExempleVideo)) {
			loadVideo("test.avi");
		}

		if (e.getSource().equals(displayInterestZones)) {
			displayStat = !displayStat;
			displayImage(video.nImg());
		}
		if (e.getSource().equals(createInterestZone)) {
			pauseVideo();
			displayedImageLabel.activateClicking();
			stat.updateInterestAreas(videoProcessing);
		}
		if (e.getSource().equals(resetInterestZones)) {
			displayedImageLabel.supressInterestArea();
			displayImage(video.nImg());
		}
		if (e.getSource().equals(openDevModeWindow)) {
			DevMode devMode = new DevMode(param);
			devMode.setVisible(true);
			devMode.setLocation(1000, 200);
		}
		// navigation :
		if (e.getSource().equals(pauseVideo)) {
			playPauseVideo();
		}
		if (e.getSource().equals(nextFrame)) {
			pauseVideo();
			if (video.hasNext()) {
				displayImage(video.getNextMat());
			}
		}
		if (e.getSource().equals(previousFrame)) {
			pauseVideo();
			if (video.hasPrev()) {
				displayImage(video.getMat(video.nImg() - 1));
			}
		}
		if (e.getSource().equals(processStatistics)) {
			stat.processStats(videoProcessing);
			stat.showGraphique(stat.getListChartNbPpl().size() - 1);
		}
		if (e.getSource().equals(firstFrame)) {
			pauseVideo();
			displayImage(video.getMat(0));
		}
		if (e.getSource().equals(lastFrame)) {
			pauseVideo();
			displayImage(video.getMat(video.size() - 1));
		}

		// Save
		if (e.getSource().equals(button_saveImage)) {
			pauseVideo();
			BufferedImage image = Image.Mat2bufferedImage(video.getMat(video.nImg()));
			Save.image(image, window);
		}
		if (e.getSource().equals(button_saveInterestZones)) {
			pauseVideo();
			Save.interestArea(stat.getInterestAreas(), window);
		}

		// Load
		if (e.getSource().equals(button_loadInterestZones)) {
			pauseVideo();
			stat.setInterestAreas(Load.interestsArea(window));
			displayStat = true;
			displayImage(video.nImg());
		}

		// Detection
		if (e.getSource().equals(startDetection)) { // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
			startDetection.setEnabled(false);
			startDetection.setBackground(c3);/* To launch another Detection you must first stop the Detection*/
			stopDetection.setEnabled(true);
			stopDetection.setBackground(c1);
			final JDialog loading = new JDialog(window);
			JPanel p1 = new JPanel(new BorderLayout());
			JLabel waiting=new JLabel("Veuillez patienter...");
			waiting.setForeground(Color.white);
			Font f=new Font(Font.DIALOG, Font.PLAIN, 30);
			waiting.setFont(f);
			p1.add(waiting, BorderLayout.CENTER);
			loading.setUndecorated(true);
			p1.setBackground(c4);
			loading.getContentPane().add(p1);
			loading.pack();
			// On utilise Graphics Environment pour pouvoir adapter la taille des fenetre en
			// fonction des écrans
			// get local graphics environment
			GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
			// get maximum window bounds
			Rectangle maximumWindowBounds = graphicsEnvironment.getMaximumWindowBounds();
			loading.setSize((int) Math.round(maximumWindowBounds.getWidth() * 0.2),
				(int) Math.round(maximumWindowBounds.getHeight()*0.2));
			loading.setLocationRelativeTo(window);
			loading.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
			loading.setModal(true);

			SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
				@Override
				protected Void doInBackground() {
					videoProcessing.runProcessing(param, video, 0, 1000);// video.size() - 1);
					return null;
				}

				@Override
				protected void done() {
					loading.dispose();
					startDetection.setEnabled(true);
					startDetection.setBackground(c1);
					stopDetection.setEnabled(false);
					stopDetection.setBackground(c3);

				}
			};
			worker.execute();
			loading.setVisible(true);
			/*
			 * try { worker.get(); } catch (Exception e1) { e1.printStackTrace(); }
			 */

			stat.updateInterestAreas(videoProcessing);
			refreshImage();
		}
		if (e.getSource().equals(stopDetection)) {
			startDetection.setEnabled(true);
			startDetection.setBackground(c1);//Reactivation of start Detection
			stopDetection.setEnabled(false);
			stopDetection.setBackground(c3);//Desactivation of start Detection
			refreshImage();
		}

	}

	public void stateChanged(ChangeEvent e) {
		if (!isNextFrameNumber(timeSlider.getValue() + 1))
			pauseVideo();
		if (e.getSource().equals(timeSlider) && !playPause.isPlaying()) {
			displayImage(video.getMat(timeSlider.getValue()));
		}
	}

	private void loadVideo(String chemin) {
		video = new Video(chemin);
		playPause.setVideo(video);
		displayedImageLabel.supressInterestArea();
		if (!video.isOpened()) {
			System.out.println(
					"Echec de l'ouverture de la video.\nAvez-vous suivi toutes les instructions au-dessus du main ?");
			return;
		}

		displayImage(video.getMat(0));
		enable_videoLoaded();
		timeSlider.setValue(0);
		timeSlider.setMinimum(0);
		timeSlider.setMaximum(video.size() - 1);
		timeSlider.setEnabled(true);
		videoNavSliderPanel.setVisible(true);
		videoNavButtonsPanel.setVisible(true);
	}

	private void pauseVideo() {

		if (playPause.isPlaying()) {
			playPause.toggle();
			pauseVideo.setIcon(new ImageIcon("play.png"));
		}
	}

	private void resumeVideo() {
		if (!playPause.isPlaying()) {
			playPause.toggle();
			pauseVideo.setIcon(new ImageIcon("pause.png"));
		}
	}

	private void playPauseVideo() {
		playPause.toggle();
		if (playPause.isPlaying()) {
			pauseVideo.setIcon(new ImageIcon("pause.png"));
		} else {
			pauseVideo.setIcon(new ImageIcon("play.png"));
		}
	}

	/**
	 * Displays an image into the GUI. Draws also the square representing the people
	 * detected or the interest areas
	 * 
	 * @param image
	 */
	private void displayImage(Mat image) { // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		if (image.width() == 0) {
			return;
		}
		timeLabel.setFont(new Font(Font.DIALOG, Font.PLAIN, 25));
		timeLabel.setText(video.time());

		Image.drawTraitement(image, videoProcessing.getPersons().get(video.nImg()));

		if (displayStat) {
			Image.drawStatistique(image, stat, video.nImg());
		}

		BufferedImage bi = Image.Mat2bufferedImage(image);
		displayedImageLabel.setIcon(new StretchIcon(bi));
		// videoPanel.repaint();
		// window.validate();

		timeSlider.setValue(video.nImg());
	}

	/**
	 * Returns true if n == (video's image number) + 1
	 * 
	 * @param n
	 * @return
	 */
	private boolean isNextFrameNumber(int n) {
		return (video.nImg() + 1 == n);
	}

	/**
	 * Displays the image number n in the GUI
	 * 
	 * @param n
	 */
	public void displayImage(int n) {
		displayImage(video.getMat(n));
	}

	/**
	 * Displays the next image of the video.
	 */
	public void displayNextImage() {
		displayImage(video.getNextMat());
	}

	/**
	 * Refresh the current displayed image.
	 */
	public void refreshImage() {
		displayImage(video.nImg());
	}

	public Video getVideo() {
		return video;
	}

	/**
	 * JDialog to confirm the creation of an interest area
	 */
	public void confirmchoice() {
		JDialog.setDefaultLookAndFeelDecorated(true);
		int response = JOptionPane.showConfirmDialog(null, "Voulez-vous créer cette zone d'interet?", "Confirmer",
				JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		if (response == JOptionPane.YES_OPTION) {

		} else if (response == JOptionPane.CLOSED_OPTION || response == JOptionPane.NO_OPTION) {
			displayedImageLabel.destroylastIZ();
		}

	}

	// Statistics
	public Statistic getStat() {
		return stat;
	}

	public void setStat(Statistic stat) {
		this.stat = stat;
	}

	public void setDisplayStat(boolean displayStat) {
		this.displayStat = displayStat;
	}

	/**
	 * Fonction to add a Jlabel of given font, font size and font type
	 * 
	 * @param name
	 *            the text to displayed
	 * @param size
	 *            the font size
	 * @param type
	 *            the font type
	 * 
	 * @author Terenui Rouby
	 */
	public JLabel addLabel(String name, int size, int type) {
		JLabel b = new JLabel(name, JLabel.CENTER);
		b.setFont(new Font(Font.DIALOG, type, size));
		return (b);
	}

	public JPanel getVideoPanel() {
		return videoPanel;
	}

}
