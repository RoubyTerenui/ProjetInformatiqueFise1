package tse.JavaBienEtToi.gui.utils;

import java.io.File;

import javax.swing.filechooser.FileFilter;
/**
 * Class used by the FileChooser to put restriction on the type of video the user is allowed to chose
 * 
 *
 * @author Rouby Terenui
 */

public class VideoFilter extends FileFilter {
	/**
	 * Define which type of file is displayed on the FileChooser
	 * @param f
	 */
	public boolean accept(File f) {
	    if (f.isDirectory()) {
	        return true;
	    }

	    String extension =getExtension(f);
	    if (extension != null) {
	        if (extension.equals("MP4") ||
	            extension.equals("mp4") ||
	            extension.equals("mpeg") ||
	            extension.equals("MPEG") ||
	            extension.equals("M4V") ||
	            extension.equals("m4V") ||
	            extension.equals("MKV") ||
	            extension.equals("mkv") ||
	            extension.equals("avi") ||
	            extension.equals("AVI") ||
	            extension.equals("FLV") ||
	            extension.equals("flv") ||
	            extension.equals("webm") ||
	            extension.equals("WEBM") ||
	            extension.equals("MOV") ||
	            extension.equals("mov") ||
	            extension.equals("wmv") ||
	            extension.equals("WMV")) {
	                return true;
	        } else {
	            return false;
	        }
	    }

	    return false;
	}
	/**
	 * Display in the fileChooser the extension of files
	 * @param f
	 */
	private static String getExtension(File f) {
        String ext = null;
        String s = f.getName();
        int i = s.lastIndexOf('.');

        if (i > 0 &&  i < s.length() - 1) {
            ext = s.substring(i+1).toLowerCase();
        }
        return ext;
    }
	/**
	 * Display which kind of file are acctepted by the fileChooser
	 */
	@Override
	public String getDescription() {
		return("MP4 MPEG AVI M4V FLV WMV MKV MOV WEBM");
	}
	

}
