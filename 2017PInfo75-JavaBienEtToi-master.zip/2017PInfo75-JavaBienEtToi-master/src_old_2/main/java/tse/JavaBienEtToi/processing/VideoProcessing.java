package tse.JavaBienEtToi.processing;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.opencv.core.Mat;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.objdetect.CascadeClassifier;

import tse.JavaBienEtToi.person.PersonList;
import tse.JavaBienEtToi.video.Video;

/**
 * the class that is used to process a part ( can be used for the full length of the video ) of a video
 * process means here to process the video frame per frame, which means use a classifier on each frame to detect persons
 * 
 * @author Corentin
 *
 */
public class VideoProcessing {
	
	/** don't put that to false! this is used to determine if we should postprocess or not*/
	private Boolean optimised=true;
	/** this is the video on which we are performing the processing */
	private Video vid;
	/** param are the parameters of the classifiers */
	private Parameters param;
	/** number of the first frame on which we apply the processing */
	private int firstFrame;
	/** number of the last frame on which we apply the processing */
	private int lastFrame;
	/** number of the frame on which we apply the processing */
	private int currentFrame;
	/** frame on which we apply the processing */
	private Mat image= new Mat();
	/** number of frames used to postprocess - we are taking all the persons of the around frames and puting them in the actual frame to increase the number of detections on each frame */
	private int stack=30;// nombre de frames pour le postTraitement
	/** persons detected */
	private ArrayList<PersonList> persons= new ArrayList<PersonList>();
	/** classifiers */
	private CascadeClassifier cascade1= new CascadeClassifier("classifieurs/data/haarcascades/haarcascade_upperbody.xml");
	/** classifiers */
	private CascadeClassifier cascade2= new CascadeClassifier("classifieurs/data/haarcascades/haarcascade_fullbody.xml");
	/** classifiers */
	private CascadeClassifier cascade3= new CascadeClassifier("classifieurs/data/haarcascades/haarcascade_frontalface_default.xml");
	/** classifiers */
	private ArrayList<CascadeClassifier> cascadeList = new ArrayList<CascadeClassifier>();
	/** mask used for the postprocessing - someone detected in the black part of the mask is rather a wall or a door */
	private Mat mask =Imgcodecs.imread("./imagesTest/mask6.bmp" );
	/** look at mask */
	private ArrayList<ArrayList<Double>> maskClone= new ArrayList<ArrayList<Double>>();
	//-hallmetro.png
	
	
	/**
	 * constructor
	 * @param vid is the current video to be processed
	 * @param firstFrame is the first frame of the part of the video to analyse, not necessary the first frame of the video
	 * @param lastFrame is the last frame to analyse, not necessary the last frame of the video
	 */
	public VideoProcessing(Parameters param, Video vid, int firstFrame, int lastFrame) {
		
		this.param = param;
		this.stack=param.getStack();
		this.vid = vid.clone();
		this.firstFrame = firstFrame;
		this.lastFrame = lastFrame;
		this.currentFrame= firstFrame;
		
		setMaskClone();
		
		processVid();
		if (optimised==true)
			postProcessing();
		System.out.println("terminated");
		
	}
	
	/**
	 * get the image of the mask to create an ArrayList containing the values of the image
	 * it is used to increase the performances of the application by reducing the impact of the I/O 
	 * 
	 */
	private void setMaskClone() {
		Size a=mask.size();
		for (int i=0; i<a.width; i++) {
			ArrayList<Double> temp= new ArrayList<Double>();
			for (int j=0; j<a.height; j++) {
				
				double[] t= new double[1];
				t=mask.get(j,i);
				temp.add(t[0]);
			}
			try {
				maskClone.get(i).addAll(temp);
			} catch (IndexOutOfBoundsException e) {
				maskClone.add(new ArrayList<Double>());
				maskClone.get(i).addAll(temp);
			}
			temp.clear();
		}
	}
	
	/**
	 * getter
	 * 
	 * put the boolean in the parameters to false to use the application without optimisations like the removing of redondant persons
	 * 
	 * @return a boolean
	 */
	public Boolean getOptimised() {
		return optimised;
	}

	/**
	 * if optimised equals true
	 * remove all redondant persons by comparing their positions
	 * adds undetected persons if they are detected on nearly frames ( the nearly milliseconds )
	 */
	private void postProcessing() {
		boolean ithAlreadyHere;
		boolean workDone;
		
		 
		ArrayList<PersonList> temp= new ArrayList<PersonList>(); // personnes finales
		
		
		PersonList temp3= new PersonList(); // personnes qu'on garde sur une période i:i+50 frames
		PersonList temp2= new PersonList(); // personnes non redondantes de la ieme frame
		
		temp3.add(persons.get(0)); // personnes de la premiere frame
		int current=0;
		for (int i=1; i<persons.size(); i++) { // on parcourt toutes les frames
			/*if (i%10==0)
				System.out.println("10 frames traitées de plus sur: "+persons.size());
			//*/
			if (i-(current+1)*stack>0 || i==persons.size()) { // si on a parcouru stack frames
				//for (int l=i-50-1; l<i-1; l++) { // on rajoute le même tableau 50 fois, oui c'est bien ça
				temp.add(new PersonList());	
				temp.get(current).add(temp3); // ce sont les personnes detectees sur les 50frames de l'intervalle i-50:i
					
				//}
				current+=1;// on augmente l'interval sur lequel on travaille ( on passe de i:i+50 à i+50:i+100 )
				
				temp3.clear();
				
				temp3.add(persons.get(i)); // pour restart sur le nouvel interval
				System.gc();
				
			}
			
			for (int j=0; j<persons.get(i).size(); j++) { // on parcourt toutes les personnes de la ieme frame
				
				//System.out.println("personne: "+j+" sur "+persons.get(i).size());
				temp2.clear();
				
				ithAlreadyHere=false; // ith person was already found ?
				workDone=false;
				while (!ithAlreadyHere && !workDone) {
					if (temp3.size()!=0) { // on ajoute jamais de personnes (puisqu'on ne fait pas de comparaisons ) si temp3 est vide
						for (int k=0; k<temp3.size(); k++) { // on verifie si chacune des personnes de la ieme frame ne sont pas dejà là ( dans temp3 ou pas )
							//System.out.println("verification "+k+" sur "+temp3.size());
							
							
							if ( persons.get(i).get(j).comparePos(temp3.get(k),30) ) { // on compare les personnes de la ieme frame avec toutes les personnes detectees jusque là dans l'intervalle i:i+x
								ithAlreadyHere=true;
								
							} 
							
						}
						
					} else { // donc si temp3 est vide, on ajoute la personne qu'on etait censé checker
						temp3.add(persons.get(i).get(j));
						workDone=true; // pour sortir de la boucle et changer de personne à checker
						
					}
					
					if (!ithAlreadyHere)
						temp2.add(persons.get(i).get(j));
					workDone=true; // pour sortir de la boucle qui serait infinie sinon dans le cas où là personne est pas déjà présente
				}
				
				temp3.add(temp2);
				temp2.clear();
				/*if (temp2.size()==0)
					System.out.println("test done - temp2 cleared");*/
			}
			
			
		}
		persons.clear();// on clear persons
		persons.addAll(temp); // et on le remplace par temp qui contient les personnes non redondantes
		temp.clear(); // on clear pour la mémoire
		temp3.clear();
		temp2.clear();
		
	}




	/**
	 * getter
	 * @return the list of the persons detected for each frames
	 */
	public ArrayList<PersonList> getPersons() {
		return persons;
	}
	
	/**
	 * performs the processing
	 * which means it calls ImageProcessing for each frame to be processed 
	 */
	public void processVid() {
		cascadeList.add(cascade1);
		//cascadeList.add(cascade2);
		cascadeList.add(cascade3);
		int n=15; // frames qu'on saute
				
		image=vid.getMat(firstFrame);
		ImageProcessing ti=new ImageProcessing(param,image,maskClone, firstFrame, cascadeList);
		persons.add(ti.getPersons());
		currentFrame+=1;
		for (int k=1; k<n; k++ ) { // on saute les n-1 frames suivantes
			persons.add(persons.get(persons.size()-1));
			currentFrame+=1;
		}
		
		
		

	
		
		while(currentFrame<lastFrame ) {
			
			
			// si c'est la n*kieme
			if (currentFrame%n==0) {
				image=vid.getNextMat(); // on prend la frame
				// on fait un traitement dessus
				ti=new ImageProcessing(param,image,maskClone, currentFrame, cascadeList); 
				persons.add(ti.getPersons()); // on ajoute le traitement
				
			} else { // sinon on ajoute le dernier traitement aux personnes
				image=vid.getNextMat(); // on prend la frame mais on fait pas le traitement
				persons.add(persons.get(persons.size()-1));
				
			}
			currentFrame+=1;
		}
		
	}

	/**
	 * getter
	 * @return the number of the first frame to be processed
	 */
	public int getFirstFrame() {
		return firstFrame;
	}

	/**
	 * setter
	 * @param firstFrame is the first frame to be processed
	 */
	public void setFirstFrame(int firstFrame) {
		this.firstFrame = firstFrame;
	}

	/**
	 * getter
	 * @return the last frame to be processed
	 */
	public int getLastFrame() {
		return lastFrame;
	}

	/**
	 * setter
	 * @param lastFrame is the last frame to be processed
	 */
	public void setLastFrame(int lastFrame) {
		this.lastFrame = lastFrame;
	}

	/**
	 * getter
	 * @return the frame currently processed
	 */
	public int getCurrentFrame() {
		return currentFrame;
	}

	/**
	 * setter
	 * @param currentFrame is the currently processed frame
	 */
	public void setCurrentFrame(int currentFrame) {
		this.currentFrame = currentFrame;
	}

	/**
	 * setter
	 * @param vid is the video to be processed
	 */
	public void setVid(Video vid) {
		this.vid = vid;
	}
		
	/**
	 * getter
	 * @return the value of stack
	 */
	public int getStack() {
		return stack;
	}
	
}
