package tse.JavaBienEtToi.processing;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import tse.JavaBienEtToi.person.PersonList;
import tse.JavaBienEtToi.person.PersonVideo;
import tse.JavaBienEtToi.video.Video;

/**
 * Class containing the data of the video processing
 * 
 * @author Baptiste Wolff
 *
 */
public class VideoProcessingData {
	private PersonVideo persons;
	private int firstFrame = 0;
	private int lastFrame = 0;
	private int stack = 30;
	private double fps=0;

	/**
	 * Class constructor.
	 */
	public VideoProcessingData() {
		this.persons = new PersonVideo(0);
	}

	/**
	 * Runs the threads for the processing.
	 * 
	 * @param video
	 * @param firstFrame
	 * @param lastFrame
	 */
	public void runProcessing(Parameters param, Video video, int firstFrame, int lastFrame) {
		this.firstFrame = firstFrame;
		this.lastFrame = lastFrame;
		this.fps=video.fps();
		long start = System.currentTimeMillis();

		ArrayList<PersonList> persons2 = new ArrayList<PersonList>();
		this.persons = new PersonVideo(video.size());

		// The number of threads is determined by the number of logical cores of the
		// CPU.
		int threadNumber = Runtime.getRuntime().availableProcessors();
		System.out.println("Thread number : " + threadNumber);

		// The work is divided between each thread.
		int firstFrame2 = firstFrame;
		int lastFrame2 = (lastFrame - firstFrame) / threadNumber + firstFrame2;
		int[] framesDistribution = new int[threadNumber * 2];

		for (int i = 0; i < threadNumber; i++) {
			framesDistribution[i] = firstFrame2;
			framesDistribution[i + 1] = lastFrame2;
			firstFrame2 = lastFrame2 + 1;
			lastFrame2 = (lastFrame - firstFrame) / threadNumber + firstFrame2;
			if (lastFrame2 > lastFrame) {
				lastFrame2 = lastFrame;
				if (firstFrame2 > lastFrame) {
					firstFrame2 = lastFrame;
				}
			}
		}

		// Runs the threads
		ExecutorService service = Executors.newFixedThreadPool(threadNumber);
		VideoProcessingThread[] processing = new VideoProcessingThread[threadNumber];

		for (int i = 0; i < threadNumber; i++) {
			processing[i] = new VideoProcessingThread(param, video, framesDistribution[i], framesDistribution[i + 1]);
			service.execute(processing[i]);
		}

		// Finish
		shutdownAndAwaitTermination(service);

		long last = System.currentTimeMillis();
		System.out.println("Total time elapsed : " + (last - start));
		System.out.println("Processing finished");

		// Concatenate all the persons found in each thread.
		for (int i = 0; i < threadNumber; i++) {
			persons2.addAll(processing[i].getPersons());
		}

		stack=param.getStack();
		// Pair each calculated frame with its right frame.
		for (int i = firstFrame; i < lastFrame; i++) {
			int videoIndice = (int) Math.floor(i / stack);
			persons.set(i, persons2.get(videoIndice));
		}
	}

	public PersonVideo getPersons() {
		return persons;
	}

	public int getFirstFrame() {
		return firstFrame;
	}

	public int getLastFrame() {
		return lastFrame;
	}

	/**
	 * Good practice: code imported from Oracle example
	 * 
	 * @param pool
	 */
	static void shutdownAndAwaitTermination(ExecutorService pool) {
		pool.shutdown(); // Disable new tasks from being submitted
		try {
			// Wait a while for existing tasks to terminate
			if (!pool.awaitTermination(60, TimeUnit.SECONDS)) {
				pool.shutdownNow(); // Cancel currently executing tasks
				// Wait a while for tasks to respond to being cancelled
				if (!pool.awaitTermination(60, TimeUnit.SECONDS))
					System.err.println("Pool did not terminate");
			}
		} catch (InterruptedException ie) {
			// (Re-)Cancel if current thread also interrupted
			pool.shutdownNow();
			// Preserve interrupt status
			Thread.currentThread().interrupt();
		}
	}

	public double getfps() {
		return fps;
	}
}
