package tse.JavaBienEtToi.processing;

import java.util.ArrayList;

import tse.JavaBienEtToi.person.PersonList;
import tse.JavaBienEtToi.video.Video;

/**
 * Class running the video processing on a thread.
 * 
 * @author Baptiste Wolff
 *
 */
public class VideoProcessingThread extends Thread {
	Parameters param;
	Video vid;
	int firstFrame;
	int lastFrame;
	VideoProcessing vidProcessing;

	/**
	 * Class constructor
	 * 
	 * @param vid
	 *            The video being processed
	 * @param firstFrame
	 * @param lastFrame
	 */
	public VideoProcessingThread(Parameters param, Video vid, int firstFrame, int lastFrame) {
		this.param = param;
		this.vid = vid;
		this.firstFrame = firstFrame;
		this.lastFrame = lastFrame;
	}

	public void run() {
		vidProcessing = new VideoProcessing(param, vid.clone(), firstFrame, lastFrame);
	}

	public ArrayList<PersonList> getPersons() {
		return vidProcessing.getPersons();
	}
}
