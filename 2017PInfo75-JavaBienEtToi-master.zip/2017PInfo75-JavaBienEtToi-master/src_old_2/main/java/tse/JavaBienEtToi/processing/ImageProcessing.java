package tse.JavaBienEtToi.processing;

import java.util.ArrayList;
import java.util.List;

import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;
import org.opencv.objdetect.Objdetect;

import tse.JavaBienEtToi.person.Person;
import tse.JavaBienEtToi.person.PersonList;

/**
 * Processing of one simple frame
 * The processing takes the frame and return the persons detected on this frame
 * @author Corentin
 *
 */
//https://docs.opencv.org/2.4.13.2/modules/objdetect/doc/cascade_classification.html?highlight=haartraining
public class ImageProcessing implements Runnable{
 
	/** all the persons detected by the classifier on this frame */
	private ArrayList<Person> persons= new ArrayList<Person>();
	
	/** number of persons detected by the classifier on this frame */
	private int detectedPersons=0;
	// class related parameters
	
	/** indice of the frame */
	int frameIndice;
	
	/** all the classifiers used for the processing */
	private ArrayList<CascadeClassifier> cascadeList;
	// classifier related parameters
	
	/** parameters of the detection, like the number of match points (neighbors) to validate a person */
	Parameters param;
	
	/** @return the number of persons detected */
	public int getDetectedPersons() {
		return detectedPersons;
	}
	/** @return the PersonList of the persons detected on this frame */
	public PersonList getPersons() {
		PersonList pl=new PersonList(persons);
		return pl;
	}
	
	
	/**
	 * Constructor when using several classifiers at the same time.
	 * @param image is the frame to process
	 * @param mask is the mask to apply on the frame, the dark part means nobody should be found there on the frame
	 * @param frameIndice is the number of the frame in the video
	 * @param cascadeType is the name of the cascade classifier used to process this frame
	 */	
	public ImageProcessing(Parameters param, Mat image, ArrayList<ArrayList<Double>> mask, int frameIndice, ArrayList<CascadeClassifier> cascadeList) {
		this.param = param;
		process(image, mask, frameIndice, cascadeList);
	}
	
	/**
	 * Performs the processing.
	 * @param image is the frame to process
	 * @param mask is the mask to apply on the frame, the dark part means nobody should be found there on the frame
	 * @param frameIndice is the number of the frame in the video
	 * @param cascadeList is the list of all the cascade classifiers used to process this frame
	 */
	private void process(Mat image, ArrayList<ArrayList<Double>> mask, int frameIndice, ArrayList<CascadeClassifier> cascadeList) {
		
		Mat grayFrame= new Mat();
		MatOfRect positions = new MatOfRect();
		
		// First of all we need to convert the frame in grayscale 
		Imgproc.cvtColor(image, grayFrame, Imgproc.COLOR_BGR2GRAY);
		// and equalize the histogram																																																												 to improve the results:
		Imgproc.equalizeHist(grayFrame, grayFrame);
	
		Rect[] temp;
		Rect[] posArray= new Rect[0];
		int x=0;
		//Now we can start the detection: ( it returns a list of rectangles )
		for (int i=0; i<cascadeList.size()-1; i++ ) {
			// we're looping on the cascadeList to use each classifieur
			cascadeList.get(i).detectMultiScale(grayFrame, positions, param.getScaleFactor(), param.getMinNeighbors(), param.getFlags(), param.getMinSize(), param.getMaxSize());
			
			temp= new Rect[posArray.length];
			for (int k=0; k<posArray.length; k++ ){
				temp[k]=posArray[k]; 
				// on met posTab dans temp avant de changer la taille de posTab
			} // en gros temp=posTab
			
			posArray = new Rect[temp.length+ positions.toArray().length];
			x=temp.length;
			for (int k=0; k<temp.length; k++ ){
				posArray[k]=temp[k]; 
				// on recree posTab et on lui ajoute les positions qu'il avait dans l'iteration d'avant
			}// en gros posTab = [ posTab d'avant + du vide]
			
			
			temp= positions.toArray();
			for (int k=0; k<temp.length; k++ ){
				
				posArray[k+x]=temp[k];
				// puis on rajoute les nouvelles
			}// en gros posTab =[ posTab d'avant + new positions ]
			
		}
		
		if (frameIndice %50==0)
			System.out.println(frameIndice); 
		for (int i = 0; i < posArray.length; i++) {
			Point p1=posArray[i].tl();
			Point p2=posArray[i].br();
			
			// utilisation du masque sur chaque personne
			if (param.isUseMask()) {
				Long L = Math.round(p1.x);
				int x1 = Integer.valueOf(L.intValue());
				
				Long L2 = Math.round(p1.y);
				int y1 = Integer.valueOf(L2.intValue());
				
				Long L3 = Math.round(p2.x);
				int x2 = Integer.valueOf(L3.intValue());
				
				Long L4 = Math.round(p2.y);
				int y2 = Integer.valueOf(L4.intValue());
			
			
			
				try {
					// c'est ici que sa passe les comparaisons avec le masque
					if (x1>0 && y1>0 && x2>0 && y2>2 && x1<mask.size() && x2<mask.size() && y1<mask.get(0).size() && y2<mask.get(0).size()) {
						if (    (mask.get(x1).get(y1)) * (mask.get(x2).get(y2))!=0 ) {		// si un des coins est dans le masque		
							
							
							detectedPersons+=1;
							persons.add(new Person((int)p1.x, (int)p1.y, (int)(p2.x-p1.x),  (int)(p2.y-p1.y), frameIndice));
						}
					}
				} catch (NullPointerException e) {
					System.out.print("NullPointerException caught");
				}
			}
			else {
				detectedPersons+=1;
				persons.add(new Person((int)p1.x, (int)p1.y, (int)(p2.x-p1.x),  (int)(p2.y-p1.y), frameIndice));
			}
			
		}
		grayFrame.release(); // pour liberer la memoire via le garbage collector
		positions.release();
		
	}

	/**
	 * because of runnable
	 */
	public void run() {
		// TODO Auto-generated method stub
		
	}
}