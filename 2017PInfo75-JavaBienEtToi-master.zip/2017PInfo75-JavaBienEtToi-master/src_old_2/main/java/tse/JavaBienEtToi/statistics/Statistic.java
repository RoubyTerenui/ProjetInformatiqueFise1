package tse.JavaBienEtToi.statistics;

import java.awt.Color;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;

import tse.JavaBienEtToi.processing.VideoProcessingData;

/**
 * Class used to Calculate all the statistics usefull to the users
 * 
 *
 * @author Rouby Terenui
 * @author Baptiste Wolff
 */
public class Statistic extends JPanel {
	/** interestAreas : The list of InterestArea defined by the user */
	private List<InterestArea> interestAreas = new ArrayList<InterestArea>();
	
	/**
	 * listChartNbPpl : the list of the Chart which correspond to different
	 * statistics
	 */
	private List<Chart> listChartNbPpl = new ArrayList<Chart>();

	public Statistic(int firstframe, int lastframe) {
		super();
	}

	/**
	 * add a char to ListChartNbPpl
	 * @param e
	 */
	public void addChartNbPpl(Chart e) {
		getListChartNbPpl().add(e);
	}

	/**
	 * Open a new Jframe and display the chart choosen
	 * 
	 * @param i:Index
	 *            of the chart in ListChartNbPpl you want to display
	 */
	public void showGraphique(int i) {
		// On utilise Graphics Environment pour pouvoir adapter la taille des fenetre en
		// fonction des écrans
		// get local graphics environment
		GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
		// get maximum window bounds
		Rectangle maximumWindowBounds = graphicsEnvironment.getMaximumWindowBounds();

		JFrame windowchart = new JFrame();
		windowchart.setLocation((int) Math.round(maximumWindowBounds.getWidth() * 0.5), 0);
		windowchart.add(getListChartNbPpl().get(i));
		windowchart.setTitle("Calculstatistique");
		windowchart.setSize((int) Math.round(maximumWindowBounds.getWidth() * 0.5),
				(int) Math.round(maximumWindowBounds.getHeight()));
		windowchart.setDefaultCloseOperation(windowchart.DISPOSE_ON_CLOSE);
		windowchart.setVisible(true);
	}

	/**
	 * 
	 * @return List<Interestarea>: the list of Interest area
	 */
	public List<InterestArea> getInterestAreas() {
		return interestAreas;
	}

	/**
	 * 
	 * @param interestareas:defines
	 *            the field interestAreas
	 */
	public void setInterestAreas(List<InterestArea> interestareas) {
		this.interestAreas = interestareas;
	}

	/**
	 * Add an interest area to interestAreas
	 * 
	 * @param iz
	 *            :the interest area you want to add
	 */
	public void addInterestarea(InterestArea iz) {
		interestAreas.add(iz);
		interestAreas.get(interestAreas.size() - 1).setName("Z" + interestAreas.size());
	}

	/**
	 * remove the last Interest Area added to interestAreas
	 */
	public void removelastenter() {
		interestAreas.remove(interestAreas.size() - 1);
	}

	/**
	 * Returns the average number of people per minute in each area.
	 * 
	 * @return list containing the average number of people per minute
	 */
	public List<Float> getNBP() {
		List<Float> listNBP = new ArrayList<Float>();
		if (interestAreas.size() == 0) {
			listNBP.add((float) 0);
		} else {
			for (int i = 0; i < interestAreas.size(); i++) {
				listNBP.add(interestAreas.get(i).getTotalPoepleNumber());
			}
		}
		return (listNBP);
	}

	/**
	 * 
	 * @return the list of Interest areas name
	 */
	public List<String> getNameIZ() {
		List<String> nameList = new ArrayList<String>();
		for (int i = 0; i < interestAreas.size(); i++) {
			nameList.add(interestAreas.get(i).getName());
		}
		return nameList;
	}

	/**
	 * 
	 * @return the listChartNbPpl
	 */
	public List<Chart> getListChartNbPpl() {
		return listChartNbPpl;
	}

	/**
	 * Define the listChartNbPpl by a defined List<Chart>
	 * 
	 * @param listChartNbPpl
	 */
	public void setListChartNbPpl(List<Chart> listChartNbPpl) {
		this.listChartNbPpl = listChartNbPpl;
	}

	/**
	 * Process the statistics by counting peoples in each interest area. This also
	 * sets the graphic to be displayed later.
	 * 
	 * @param persons
	 * @author Baptiste Wolff
	 * @author Terenui Rouby
	 */
	public void processStats(VideoProcessingData videoProcessing) {
//		List<Integer> NbPpl = new ArrayList<Integer>();
		List<String> Nbmin = new ArrayList<String>();//Number of minutes which have been processed
		
		int firstframe=videoProcessing.getFirstFrame();
		int	lastframe=videoProcessing.getLastFrame();
		int time=((int)Math.floor((lastframe-firstframe)/(videoProcessing.getfps()*60))+1);
		System.out.println(time);
		
		
		for (int j = 0; j < time; j++) {
			firstframe=firstframe+(int)(j*(videoProcessing.getfps()*60));
			lastframe=firstframe+(int)(videoProcessing.getfps()*60);
			if (lastframe<videoProcessing.getLastFrame()) {
			Nbmin.add(Integer.toString(j));
			for (int i = 0; i < interestAreas.size(); i++) {
				interestAreas.get(i).countPeople(videoProcessing,firstframe,lastframe);
				}
			}
		}
		
		Chart g = new Chart("Nombre de Personne par Zone d'interet", "temps en minute", "Nombre de Personne", this.getNBP(), Color.white,
				this.getNameIZ(), Nbmin, true);
		this.addChartNbPpl(g);
	}
	/**
	 * Process the statistics by counting peoples in each interest area. Doesn't create a chart to be displayed
	 * 
	 * @param persons
	 * @author Baptiste Wolff
	 */
	public void updateInterestAreas(VideoProcessingData videoProcessing) {
		for (int i = 0; i < interestAreas.size(); i++) {
			interestAreas.get(i).countPeople(videoProcessing,videoProcessing.getFirstFrame(),videoProcessing.getLastFrame());
		}
	}
}
