package tse.JavaBienEtToi.statistics;

import org.opencv.core.Point;

import tse.JavaBienEtToi.person.Person;
import tse.JavaBienEtToi.person.PersonList;
import tse.JavaBienEtToi.person.PersonVideo;
import tse.JavaBienEtToi.processing.VideoProcessingData;

/**
 * Class used to define an Interest Area
 *
 * @author Rouby Terenui
 */
public class InterestArea {

	/** p1:First point that correspond to the top-left corner of the rectangle */
	private Point p1;
	/**
	 * p2:Second point that correspond to the bottom-right corner of the rectangle
	 */
	private Point p2;

	/**
	 * Total number of people for each image in the interest area.
	 */
	int[] peopleNumber = new int[0];
	/**
	 * Total number of people in the interest area.
	 */
	int totalPeopleNumber = 0;

	/**
	 * The first and last fram that have been under process
	 */
	int firstFrame = 0, lastFrame = 0;

	/**
	 * Average number of people in the interest area for the whole video.
	 */
	float averagePeopleNumber = 0;

	String name = "Interest area";
	
	public float getTotalPoepleNumber() {
		return((float)totalPeopleNumber);
	}
	
	public int getPeopleNumber(int frameNumber) {
		if (frameNumber > lastFrame || frameNumber < firstFrame || peopleNumber.length == 0) {
			return 0;
		} else {
			return peopleNumber[frameNumber - firstFrame];
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getAveragePeopleNumber() {
		return averagePeopleNumber;
	}

	public InterestArea(Point a, Point b) {
		this.setP1(a);
		this.setP2(b);
	}

	public Point getP1() {
		return p1;
	}

	public Point getP2() {
		return p2;
	}

	public void setP1(Point point) {
		p1 = point;
	}

	public void setP2(Point point) {
		p2 = point;
	}

	/** Copy the current Interest area on a new one */
	public InterestArea clone() {
		return new InterestArea(p1.clone(), p2.clone());
	}

	/**
	 * Counts the people which are in the interest area for each image of the video.
	 * 
	 * @author Baptiste Wolff
	 * @param persons
	 */
	public void countPeople(VideoProcessingData videoProcessing,int firstframe,int timeframe) {
		PersonVideo persons = videoProcessing.getPersons();
		peopleNumber = new int[persons.size()];
		
		firstFrame = firstframe;
		lastFrame = timeframe;
		for (int i = 0; i < persons.size(); i++) {
			PersonList personList = persons.get(i);
			peopleNumber[i] = 0;

			for (int j = 0; j < personList.size(); j++) {
				Person person = personList.get(j);
				if (person.isInInterestZone(this)) {
					peopleNumber[i]++;
					totalPeopleNumber++;
				}
			}
		}
		if (lastFrame - firstFrame > 0) {
			averagePeopleNumber = (float) totalPeopleNumber / (float) (lastFrame - firstFrame);
		} else {
			averagePeopleNumber = totalPeopleNumber;
		}
	}


}
