package tse.JavaBienEtToi.statistics;
import javax.swing.JPanel;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.stage.Stage;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GradientPaint;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
/**
 * Class used to create a Chart
 * 
 *
 * @author Rouby Terenui,
 */
public class Chart extends JPanel {

	private static final long serialVersionUID = 1L;

	/** title : title of the chart displayed on the top */
	private String title;
	/** northing : name of the northing */
	private String northing;
	/** easting : name of the easting */
	private String easting;
	/** values : values to display that are sorted by series and categories
	 * In order to function correctly the size of values must be equal to
	 * the size of series * the size of type
	 * */
	private List<Float> values;
	/** series : list of series */
	private List<String> series;
	/** type : list of type */
	private List<String> type;
	/** legend : booleen vrai if the legend is displayed */
	private boolean legend;
	/** Backgroundcolor : color of the background */
	private Color backgroundcolor;
	/** stickcolor : color applied to the stick */
	private Color[] stickcolor = {Color.cyan.darker(), 
			Color.red, Color.green, Color.cyan, Color.magenta, 
			Color.yellow, Color.pink, Color.darkGray, Color.orange};




	public Chart(String title, String easting, String northing, List<Float> values, Color background, List<String> serieslist, List<String> typelist, boolean legend) {
		super(new GridLayout(1,0));
		this.title=title;
		this.northing=northing;
		this.easting=easting;
		this.values=values;
		this.series=serieslist;
		this.type=typelist;
		this.legend=legend;
		this.backgroundcolor=background;
		initiate();
	}

	

    /**
     * Method that creates the chart and that draws the chart on a Jpanel
     */
	private void initiate(){
		DefaultCategoryDataset dataset = new DefaultCategoryDataset();
		int k = 0;
		for ( int j=0; j<type.size(); j++){
			for (int i=0; i<series.size(); i++){
				dataset.addValue(values.get(k), series.get(i), type.get(j));
				k++;
			}

		}
		JFreeChart chart = ChartFactory.createBarChart(
				title,   					// chart title
				easting,					// domain axis label
				northing,   				// range axis label
				dataset,    				// data
				PlotOrientation.VERTICAL, 	// orientation
				legend,                    // include legend
				true,                     	// tooltips
				false                     	// URL
		);

		// definition de la couleur de fond
		chart.setBackgroundPaint(backgroundcolor);

		CategoryPlot plot = (CategoryPlot) chart.getPlot();

		//valeur comprise entre 0 et 1 transparence de la zone	 graphique
		plot.setBackgroundAlpha(0.9f);


		BarRenderer renderer = (BarRenderer) plot.getRenderer();
		renderer.setDrawBarOutline(false);

		// pour la couleur des barres pour chaque serie

		for (int s=0; s<series.size(); s++){
			GradientPaint gp0 = new GradientPaint(0.0f, 0.0f, stickcolor[s],
					0.0f, 0.0f, new Color(0, 40, 70));
			renderer.setSeriesPaint(s, gp0);

		}		
		ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setMouseWheelEnabled(true);
        chartPanel.setHorizontalAxisTrace(true);
        chartPanel.setVerticalAxisTrace(true);
		chartPanel.setFillZoomRectangle(true);
		chartPanel.setMouseWheelEnabled(true);
		chartPanel.setPreferredSize(new Dimension(500, 270));
		add(chartPanel);
	}

}