package tse.JavaBienEtToi.person;

import java.util.ArrayList;

import org.opencv.core.Point;
import org.opencv.core.Rect;

import tse.JavaBienEtToi.statistique.Interestarea;


/**
 * 
 * @author Corentin Renault
 *
 */
public class Person{
	private int x;
	private int previousX;
	
	private int y;
	private int previousY;
	
	private int width;
	private int height;
	
	private int apparition;
	
	private Interestarea zone;
	
	
	public int getApparition() {
		return apparition;
	}

	public void setApparition(int apparition) {
		this.apparition = apparition;
	}

	public Interestarea getZone() {
		return zone;
	}

	public void setZone(Interestarea zone) {
		this.zone = zone;
	}

	public Person(int x, int y, int width, int height, int apparitionFrame) {
		this.x=x;
		this.y=y;
		this.previousX=-1;
		this.previousY=-1;
		this.width=width;
		this.height=height;
		apparition=apparitionFrame;
	}
	
	public Person(Rect position, int apparitionFrame) {
		this.x=position.x+(int)Math.floor(position.width/2);
		this.y=position.y+(int)Math.floor(position.height/2);
		this.previousX=-1;
		this.previousY=-1;
		this.width=position.width;
		this.height=position.height;
		apparition=apparitionFrame;
	}
	
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getPreviousX() {
		return previousX;
	}
	public void setPreviousX(int previousX) {
		this.previousX = previousX;
	}
	public int getPreviousY() {
		return previousY;
	}
	public void setPreviousY(int previousY) {
		this.previousY = previousY;
	}
	
	
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	
	/**
	 * @author Corentin Renault
	 * @param neighbourhood
	 * @return true si la position actuelle est dans le voisinage de la position précédente, false dans le cas contraire
	 */
	public Boolean comparePos(int neighbourhood) { 
		if ( isBetweenPoints(x, previousX, neighbourhood) && isBetweenPoints(y, previousY, neighbourhood)) {
			return true;
		} 
		return false;
	}
	
	/**
	 * @author Corentin Renault
	 * @param neighbourhood
	 * @return true si la position actuelle est dans le voisinage de la position précédente, false dans le cas contraire
	 */
	public Boolean comparePos(Person person, int neighbourhood) { 
		if ( isBetweenPoints(x, person.getX(), neighbourhood) && isBetweenPoints(y, person.getY(), neighbourhood)) {
			return true;
		}// compare les centres de gravité
		else if ( this.isIncludedIn(person) || person.isIncludedIn(this) ) {
			return true;
		}
		return false;
	}
	
	
	/**
	 * 
	 * @param p est une autre personne que this
	 * @return true si this est inclu dans la personne à au moins 70%
	 */
	public Boolean isIncludedIn(Person p) {
		if ( this.width*this.height> p.width*p.height ) 
			return false;
		
		
		int temp=0;
		
		
		if( this.x+this.width<p.x ||  this.x>p.x+p.width) {
			// pas inclu
			return false;
		} else if ( this.y+this.height<p.y ||  this.y>p.y+p.height){
			// idem
			return false;
		} 
		
		// il existe forcement une jonction entre les deux rectangles
		
		else if ( this.x+this.width< p.x+p.width && this.x>p.x ) {
			// this depasse eventuellement en dessous et au dessus mais certainement pas sur les côtés
			if ( this.y+this.height< p.y+p.height && this.y>p.y ) {
				// totalement inclu
				return true;
			} else { 	// depasse sur le haut ou le bas ou les deux
				
				temp=this.width*this.height; 
				// on initialise temp à la surface totale de this avant de retirer les extremites qui depassent de p
			
				if ( this.y<p.y) { // depasse en haut
					temp=temp-(p.y-this.y)*this.width;
					System.out.println("8 "+temp);
					// on retire la surface qui depasse 
				}
				
				if ( this.y+this.height>p.y+p.height) { // depasse en bas
					temp=temp-((this.y+this.height)-(p.y+p.height))*this.width;

					System.out.println("7 "+temp);
				}
			}
		} else if  ( this.y+this.height< p.y+p.height && this.y>p.y ) {
			// this depasse eventuellement sur les côtés droit ou gauche mais certainement pas sur le dessus ou le dessous
			
			//ne peut pas être totalement inclu cf tests précédents
			
			temp=this.width*this.height; 
			// on initialise temp à la surface totale de this avant de retirer les extremites qui depassent de p
		
			if ( this.x<p.x) { // depasse à gauche
				temp=temp-(p.x-this.x)*this.height;

				System.out.println("6 "+temp);
				// on retire la surface qui depasse 
			}
			
			if ( this.x+this.width>p.x+p.width) { // depasse à droite
				temp=temp-((this.x+this.width)-(p.x+p.width))*this.height;

				System.out.println("5 "+temp);
			}
			
			
		}
		
		
		
	
		
		// est sans doute au niveau d'un des sommets de p cf dessin
		else if ( this.x<p.x ) { // depasse sommet gauche haut ou bas
			if (this.y<p.y) {
				// sommet haut gauche !!
				temp=(this.x+this.width-p.x)*(this.y+this.height-p.y);
				System.out.println("4 "+temp);
				
			} else if (this.y+this.height>p.y+p.height){
				// sommet bas gauche !!
				temp=(p.y+p.height-this.y)*(this.width+this.x-p.x);

				System.out.println("3 "+temp);
				
			}
		} else if ( this.x+this.width>p.x+p.width ){ // depasse sommet droit haut ou bas
			if (this.y<p.y) {
				// sommet haut droit!!
				temp=(p.x+p.width-this.x)*(this.y+this.height-p.y);
				System.out.println("2 "+temp);
				
			} else if (this.y+this.height>p.y+p.height){
				// sommet bas droit !!
				temp=(p.y+p.height-this.y)*(p.width+p.x-this.x);
				System.out.println("1 "+temp);
			}
		} else {
			// bah ils se croisent pas vos rectangles ;)
			return false;
		}
		
		System.out.println(this.width*this.height*0.7);
		// temp =surface incluse dans p
		if (temp> this.width*this.height*0.7)
			return true;
		
		return false;
	}
	
	
	/**
	 * @author Corentin Renault
	 * @param pos position actuelle
	 * @param previousPos position précédente
	 * @param neighbourhood voisinage autour de la position précédente
	 * @return true si pos est proche de la position précédente, false sinon
	 */
	private Boolean isBetweenPoints(int pos, int previousPos, int neighbourhood) {
	
		return  abs(pos-previousPos)<neighbourhood ? true : false;
	}
	
	private int abs(int i) {
		// TODO Auto-generated method stub
		return i>0 ? i: -i;
	}

	/**
	 * @author Corentin Renault
	 * @param actualNumberFrame
	 * @return the number of frames since the person appeared
	 */
	private int existenceTime(int actualFrameNumber) {
		return actualFrameNumber-apparition;
	}
	
	/**
	 * @author Corentin Renault
	 * @param interestZones
	 * @return true if the person is, at least partially, in the interest zone, false if he isn't
	 */
	private Boolean isInInterestZone( Interestarea interestZone) { // 0 --> x 
		if (pointIsInZone(new Point(x-width/2,y), interestZone) || pointIsInZone(new Point(x,y-height/2), interestZone) || pointIsInZone(new Point(x+width/2,y), interestZone) || pointIsInZone(new Point(x,y+height/2), interestZone) ) {
			return true;
		}
		
		return false;
	}
	
	/**
	 * @author Corentin Renault
	 * @param p
	 * @param ZoneInteret
	 * @return true si le point est dans la zone d'interet, false sinon
	 */
	private Boolean pointIsInZone(Point p, Interestarea zone) {
		if (zone.getP1().x<p.x && p.x< zone.getP2().x && zone.getP1().y<p.y && p.y<zone.getP2().y) {
			return true;
		}
		return false;
	}
	
}
