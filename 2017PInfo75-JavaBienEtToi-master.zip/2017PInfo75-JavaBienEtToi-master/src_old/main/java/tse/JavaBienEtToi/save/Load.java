package tse.JavaBienEtToi.save;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.opencv.core.Point;

import tse.JavaBienEtToi.gui.utils.FileChooser;
import tse.JavaBienEtToi.statistique.Interestarea;

/**
 * Class used for loading the parameters previously saved
 * 
 * @author Baptiste Wolff
 *
 */
public class Load {
	/**
	 * Reads the zonesInterets file
	 * 
	 * @return List<ZoneInteret>
	 */
	public static List<Interestarea> interestsarea() {
		String fileName = FileChooser.pathR();
		return interestsarea(fileName);
	}

	public static List<Interestarea> interestsarea(String fileName) {
		List<Interestarea> zonesInterets = new ArrayList<Interestarea>();
		try {
			FileInputStream fin = new FileInputStream(fileName);
			BufferedInputStream bin = new BufferedInputStream(fin);
			DataInputStream in = new DataInputStream(bin);

			while (in.available() > 3) {
				for (int i = 0; i < 4; i++) {
					Point p1 = new Point(in.readInt(), in.readInt());
					Point p2 = new Point(in.readInt(), in.readInt());
					zonesInterets.add(new Interestarea(p1, p2));
				}
			}

			in.close();
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file '" + fileName + "'");
		} catch (IOException ex) {
			System.out.println("Error reading file '" + fileName + "'");
			// Or we could just do this:
			// ex.printStackTrace();
		}
		return zonesInterets;
	}
}
