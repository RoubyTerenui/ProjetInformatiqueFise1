package tse.JavaBienEtToi.save;

import java.awt.image.BufferedImage;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;

import tse.JavaBienEtToi.gui.utils.FileChooser;
import tse.JavaBienEtToi.statistique.Interestarea;

/**
 * Class managing all the saves
 * 
 * @author Baptiste Wolff
 *
 */
public class Save {
	/**
	 * Saves an image
	 * 
	 * @param image
	 * @param fileName
	 */
	public static void image(BufferedImage image, String fileName) {
		File fichier = new File(fileName + ".bmp");// or jpg

		try {
			ImageIO.write(image, "BMP", fichier); // or JPG
		} catch (IOException e) {
			System.out.println("Unable to save file");
			e.printStackTrace();
		}
	}

	/**
	 * Opens a dialog box and saves the image
	 * 
	 * @param image
	 */
	public static void image(BufferedImage image) {
		String path = FileChooser.pathS();
		if (path != "") {
			image(image, path);
		}
	}

	/**
	 * Opens a dialog box and saves the 'ZoneInterets'
	 * 
	 * @param zonesInterets
	 */
	public static void interestarea(List<Interestarea> zonesInterets) {
		String fileName = FileChooser.pathS();
		if (fileName != "") {
			interestarea(fileName, zonesInterets);
		}
	}

	public static void interestarea(String fileName, List<Interestarea> zonesInterets) {
		try {
			DataOutputStream out = new DataOutputStream(new FileOutputStream(fileName));
			for (int i = 0; i < zonesInterets.size(); i++) {
				Interestarea zoneInteret = zonesInterets.get(i);
				out.writeInt((int) zoneInteret.getP1().x);
				out.writeInt((int) zoneInteret.getP1().y);
				out.writeInt((int) zoneInteret.getP2().x);
				out.writeInt((int) zoneInteret.getP2().y);
			}
			// Always close files.
			out.close();

		} catch (IOException ex) {
			System.out.println("Error writing file '" + fileName + "'");
			// Or we could just do this:
			// ex.printStackTrace();
		}
	}
}
