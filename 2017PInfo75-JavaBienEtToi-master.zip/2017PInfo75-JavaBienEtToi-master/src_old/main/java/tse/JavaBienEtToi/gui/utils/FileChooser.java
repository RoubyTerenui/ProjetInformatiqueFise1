package tse.JavaBienEtToi.gui.utils;

import javax.swing.*;

public class FileChooser {
	public static String chemin() {
		String realPath = "";
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setAcceptAllFileFilterUsed(false);
		fileChooser.addChoosableFileFilter(new VideoFilter());
		if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
			// Récupère le chemin absolu du fichier
			String path = fileChooser.getSelectedFile().getAbsolutePath();
			// String file = fileChooser.getSelectedFile().getName();
			// Pour ouvrir un fichier video, on remplace dans le chemin les '\' par des '\\'
			realPath = path.replaceAll("\\\\", "\\\\\\\\");
		}
		return (realPath);
	}

	public static String pathS() {
		String realPath = "";
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Save");
		fileChooser.setApproveButtonText("Save");
		if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
			// Récupère le chemin absolu du fichier
			String path = fileChooser.getSelectedFile().getAbsolutePath();
			// String file = fileChooser.getSelectedFile().getName();
			// Pour ouvrir un fichier video, on remplace dans le chemin les '\' par des '\\'
			realPath = path.replaceAll("\\\\", "\\\\\\\\");
		}
		return (realPath);
	}

	public static String pathR() {
		String realPath = "";
		JFileChooser fileChooser = new JFileChooser();
		// fileChooser.setAcceptAllFileFilterUsed(false);
		// fileChooser.addChoosableFileFilter(new VideoFilter());
		if (fileChooser.showOpenDialog(null) == JFileChooser.APPROVE_OPTION) {
			// Récupère le chemin absolu du fichier
			String path = fileChooser.getSelectedFile().getAbsolutePath();
			// String file = fileChooser.getSelectedFile().getName();
			// Pour ouvrir un fichier video, on remplace dans le chemin les '\' par des '\\'
			realPath = path.replaceAll("\\\\", "\\\\\\\\");
		}
		return (realPath);
	}
}
