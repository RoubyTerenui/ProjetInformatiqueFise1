package tse.JavaBienEtToi.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import org.opencv.core.Point;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JSlider;
import javax.swing.SwingWorker;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.opencv.core.Mat;

import tse.JavaBienEtToi.gui.utils.FileChooser;
import tse.JavaBienEtToi.gui.utils.Jlabelmouse;
import tse.JavaBienEtToi.gui.utils.StretchIcon;
import tse.JavaBienEtToi.image.Image;
import tse.JavaBienEtToi.processing.ProcessingRunThreads;
import tse.JavaBienEtToi.save.Load;
import tse.JavaBienEtToi.save.Save;
import tse.JavaBienEtToi.statistique.Chart;
import tse.JavaBienEtToi.statistique.Statistique;
import tse.JavaBienEtToi.video.PlayPause;
import tse.JavaBienEtToi.video.Video;

/**
 * The main window.
 * Display the video and handles most user interactions.
 * 
 * @author RaphaelChevasson
 * @author Terenui Rouby
 * 
 *         TODO : code using displayImage(Mat i) -> use displayImage(int n) and
 *         displayImage()
 */
public class GUI extends JFrame implements ActionListener, ChangeListener {

	// Video
	private PlayPause playPause;
	private Video video;

	// Interest Zones
	private Statistique stat = new Statistique(0, 0);
	private boolean displayStat = false;

	// Processing
	private int stack=30;
	private boolean displayDetection = false;
	private ProcessingRunThreads tVid = new ProcessingRunThreads();

	// UI elements
	JFrame window = new JFrame();
	JPanel mainPanel, toolsPanel, devPanel, videoPanel, videoNavSliderPanel, videoNavButtonsPanel;
	JButton loadVideo, loadExempleVideo, displayInterestZones, startDetection, stopDetection;
	JButton nextFrame, previousFrame, pauseVideo, lastFrame, firstFrame, createInterestZone, resetInterestZones,
			processStatistics, saveImage, saveInterestZones, loadInterestZones, openDevModeWindow;
	JLabel timeLabel;
	JSlider timeSlider;
	Jlabelmouse displayedImageLabel = new Jlabelmouse(this);
	Point p1;
	Point p2;
	
	// File choosing mechanism
	JFileChooser fichier = new JFileChooser();

	/**
	 * create the GUI object and the main window
	 */
	public GUI() {
		//// Video
		playPause = new PlayPause(this);
		// see https://docs.oracle.com/javase/tutorial/uiswing/components/panel.html

		//// UI elements
		// main panel
		mainPanel = new JPanel(new BorderLayout());
		window.add(mainPanel);

		// tools panel
		JPanel leftPanel = new JPanel(new BorderLayout());
		mainPanel.add(leftPanel, BorderLayout.WEST);
		toolsPanel = new JPanel(new GridLayout(0, 1, 0, 1)); // (rox, col, HGap, VGap)
															 // here, we layout vertically
		leftPanel.add(toolsPanel, BorderLayout.NORTH);
		toolsPanel.add(addLabel("Charger",20,2));
		loadVideo = addBouton("Ouvrir une vidéo", toolsPanel);
		loadExempleVideo = addBouton("Utiliser la vidéo d'exemple", toolsPanel);
		toolsPanel.add(addLabel("Sauvegarder",20,2));
		// saving
		saveImage = addBouton("Sauvegarder l'image actuelle", toolsPanel);
		saveInterestZones = addBouton("Sauvegarder les zones d'intérêt", toolsPanel);
		// loading
		loadInterestZones = addBouton("Charger des zones d'interêt", toolsPanel);
		// statistics processing
		toolsPanel.add(addLabel("CalculStatistique",20,2));
		processStatistics = addBouton("Calcul Statistique", toolsPanel);
		// interest zones
		toolsPanel.add(addLabel("Zone d'Interet",20,2));
		displayInterestZones = addBouton("Afficher/Masquer les zones d'intérêt", toolsPanel);
		createInterestZone = addBouton("Créer une zone d'intérêt", toolsPanel);
		resetInterestZones = addBouton("Supprimer les zones d'intérêt", toolsPanel);
		toolsPanel.add(addLabel("Detection",20,2));
		startDetection = addBouton("Détection de personnes", toolsPanel);
		stopDetection = addBouton("Arréterla détection", toolsPanel);
		
		// dev panel (below tools panel)
		devPanel = new JPanel(new GridLayout(0, 1, 0, 1)); // (rox, col, HGap, VGap)
														   // here, we layout vertically
		leftPanel.add(devPanel, BorderLayout.SOUTH);
		devPanel.add(addLabel("Mode developpeur",20,2));
		openDevModeWindow = addBouton("Regler la détection", devPanel);

		// video panel
		videoPanel = new JPanel(new BorderLayout());
		mainPanel.add(videoPanel, BorderLayout.CENTER);
		videoPanel.add(displayedImageLabel, BorderLayout.CENTER);

		// video navigation panel
		JPanel videoNavPanel = new JPanel(new GridLayout(0, 1)); // here, we layout vertically
		videoPanel.add(videoNavPanel, BorderLayout.SOUTH);
		// buttons
		videoNavButtonsPanel = new JPanel();
		videoNavPanel.add(videoNavButtonsPanel);
		firstFrame = addBouton("|<<", videoNavButtonsPanel);
		previousFrame = addBouton("<", videoNavButtonsPanel);
		pauseVideo = addBouton("|>", videoNavButtonsPanel);
		nextFrame = addBouton(">", videoNavButtonsPanel);
		lastFrame = addBouton(">>|", videoNavButtonsPanel);
		timeLabel=new JLabel();
		videoNavButtonsPanel.add(timeLabel,BorderLayout.EAST);
		// time slider
		videoNavSliderPanel = new JPanel(new BorderLayout());
		videoNavPanel.add(videoNavSliderPanel);
		int initialValue = 0;
		timeSlider = new JSlider(JSlider.HORIZONTAL, 0, 50, initialValue);
		videoNavSliderPanel.add(timeSlider, BorderLayout.CENTER);
		timeSlider.addChangeListener(this);
		timeSlider.setEnabled(false); // disables while video is not loaded
		
		// ui colors
		leftPanel.setBackground(Color.GRAY);
		toolsPanel.setBackground(Color.GRAY);
		devPanel.setBackground(Color.GRAY);
		videoNavButtonsPanel.setBackground(Color.LIGHT_GRAY);
		timeSlider.setBackground(Color.LIGHT_GRAY);

		// window
		window.setTitle("Détection de personnes");
		window.setSize(1000, 725); // we can also use fenetre.pack() which narrow the window down to
								   // the minimum possible
		// fenetre.setLocationRelativeTo(null); // to center the window
		// fenetre.setUndecorated(true); // to hide window borders and control buttons
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // to stop the program when the main
															   // window is closed by the user
		window.setVisible(true);
	}

	/**
	 * adds and return a button with given text to the given JPanel. If button is already
	 * declared, you have to erase it with the return value - ex : b = addBouton("foo", panel).
	 * 
	 * @param text text contained by the button
	 * @param parent the JPanel containing the button
	 * @return the created button
	 */
	private JButton addBouton(String text, JPanel parent) {
		JButton b = new JButton(text); // create button
		b.setFont(new Font(Font.DIALOG, Font.PLAIN, 15));
		parent.add(b); // add it to the GUI parent object
		b.addActionListener(this); // listen to its events
		return (b);
	}

	/**
	 * when a button is clicked
	 */
	public void actionPerformed(ActionEvent e) {
		// tools :
		if (e.getSource().equals(loadVideo)) {
			loadVideo(FileChooser.chemin());
			timeLabel.setText(video.time());
		}
		if (e.getSource().equals(loadExempleVideo)) {
			loadVideo("test.avi");
		}

		if (e.getSource().equals(displayInterestZones)) {
			displayStat = !displayStat;
			displayImage(video.nImg());
		}
		if (e.getSource().equals(createInterestZone)) {
			pauseVideo();
			displayedImageLabel.activateClicking();
		}
		if (e.getSource().equals(resetInterestZones)) {
			displayedImageLabel.Supresszone_interet();
			displayImage(video.nImg());
		}
		if (e.getSource().equals(openDevModeWindow)) {
			DevMode devMode = new DevMode();
			devMode.setVisible(true);
			devMode.setLocation(1000,200);
		}
		// navigation :
		if (e.getSource().equals(pauseVideo)) {
			playPauseVideo();
		}
		if (e.getSource().equals(nextFrame)) {
			pauseVideo();
			if (video.hasNext()) {
				displayImage(video.getNextMat());
			}
		}
		if (e.getSource().equals(previousFrame)) {
			pauseVideo();
			if (video.hasPrev()) {
				displayImage(video.getMat(video.nImg() - 1));
			}
		}
		if (e.getSource().equals(processStatistics)) {
			List<Float> data = new ArrayList<Float>();
			List<String> l1 = new ArrayList<String>();
			List<String> l2 = new ArrayList<String>();
			l2.add("0");
			System.out.println(stat.getNBP());
			System.out.println(stat.getNameIZ());
			// TODO: Attention une fois appuyer sur le bouton il n'y a plus modification des zone d'interet pk?
			Chart g = new Chart("Nombre de Personne par Zone d'interet", "zone d'interet", "y", stat.getNBP(),
					Color.white, l2, stat.getNameIZ(), true);
			stat.addChartNbPpl(g);
			stat.showGraphique(stat.getListChartNbPpl().size()-1);
		}
		if (e.getSource().equals(firstFrame)) {
			pauseVideo();
			displayImage(video.getMat(0));
		}
		if (e.getSource().equals(lastFrame)) {
			pauseVideo();
			displayImage(video.getMat(video.size() - 1));
		}

		// Save
		if (e.getSource().equals(saveImage)) {
			pauseVideo();
			BufferedImage image = Image.Mat2bufferedImage(video.getMat(video.nImg()));
			Save.image(image);
		}
		if (e.getSource().equals(saveInterestZones)) {
			pauseVideo();
			Save.interestarea(stat.getInterestAreas());
		}

		// Load
		if (e.getSource().equals(loadInterestZones)) {
			pauseVideo();
			stat.setInterestAreas(Load.interestsarea());
			displayStat = true;
			displayImage(video.nImg());
		}

		// Detection
		if (e.getSource().equals(startDetection)) { // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
			final JDialog loading = new JDialog(window);
		    JPanel p1 = new JPanel(new BorderLayout());
		    p1.add(new JLabel("Veuillez patienter..."), BorderLayout.CENTER);
		    loading.setUndecorated(true);
		    loading.getContentPane().add(p1);
		    loading.pack();
		    loading.setLocationRelativeTo(window);
		    loading.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
		    loading.setModal(true);

		    SwingWorker<Void,Void> worker = new SwingWorker<Void,Void>()
		    {
		        @Override
		        protected Void doInBackground()
		        {
		        	tVid.runThreads(video, 0,1000);//video.size() - 1); 
					displayDetection = true;
					refreshImage();
		            return null;
		        }
		     
		        @Override
		        protected void done()
		        {
		            loading.dispose();
		        }
		    };
		    worker.execute();
		    loading.setVisible(true);
		    /*try {
		        worker.get();
		    } catch (Exception e1) {
		        e1.printStackTrace();
		    }*/
		}
		if (e.getSource().equals(stopDetection)) {
			displayDetection = false;
			refreshImage();
		}

	}

	public void stateChanged(ChangeEvent e) {
		if (!isNextFrameNumber(timeSlider.getValue() + 1))
			pauseVideo();
		if (e.getSource().equals(timeSlider) && !playPause.isPlaying()) {
			displayImage(video.getMat(timeSlider.getValue()));
		}
	}

	private void loadVideo(String chemin) {
		video = new Video(chemin);
		playPause.setVideo(video);
		// System.out.println(video.isOpened());
		// System.out.println(video.size());
		if (!video.isOpened()) {
			System.out.println(
					"Echec de l'ouverture de la video.\nAvez-vous suivi toutes les instructions au-dessus du main ?");
			return;
		}

		displayImage(video.getMat(0));

		timeSlider.setValue(0);
		timeSlider.setMinimum(0);
		timeSlider.setMaximum(video.size() - 1);
		timeSlider.setEnabled(true);
	}

	private void pauseVideo() {

		if (playPause.isPlaying()) {
			playPause.toggle();
			pauseVideo.setText("|>");
		}
	}

	private void resumeVideo() {
		if (!playPause.isPlaying()) {
			playPause.toggle();
			pauseVideo.setText("||");
		}
	}

	private void playPauseVideo() {
		playPause.toggle();
		if (playPause.isPlaying()) {
			pauseVideo.setText("||");
		} else {
			pauseVideo.setText("|>");
		}
	}

	private void displayImage(Mat image) { // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		if (image.width() == 0) {
			return;
		}
		timeLabel.setText(video.time());
		if (displayDetection && video.nImg() >= tVid.getFirstFrame() && video.nImg() <= tVid.getLastFrame()) {
			/* TODO: translate comments in English @CorentinRenault (et un conseil passes justes tvid en paramètre de
			 * Image.drawTraitement(), ça évitera de faire du code de traitement dans le GUI (genre la variable
			 * stack n'a rien à faire dans le GUI ^^') - ex : Image.drawTraitement(image, video, tVid);
			 */
			//if (tVid.getOptimised() == true) {
				//System.out.println(video.nImg());
				Image.drawTraitement(image, tVid.getPersons().get((int)Math.floor(video.nImg() / stack)  )); // get le
																									// ArrayList<Persons>
																									// de la ieme frame
				// (int)(video.nImg()/50)-1)au lieu de video.nImg() pour utiliser l'evitement de
				// redondance du code de traitement dans TraitementVideo (cf postProcessing())
				// Image.drawTraitement(i, tVid.getTraitementImage(video.nImg()));
			/*} else {
				Image.drawTraitement(image, tVid.getPersons().get(video.nImg()));
			}*/
		}

		if (displayStat) {
			Image.drawStatistique(image, stat);
		}

		BufferedImage bi = Image.Mat2bufferedImage(image);
		displayedImageLabel.setIcon(new StretchIcon(bi));
		// videoPanel.repaint();
		// fenetre.validate();

		timeSlider.setValue(video.nImg());
	}

	/**
	 * Returns true if n == (video's image number) + 1
	 * 
	 * @param n
	 * @return
	 */
	private boolean isNextFrameNumber(int n) {
		return (video.nImg() + 1 == n);
	}

	/**
	 * Displays the image number n in the GUI
	 * 
	 * @param n
	 */
	public void displayImage(int n) {
		displayImage(video.getMat(n));
	}

	/**
	 * Displays the next image of the video.
	 */
	public void displayNextImage() {
		displayImage(video.getNextMat());
	}

	/**
	 * Refresh the current displayed image.
	 */
	public void refreshImage() {
		displayImage(video.nImg());
	}

	public Video getVideo() {
		return video;
	}

	public void confirmchoice() {
		JDialog.setDefaultLookAndFeelDecorated(true);
		int response = JOptionPane.showConfirmDialog(null, "Voulez-vous créer cette zone d'interet?", "Confirmer",
				JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		if (response == JOptionPane.YES_OPTION) {

		} else if (response == JOptionPane.CLOSED_OPTION || response == JOptionPane.NO_OPTION) {
			displayedImageLabel.destroylastZI();
		}

	}

	// Statistics
	public Statistique getStat() {
		return stat;
	}

	public void setStat(Statistique stat) {
		this.stat = stat;
	}

	public void setDisplayStat(boolean displayStat) {
		this.displayStat = displayStat;
	}
	/**
	 * Fonction to add a Jlabel of given font, font size and font type
	 * @param name the text to displaye
	 * @param size the font size
	 * @param type the font type
	 * 
	 * @author Terenui Rouby
	 */
	public JLabel addLabel(String name,int size,int type)
	{
		JLabel b=new JLabel(name, JLabel.CENTER);
		b.setFont(new Font(Font.DIALOG, type, size));
		return(b);
	}
}
