package tse.JavaBienEtToi.gui.utils;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

import javax.swing.JLabel;

import org.opencv.core.Point;

import tse.JavaBienEtToi.gui.GUI;
import tse.JavaBienEtToi.statistique.Interestarea;

public class Jlabelmouse extends JLabel implements MouseListener, MouseMotionListener {

	private boolean MouseListeneractivate = false;// champ ajouté pour pouvoir cliquer
	private Interestarea z1 = new Interestarea(null, null);
	GUI gui;

	public Jlabelmouse(GUI gui) {
		super();
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
		this.gui = gui;
	}

	// Suite de méthode pour pouvoir selectionner des points dans la vidéo
	public void activateClicking() {
		MouseListeneractivate = true;
	}

	public void desactivateClicking() {
		MouseListeneractivate = false;
	}

	public void mouseClicked(MouseEvent e) {

	}

	public void mouseEntered(MouseEvent e) {

	}

	public void mouseExited(MouseEvent e) {

	}

	public void mousePressed(MouseEvent e) {
		if (MouseListeneractivate) {
			double x = (double) e.getX();
			double y = (double) e.getY();
			Point p1 = label2Point(x, y);
			z1 = new Interestarea(p1, p1);
			gui.getStat().addInterestarea(z1);
			gui.setDisplayStat(true);
		}
	}

	public void mouseReleased(MouseEvent e) {
		if (MouseListeneractivate) {
			double x = (double) e.getX();
			double y = (double) e.getY();
			Point p2 = label2Point(x, y);
			z1.setP2(p2);
			desactivateClicking();
			gui.confirmchoice();
			gui.refreshImage();
		}
	}

	public void destroylastZI() {
		gui.getStat().removelastenter();
	}

	public void Supresszone_interet() {// reset toutes les zones d'interet
		gui.getStat().setInterestAreas(new ArrayList<Interestarea>());
	}

	public void mouseDragged(MouseEvent e) {
		if (MouseListeneractivate) {
			double x = (double) e.getX();
			double y = (double) e.getY();
			Point p2 = label2Point(x, y);
			z1.setP2(p2);

			gui.refreshImage();
		}
	}

	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	/**
	 * Returns a point with coordinates representing position in the original image.
	 * 
	 * @param p
	 *            Point in the label
	 * @return Point(p.x / labelWidth, p.y / labelHeight)
	 */
	private Point label2Point(double x, double y) {

		double width = gui.getVideo().getWidth();
		double height = gui.getVideo().getHeight();

		double xGap = 0;
		double yGap = 0;

		if (this.getHeight() / height > this.getWidth() / width) {
			yGap = this.getHeight() - this.getWidth() * height / width;
		} else {
			xGap = this.getWidth() - this.getHeight() * width / height;
		}

		x = width * (x - xGap / 2) / (this.getWidth() - xGap);
		y = height * (y - yGap / 2) / (this.getHeight() - yGap);

		if (x < 0) {
			x = 0;
		} else if (x > width) {
			x = width;
		}

		if (y < 0) {
			y = 0;
		} else if (y > height) {
			y = height;
		}

		return new Point(x, y);
	}
}
