package tse.JavaBienEtToi.statistique;



import java.util.ArrayList;
import java.util.List;

import org.opencv.core.Point;

import tse.JavaBienEtToi.person.Person;

public class Interestarea {
	
	
	private Point p1;
	private Point p2;
	

	public Interestarea(Point a, Point b) {

		this.setP1(a);
		this.setP2(b);
	}

	public Point getP1() {
		return p1;
	}

	public Point getP2() {
		return p2;
	}

	public void setP1(Point point) {
		p1 = point;
	}

	public void setP2(Point point) {
		p2 = point;
	}

	public Interestarea clone() {
		return new Interestarea(p1.clone(), p2.clone());
	}

}
