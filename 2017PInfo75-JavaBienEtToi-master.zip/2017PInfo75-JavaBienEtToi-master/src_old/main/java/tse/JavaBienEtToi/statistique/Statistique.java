package tse.JavaBienEtToi.statistique;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import tse.JavaBienEtToi.person.PersonList;
import tse.JavaBienEtToi.person.Person;
import tse.JavaBienEtToi.gui.GUI;

public class Statistique  extends JPanel{
	private List<Interestarea> interestAreas = new ArrayList<Interestarea>();
	int firstframe;
	int last_frame;
//	JButton CalculStat1;
	private List<Chart> listChartNbPpl = new ArrayList<Chart>();
	private List<PersonList> listPoeple = new ArrayList<PersonList>();
	private List<String> nameIZ=new ArrayList<String>();
	
	public Statistique(int firstframe, int lastframe) {
		super();
		this.firstframe = firstframe;
		this.last_frame = lastframe;
		
	}
	public void addChartNbPpl(Chart e)
	{
		getListChartNbPpl().add(e);
	}
	public void showGraphique(int i)
	{
		JFrame windowchart = new JFrame();
		windowchart.setLocation(1000,200);
		windowchart.add(getListChartNbPpl().get(i));
		windowchart.setTitle("Calculstatistique");
		windowchart.setSize(900, 725);
		windowchart.setDefaultCloseOperation(windowchart.DISPOSE_ON_CLOSE);
		windowchart.setVisible(true);
	}

	public List<Interestarea> getInterestAreas() {
		return interestAreas;
	}

	public void setInterestAreas(List<Interestarea> interestareas) {
		this.interestAreas = interestareas;
	}

	public void addInterestarea(Interestarea z) {
		interestAreas.add(z);
		// TODO temporaire en attendant la méthode qui créé une liste de personne pour chaque zone d'interet
		PersonList lp=new PersonList();
		listPoeple.add(lp);
		nameIZ.add("Z"+interestAreas.size());
	}
	public void removelastenter() {
		interestAreas.remove(interestAreas.size()-1);
	}
	public List<PersonList> getListPoeple() {
		return listPoeple;
	}
	public void setListPersons(List<PersonList> listPoeple) {
		this.listPoeple = listPoeple;
	}
	
	public List<Float> getNBP(){
		List<Float> listNBP=new ArrayList<Float>();
		if (listPoeple.isEmpty()){
			listNBP.add((float) 0);
		}
		else {
			for (PersonList p:listPoeple) {
				listNBP.add((float) p.size());
			}
		}
		return(listNBP);
	}

	public List<String> getNameIZ() {
		return nameIZ;
	}
	public void setNameIZ(List<String> nameIZ) {
		this.nameIZ = nameIZ;
	}
	public List<Chart> getListChartNbPpl() {
		return listChartNbPpl;
	}
	public void setListChartNbPpl(List<Chart> listChartNbPpl) {
		this.listChartNbPpl = listChartNbPpl;
	}

	
	}

