package tse.JavaBienEtToi.processing;

import java.util.ArrayList;

import tse.JavaBienEtToi.person.PersonList;
import tse.JavaBienEtToi.video.Video;

public class ProcessingThread extends Thread {
	Video vid;
	int firstFrame;
	int lastFrame;
	VideoProcessing vidProcessing;

	public ProcessingThread(Video vid, int firstFrame, int lastFrame) {
		this.vid = vid;
		this.firstFrame = firstFrame;
		this.lastFrame = lastFrame;
	}

	public void run() {
		vidProcessing = new VideoProcessing(vid.clone(), firstFrame, lastFrame);
	}

	public ArrayList<PersonList> getPersons() {
		return vidProcessing.getPersons();
	}
}
