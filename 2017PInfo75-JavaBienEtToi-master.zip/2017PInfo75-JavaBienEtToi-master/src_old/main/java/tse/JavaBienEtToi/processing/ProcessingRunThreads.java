package tse.JavaBienEtToi.processing;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import tse.JavaBienEtToi.person.PersonList;
import tse.JavaBienEtToi.video.Video;

public class ProcessingRunThreads {
	ArrayList<PersonList> persons;
	int firstFrame = 0;
	int lastFrame = 0;

	public ProcessingRunThreads() {
		this.persons = new ArrayList<PersonList>();
	}

	public void runThreads(Video video, int firstFrame, int lastFrame) {
		this.firstFrame = firstFrame;
		this.lastFrame = lastFrame;

		long start = System.currentTimeMillis();

		this.persons = new ArrayList<PersonList>();
		int threadNumber = Runtime.getRuntime().availableProcessors();
		System.out.println("Thread number : " + threadNumber);
		int firstFrame2 = firstFrame;
		int lastFrame2 = (lastFrame - firstFrame) / threadNumber + firstFrame2;
		int[] framesDistribution = new int[threadNumber * 2];

		for (int i = 0; i < threadNumber; i++) {
			framesDistribution[i] = firstFrame2;
			framesDistribution[i + 1] = lastFrame2;
			firstFrame2 = lastFrame2 + 1;
			lastFrame2 = (lastFrame - firstFrame) / threadNumber + firstFrame2;
			if (lastFrame2 > lastFrame) {
				lastFrame2 = lastFrame;
				if (firstFrame2 > lastFrame) {
					firstFrame2 = lastFrame;
				}
			}
		}

		ExecutorService service = Executors.newFixedThreadPool(threadNumber);
		ProcessingThread[] processing = new ProcessingThread[threadNumber];

		for (int i = 0; i < threadNumber; i++) {
			processing[i] = new ProcessingThread(video, framesDistribution[i], framesDistribution[i + 1]);
			service.execute(processing[i]);
		}

		// Finish
		shutdownAndAwaitTermination(service);

		for (int i = 0; i < threadNumber; i++) {
			persons.addAll(processing[i].getPersons());
		}

		long last = System.currentTimeMillis();
		System.out.println(last - start);
	}

	public ArrayList<PersonList> getPersons() {
		return persons;
	}

	public int getFirstFrame() {
		return firstFrame;
	}

	public int getLastFrame() {
		return lastFrame;
	}

	/**
	 * Good practice: code imported from Oracle example
	 * 
	 * @param pool
	 */
	static void shutdownAndAwaitTermination(ExecutorService pool) {
		pool.shutdown(); // Disable new tasks from being submitted
		try {
			// Wait a while for existing tasks to terminate
			if (!pool.awaitTermination(60, TimeUnit.SECONDS)) {
				pool.shutdownNow(); // Cancel currently executing tasks
				// Wait a while for tasks to respond to being cancelled
				if (!pool.awaitTermination(60, TimeUnit.SECONDS))
					System.err.println("Pool did not terminate");
			}
		} catch (InterruptedException ie) {
			// (Re-)Cancel if current thread also interrupted
			pool.shutdownNow();
			// Preserve interrupt status
			Thread.currentThread().interrupt();
		}
	}
}
