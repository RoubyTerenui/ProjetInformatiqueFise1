package tse.JavaBienEtToi.processing;




import java.util.ArrayList;
import java.util.List;

import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Size;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;
import org.opencv.objdetect.Objdetect;

import tse.JavaBienEtToi.person.Person;
import tse.JavaBienEtToi.person.PersonList;

//https://docs.opencv.org/2.4.13.2/modules/objdetect/doc/cascade_classification.html?highlight=haartraining
public class ImageProcessing implements Runnable{
 


	
	
	
	private int hMin=5;//20;// taille minimale des personnes sur la video ( en pixel je suppose ? )
	

	private ArrayList<Person> persons= new ArrayList<Person>();
	private int detectedPersons=0;



	
	

	public int getDetectedPersons() {
		return detectedPersons;
	}
	
	public void finalize(){
		//System.out.println("nettoyé");
	}


	public ImageProcessing(Mat image, ArrayList<ArrayList<Double>> mask, int frameIndice, String cascadeType) {
		
		run();
		
		Mat grayFrame= new Mat();
		MatOfRect positions = new MatOfRect();
		//<-- RETIRER /* POUR UTILISER LE HAAR CASCADE CLASSIFIER
		// First of all we need to convert the frame in grayscale 
		Imgproc.cvtColor(image, grayFrame, Imgproc.COLOR_BGR2GRAY);
		// and equalize the histogram																																																												 to improve the results:
		Imgproc.equalizeHist(grayFrame, grayFrame);
		

		// load xml file des personnes ou this.cascade.load(xmlClassifier);
		//haarcascade_fullbody.xml
		//private CascadeClassifier cascade= new CascadeClassifier("cheminDAccesDuFileXML");
		
		
		
		CascadeClassifier cascade= new CascadeClassifier("classifieurs/data/haarcascades/haarcascade_"+cascadeType+".xml");
		
		
		
		
		//Now we can start the detection: ( returns a list of rectangles )
		cascade.detectMultiScale(grayFrame, positions, 1.01, 10, 0 | Objdetect.CASCADE_SCALE_IMAGE, new Size(hMin*4, hMin*4), new Size(25*hMin,25*hMin));
		//new Size(hMin*4, hMin*4), new Size(25*hMin,25*hMin));
		//Size(hMin, hMin), new Size(5*hMin,5*hMin));
		
		
		
		Rect[] temp = positions.toArray();
		/*if (frameIndice %50==0)
			System.out.println(frameIndice); // affichage*/
		for (int i = 0; i < temp.length; i++) {
			Point p1=temp[i].tl();
			Point p2=temp[i].br();
			
			Long L = Math.round(p1.x);
			int x1 = Integer.valueOf(L.intValue());
			
			Long L2 = Math.round(p1.y);
			int y1 = Integer.valueOf(L2.intValue());
			
			Long L3 = Math.round(p2.x);
			int x2 = Integer.valueOf(L3.intValue());
			
			Long L4 = Math.round(p2.y);
			int y2 = Integer.valueOf(L4.intValue());
			
			
			
			try {
				/*if (    (mask.get(y1,x1)[0]) * (mask.get(y2,x2)[0])!=0 ) {		// si un des coins est dans le masque		
					
	
					detectedPersons+=1;
					persons.add(new Person((int)p1.x, (int)p1.y, (int)(p2.x-p1.x),  (int)(p2.y-p1.y), frameIndice));
				}*/
				//.out.println("mask "+mask.size()+"mask "+mask.get(0).size());
				//System.out.println(x1);
				//System.out.println(y1);
				if (x1>0 && y1>0 && x2>0 && y2>2 && x1<mask.size() && x2<mask.size() && y1<mask.get(0).size() && y2<mask.get(0).size()) {
					if (    (mask.get(x1).get(y1)) * (mask.get(x2).get(y2))!=0 ) {		// si un des coins est dans le masque		
						
						
						detectedPersons+=1;
						persons.add(new Person((int)p1.x, (int)p1.y, (int)(p2.x-p1.x),  (int)(p2.y-p1.y), frameIndice));
					}
				}
			} catch (NullPointerException e) {
				System.out.print("NullPointerException caught");
			}
			
		}
		grayFrame.release(); // pour liberer la memoire via le garbage collector
		
		positions.release();

		
		
	}
	
	
public ImageProcessing(Mat image, ArrayList<ArrayList<Double>> mask, int frameIndice, ArrayList<CascadeClassifier> cascadeList) {
		
		
		
		Mat grayFrame= new Mat();
		MatOfRect positions = new MatOfRect();
		
		// First of all we need to convert the frame in grayscale 
		Imgproc.cvtColor(image, grayFrame, Imgproc.COLOR_BGR2GRAY);
		// and equalize the histogram																																																												 to improve the results:
		Imgproc.equalizeHist(grayFrame, grayFrame);
		

		// load xml file des personnes ou this.cascade.load(xmlClassifier);
		//haarcascade_fullbody.xml
		//private CascadeClassifier cascade= new CascadeClassifier("cheminDAccesDuFileXML");
		
		//ArrayList<Double> weights=new ArrayList<Double>();
		//ArrayList<Integer> levels=new ArrayList<Integer>();
		Rect[] temp;
		Rect[] posArray= new Rect[0];
		int x=0;
		//Now we can start the detection: ( returns a list of rectangles )
		double scaleFactor=1.05;
		for (int i=0; i<cascadeList.size()-1; i++ ) {
			cascadeList.get(i).detectMultiScale(grayFrame, positions, scaleFactor, 4, 0 | Objdetect.CASCADE_SCALE_IMAGE, new Size(hMin*4/scaleFactor, hMin*4/scaleFactor), new Size(25*hMin/2,25*hMin));
			
			//cascadeList.get(i).detectMultiScale(grayFrame, positions, levels, weights, 1.01, 4, 0 | Objdetect.CASCADE_SCALE_IMAGE, new Size(hMin*4, hMin*4), new Size(25*hMin/2,25*hMin), true);
			
			temp= new Rect[posArray.length];
			for (int k=0; k<posArray.length; k++ ){
				temp[k]=posArray[k]; 
				// on met posTab dans temp avant de changer la taille de posTab
			} // en gros temp=posTab
			
			posArray = new Rect[temp.length+ positions.toArray().length];
			x=temp.length;
			for (int k=0; k<temp.length; k++ ){
				posArray[k]=temp[k]; 
				// on recree posTab et on lui ajoute les positions qu'il avait dans l'iteration d'avant
			}// en gros posTab = [ posTab d'avant + du vide]
			
			
			temp= positions.toArray();
			for (int k=0; k<temp.length; k++ ){
				
				posArray[k+x]=temp[k];
				// puis on rajoute les nouvelles
			}// en gros posTab =[ posTab d'avant + new positions ]
			
			//weights.clear();
			//levels.clear();
		}
		
		if (frameIndice %50==0)
			System.out.println(frameIndice); // affichage*/
		for (int i = 0; i < posArray.length; i++) {
			Point p1=posArray[i].tl();
			Point p2=posArray[i].br();
			
			Long L = Math.round(p1.x);
			int x1 = Integer.valueOf(L.intValue());
			
			Long L2 = Math.round(p1.y);
			int y1 = Integer.valueOf(L2.intValue());
			
			Long L3 = Math.round(p2.x);
			int x2 = Integer.valueOf(L3.intValue());
			
			Long L4 = Math.round(p2.y);
			int y2 = Integer.valueOf(L4.intValue());
			
			
			
			try {
				if (x1>0 && y1>0 && x2>0 && y2>2 && x1<mask.size() && x2<mask.size() && y1<mask.get(0).size() && y2<mask.get(0).size()) {
					if (    (mask.get(x1).get(y1)) * (mask.get(x2).get(y2))!=0 ) {		// si un des coins est dans le masque		
						
						
						detectedPersons+=1;
						persons.add(new Person((int)p1.x, (int)p1.y, (int)(p2.x-p1.x),  (int)(p2.y-p1.y), frameIndice));
					}
				}
			} catch (NullPointerException e) {
				System.out.print("NullPointerException caught");
			}
			
		}
		grayFrame.release(); // pour liberer la memoire via le garbage collector
		
		positions.release();

		
		
	}
 

	public PersonList getPersons() {
		PersonList pl=new PersonList(persons);
		return pl;
	}

	public void run() {
		// TODO Auto-generated method stub
		
	}


	
	


}