package tse.JavaBienEtToi.processing;


import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

import tse.JavaBienEtToi.person.Person;
import tse.JavaBienEtToi.person.PersonList;
import tse.JavaBienEtToi.processing.ImageProcessing;

public class TestImageProcessing extends ImageProcessing implements ActionListener{
	 
	
	private static Mat img;
	private static Mat originalImg;
	
	private static ArrayList<ArrayList<Double>> maskClone= new ArrayList<ArrayList<Double>>();
	
	
	// UI elements
	JFrame window = new JFrame();
	JPanel mainPanel, toolsPanel, imagePanel;
	JButton fullBody, upperBody, lowerBody, frontalFace, profileFace;
	JLabel displayedImage = new JLabel();
	
	
	
	public static void main(String[] args) {
		System.loadLibrary("opencv_java331");
		img =Imgcodecs.imread("./imagesTest/2.JPG" );
		originalImg=img.clone();
		
		// mask that allow us to validate ( or rather deny positions that are impossible )
		Mat mask =Imgcodecs.imread("./imagesTest/mask-hallmetro.png" );
		setMaskClone(mask);	
		new TestImageProcessing(img, maskClone, 0, "frontalface_default");
	}
	
	private static void setMaskClone(Mat mask) {
		Size a=mask.size();
		for (int i=0; i<a.width; i++) {
			ArrayList<Double> temp= new ArrayList<Double>();
			for (int j=0; j<a.height; j++) {
				
				double[] t= new double[1];
				t=mask.get(j,i);
				temp.add(t[0]);
				//System.out.println(i);
				//System.out.println(mask.get(893)[0]);
				//System.out.println(temp.get(j));
			}
			maskClone.add(temp);
			temp.clear();
		}
	}
	
	public TestImageProcessing(Mat image, ArrayList<ArrayList<Double>> mask, int frameIndice, String cascadeType) {
		super(image, mask, frameIndice, cascadeType);

		
		//traitement.affichePositions();
		PersonList persons=this.getPersons();
		for (int i = 0; i < persons.size(); i++)
			Imgproc.rectangle(image, new Point(persons.get(i).getX(), persons.get(i).getY()), new Point(persons.get(i).getX()+persons.get(i).getWidth(), persons.get(i).getY()+persons.get(i).getHeight()), new Scalar(0, 255, 0, 255), 3);
		
		/*// First of all we need to convert the frame in grayscale 
		Imgproc.cvtColor(image, image, Imgproc.COLOR_BGR2GRAY);
		// and equalize the histogram to improve the results:
		Imgproc.equalizeHist(image, image);//*/
		
		BufferedImage bI=Mat2BufferedImage(image);
		displayImage(bI);//*/
		
	}

	
	private JButton ajouterBouton(String texte, JPanel parent) {
		JButton b = new JButton(texte); // create button
		parent.add(b); // add it to the GUI parent object
		b.addActionListener(this); // listen to its events
		return(b);
	}//*/
	
	public void actionPerformed(ActionEvent e) {
		String cascadeType;
		if (e.getSource().equals(frontalFace)) {
			cascadeType = new String("frontalface_alt");
		}
		else if (e.getSource().equals(profileFace)) {
			cascadeType = new String("profileface");
		}
		else if (e.getSource().equals(upperBody)) {
			cascadeType = new String("upperbody");
		}
		else if (e.getSource().equals(lowerBody)) {
			cascadeType = new String("lowerbody");
		}
		else if (e.getSource().equals(fullBody)) {
			cascadeType = new String("fullbody");
		}
		else { cascadeType = new String("frontalface_alt2"); }
		
		img=originalImg.clone();
		// mask that allow us to validate ( or rather deny positions that are impossible )
		Mat mask =Imgcodecs.imread("./imagesTest/mask-hallmetro.png" );
		setMaskClone(mask);
		new TestImageProcessing(img, maskClone, 0, cascadeType);
		
		//*/

		// TODO : sélecteur d'image
	}
	
	// SOURCE: http://answers.opencv.org/question/31505/how-load-and-display-images-with-java-using-opencv-solved/
	public BufferedImage Mat2BufferedImage(Mat m){
		// source: http://answers.opencv.org/question/10344/opencv-java-load-image-to-gui/
		// Fastest code
		// The output can be assigned either to a BufferedImage or to an Image

		    int type = BufferedImage.TYPE_BYTE_GRAY;
		    if ( m.channels() > 1 ) {
		        type = BufferedImage.TYPE_3BYTE_BGR;
		    }
		    int bufferSize = m.channels()*m.cols()*m.rows();
		    byte [] b = new byte[bufferSize];
		    m.get(0,0,b); // get all the pixels
		    BufferedImage image = new BufferedImage(m.cols(),m.rows(), type);
		    final byte[] targetPixels = ((DataBufferByte) image.getRaster().getDataBuffer()).getData();
		    System.arraycopy(b, 0, targetPixels, 0, b.length);  
		    return image;

	}
	
	// SOURCE: http://answers.opencv.org/question/31505/how-load-and-display-images-with-java-using-opencv-solved/
	 public void displayImage(Image img2)
	 {   
		 
		
		
	    ImageIcon icon=new ImageIcon(img2);
	     
	     // main panel
	    mainPanel = new JPanel();
	    mainPanel.setLayout(new FlowLayout());            
	    window.add(mainPanel);
	     
	    // image panel
		imagePanel = new JPanel();
		mainPanel.add(imagePanel, BorderLayout.CENTER);
		imagePanel.setLayout(new BorderLayout());
		imagePanel.add(displayedImage);
	     
	     // tools panel
		toolsPanel = new JPanel();
		toolsPanel.setLayout(new BoxLayout(toolsPanel, BoxLayout.Y_AXIS)); // le tout sera ordonné verticalement
		mainPanel.add(toolsPanel, BorderLayout.WEST);
		frontalFace = ajouterBouton("frontalFace", toolsPanel);
		upperBody = ajouterBouton("upperBody", toolsPanel);
		fullBody = ajouterBouton("fullBody", toolsPanel);
		lowerBody = ajouterBouton("lowerBody", toolsPanel);
		profileFace = ajouterBouton("profileFace", toolsPanel);
		toolsPanel.setBackground(Color.LIGHT_GRAY);
			
	    window.setSize(img2.getWidth(null)+200, img2.getHeight(null)+50); 
	     
	    displayedImage.setIcon(icon);
	    window.setVisible(true);
	 	window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	 }

	 public void personnePasTropLoin(MatOfRect positions) {
		 Rect[] truePos=positions.toArray();
		 PersonList detectedPos= this.getPersons();
		 for (int i=0; i<max(truePos.length,detectedPos.size()); i++) {
			 
		 }
	 }
	 
	 public int max(int a, int b) {
		 return a>b ? a : b;
	 }
	

}
