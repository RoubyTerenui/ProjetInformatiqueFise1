package tse.JavaBienEtToi.image;

import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;

import tse.JavaBienEtToi.gui.utils.Jlabelmouse;
import tse.JavaBienEtToi.person.Person;
import tse.JavaBienEtToi.person.PersonList;
import tse.JavaBienEtToi.processing.ImageProcessing;
import tse.JavaBienEtToi.statistique.Interestarea;
import tse.JavaBienEtToi.statistique.Statistique;

/**
 * 
 * @author Baptiste Wolff
 *
 */
public class Image {
	/**
	 * Transforms any Mat into a BufferedImage
	 * 
	 * @param in
	 *            Mat
	 * @param width
	 * @param height
	 * @return BufferedImage
	 */
	public static BufferedImage Mat2bufferedImage(Mat in) {
		int width = in.width();
		int height = in.height();
		BufferedImage out;
		Mat in2 = new Mat();
		Imgproc.cvtColor(in, in2, Imgproc.COLOR_RGB2BGR);
		byte[] data = new byte[width * height * (int) in2.elemSize()];
		int type;
		in2.get(0, 0, data);

		if (in2.channels() == 1)
			type = BufferedImage.TYPE_BYTE_GRAY;
		else
			type = BufferedImage.TYPE_3BYTE_BGR;

		out = new BufferedImage(width, height, type);

		out.getRaster().setDataElements(0, 0, width, height, data);
		return out;

	}

	/**
	 * Draws rectangles representing the peoples on a Mat and returns a buffered
	 * image of this Mat
	 * 
	 * @param image
	 * @param traitementImage
	 * @return BufferedImage
	 */
	/*public static BufferedImage Mat2BufferedImage(Mat image, TraitementImage traitementImage) {
		drawTraitement(image, traitementImage);
		return Mat2bufferedImage(image);
	}*/
	
	public static BufferedImage Mat2BufferedImage(Mat image, ArrayList<Person> persons) {
		drawTraitement(image, persons);
		return Mat2bufferedImage(image);
	}

	/**
	 * Draws rectangles representing 'zoneInteret' on a Mat and returns a buffered
	 * image of this Mat
	 * 
	 * @param image
	 * @param statistique
	 * @return
	 */
	public static BufferedImage Mat2BufferedImage(Mat image, Statistique statistique) {
		drawStatistique(image, statistique);
		return Mat2bufferedImage(image);
	}

	/**
	 * Draws rectangles representing the peoples and 'zoneInteret' in a Mat and
	 * returns a buffered image of this Mat
	 * 
	 * @param image
	 * @param traitementImage
	 * @param statistique
	 * @return
	 */
	/*public static BufferedImage Mat2BufferedImage(Mat image, TraitementImage traitementImage, Statistique statistique) {
		drawStatistique(image, statistique);
		drawTraitement(image, traitementImage);
		return Mat2bufferedImage(image);
	}*/

	/**
	 * Draws rectangles representing the peoples on a Mat
	 * 
	 * @param image
	 * @param personList
	 */
	public static void drawTraitement(Mat image, PersonList personList) {
		//PersonList persons = personList.getPersons();
		for (int i = 0; i < personList.size(); i++) {
			Imgproc.rectangle(image, new Point(personList.get(i).getX(), personList.get(i).getY()), new Point(personList.get(i).getX()+personList.get(i).getWidth(), personList.get(i).getY()+personList.get(i).getHeight()), new Scalar(0, 255, 0, 255), 1);
		}
	}
	
	
	
	/**
	 * Draws rectangles representing the peoples on a Mat
	 * 
	 * @param image
	 * @param traitementImage
	 */
	public static void drawTraitement(Mat image, ArrayList<Person> persons) {
	 
		for (int i = 0; i < persons.size(); i++) {
			Imgproc.rectangle(image, new Point(persons.get(i).getX(), persons.get(i).getY()), new Point(persons.get(i).getX()+persons.get(i).getWidth(), persons.get(i).getY()+persons.get(i).getHeight()), new Scalar(0, 255, 0, 255), 3);
		}
	}

	/**
	 * Draws rectangles representing 'zoneInteret' on a Mat
	 * 
	 * @param image
	 * @param statistique
	 */
	public static void drawStatistique(Mat image, Statistique statistique) {
		List<Interestarea> zoneInteret = statistique.getInterestAreas();
		for (int i = 0; i < zoneInteret.size(); i++) {
			Point p1 = zoneInteret.get(i).getP1();
			Point p2 = zoneInteret.get(i).getP2();
			Imgproc.rectangle(image, p1, p2, new Scalar(255, 0, 0, 255), 3);
		}
	}
}
