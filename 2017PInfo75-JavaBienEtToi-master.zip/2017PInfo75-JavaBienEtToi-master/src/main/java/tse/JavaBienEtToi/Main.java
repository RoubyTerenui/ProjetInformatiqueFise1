package tse.JavaBienEtToi;

import tse.JavaBienEtToi.gui.GUI;
import tse.JavaBienEtToi.image.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.videoio.VideoCapture;

/**
 * Project main. Please install OpenCV before running (see bellow).
 * 
 * @author Baptiste Wolff
 */
public class Main {

	// Some documentation for OpenCV :
	// https://docs.opencv.org/2.4/doc/tutorials/introduction/java_eclipse/java_eclipse.html
	// https://stackoverflow.com/questions/34113240/eclipse-adding-a-class-path-variable-library-to-eclipse-preferences-vs-adding-a

	/*
	 * installing openCV on a new project : 1) follow theses instructions :
	 * https://docs.opencv.org/3.0-beta/doc/tutorials/introduction/java_eclipse/java_eclipse.html
	 * 2) add YOUR_INSTAL_FOLDER\opencv\build\x64\vc14\bin to the PATH
	 */
	/**
	 * Project entry point
	 * 
	 * @param args command-line arguments (not used here)
	 */
	public static void main(String[] args) {
		System.loadLibrary("opencv_java331");
		new GUI();
	}

	/**
	 * test openCV : displays a matrix 3x3 in the console.
	 */
	public static void testOpenCV() {
		Mat mat = Mat.eye(3, 3, CvType.CV_8UC1);
		System.out.println("mat = " + mat.dump());
	}

	/**
	 * test openCV : displays a video.
	 */
	public static void testOpenCV2() {
		Mat frame = new Mat();
		VideoCapture camera = new VideoCapture("test_2.mp4");
		System.out.println(camera.isOpened());
		JFrame jframe = new JFrame("Title");
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JLabel vidpanel = new JLabel();
		jframe.setContentPane(vidpanel);
		jframe.setVisible(true);

		while (true) {
			if (camera.read(frame)) {

				ImageIcon image = new ImageIcon(Image.Mat2bufferedImage(frame));
				vidpanel.setIcon(image);
				vidpanel.repaint();

			}
		}
	}
}
