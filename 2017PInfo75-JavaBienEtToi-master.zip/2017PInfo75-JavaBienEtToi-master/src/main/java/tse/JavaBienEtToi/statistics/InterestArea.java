package tse.JavaBienEtToi.statistics;

import java.util.ArrayList;
import java.util.List;

import org.opencv.core.Point;

import tse.JavaBienEtToi.person.Person;
import tse.JavaBienEtToi.person.PersonList;
import tse.JavaBienEtToi.person.PersonVideo;
import tse.JavaBienEtToi.processing.VideoProcessingData;

/**
 * Class used to define an Interest Area
 *
 * @author Rouby Terenui
 * @author Baptiste Wolff
 */
public class InterestArea {
	private float meanTime = 0;
	/** p1:First point that correspond to the top-left corner of the rectangle */
	private Point p1;
	/**
	 * p2:Second point that correspond to the bottom-right corner of the rectangle
	 */
	private Point p2;

	/**
	 * Total number of people for each image in the interest area.
	 */
	int[] peopleNumber = new int[0];

	/**
	 * The first and last fram that have been under process
	 */
	// int firstFrame = 0, lastFrame = 0;

	/**
	 * Average number of people in the interest area for the whole video.
	 */
	float averagePeopleNumber = 0;

	String name = "Interest area";

	/**
	 * Returns the number of people for a specific frame of the video.
	 * 
	 * @param frameNumber
	 * @return the number of people.
	 */
	public int getPeopleNumber(int frameNumber) {
		if (frameNumber > peopleNumber.length - 1) {
			return 0;
		} else {
			return peopleNumber[frameNumber];
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public float getAveragePeopleNumber() {
		return averagePeopleNumber;
	}

	/**
	 * Class constructor.
	 * 
	 * @param a
	 * @param b
	 */
	public InterestArea(Point a, Point b) {
		this.setP1(a);
		this.setP2(b);
	}

	public float getMeanTime() {
		return meanTime;
	}

	public Point getP1() {
		return p1;
	}

	public Point getP2() {
		return p2;
	}

	public void setP1(Point point) {
		p1 = point;
	}

	public void setP2(Point point) {
		p2 = point;
	}

	/** Copy the current Interest area on a new one */
	public InterestArea clone() {
		return new InterestArea(p1.clone(), p2.clone());
	}

	/**
	 * Count how many people were on the video between two given frames of the
	 * video.
	 * 
	 * @param videoProcessing
	 * @param firstFrame
	 * @param lastFrame
	 * @return people count
	 */
	public int countPeople(VideoProcessingData videoProcessing, int firstFrame, int lastFrame) {
		PersonVideo persons = videoProcessing.getPersons();
		int peopleNumber = persons.get(firstFrame).size();

		for (int i = firstFrame + 1; i < lastFrame; i++) {
			PersonList personListPrevious = persons.get(i - 1);
			PersonList personListCurrent = persons.get(i);

			for (int j = 0; j < personListCurrent.size(); j++) {
				Person currentPerson = personListCurrent.get(j);
				// First : check if the person is in the interest area
				if (currentPerson.isInInterestZone(this)) {
					// Then we check if the person correspond to a person on the previous frame of
					// the video
					boolean collision = false;
					for (int k = 0; k < personListPrevious.size(); k++) {
						InterestArea currentPersonArea = new InterestArea(currentPerson.getP1(), currentPerson.getP2());
						if (personListPrevious.get(k).isInInterestZone(currentPersonArea)) {
							collision = true;
							break;
						}
					}
					if (!collision) {
						peopleNumber++;
					}
				}
			}
		}
		return (peopleNumber);
	}

	/**
	 * Counts the people which are in the interest area for each image of the video
	 * and saves it.
	 * 
	 * @author Baptiste Wolff
	 * @param videoProcessing
	 */
	public void setPeopleNumber(VideoProcessingData videoProcessing) {
		PersonVideo persons = videoProcessing.getPersons();
		int totalPeopleNumber = 0;
		peopleNumber = new int[persons.size()];

		int firstFrame = videoProcessing.getFirstFrame();
		int lastFrame = videoProcessing.getLastFrame();
		for (int i = 0; i < persons.size(); i++) {
			PersonList personList = persons.get(i);
			peopleNumber[i] = 0;

			for (int j = 0; j < personList.size(); j++) {
				Person person = personList.get(j);
				if (person.isInInterestZone(this)) {
					peopleNumber[i]++;
					totalPeopleNumber++;
				}
			}
		}
		if (lastFrame - firstFrame > 0) {
			averagePeopleNumber = (float) totalPeopleNumber / (float) (lastFrame - firstFrame);
		} else {
			averagePeopleNumber = totalPeopleNumber;
		}
	}

	/**
	 * Calculate the mean Time a person spends in the interest Area. The method used
	 * is the following:Each time the number of people change in the interest Area
	 * the time is reset to 0
	 * 
	 * @author Rouby Terenui
	 * @param videoProcessing
	 */
	public void setMeanTime(VideoProcessingData videoProcessing) {
		int firstFrame = videoProcessing.getFirstFrame() + 1;
		int lastFrame = videoProcessing.getLastFrame();
		List<Integer> nbrFrameWithoutChange = new ArrayList<Integer>();
		int k = 0;
		nbrFrameWithoutChange.add(0);
		for (int i = firstFrame; i < lastFrame; i++) {
			if (peopleNumber[i] > 0) {
				if (peopleNumber[i - 1] == peopleNumber[i]) {
					nbrFrameWithoutChange.set(k, nbrFrameWithoutChange.get(k) + 1);
				}
			} else {
				nbrFrameWithoutChange.add(0);
				k++;
			}
		}
		float mean = 0;
		for (int j = 0; j <= k; j++) {
			mean += nbrFrameWithoutChange.get(j);
		}
		meanTime = mean / (k + 1);
	}
}
