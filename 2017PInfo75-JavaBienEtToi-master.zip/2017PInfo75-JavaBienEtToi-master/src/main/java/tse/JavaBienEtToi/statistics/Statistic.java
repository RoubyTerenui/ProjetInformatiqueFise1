package tse.JavaBienEtToi.statistics;

import java.awt.Color;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;

import tse.JavaBienEtToi.processing.VideoProcessingData;

/**
 * Class used to Calculate all the statistics usefull to the users
 * 
 *
 * @author Rouby Terenui
 * @author Baptiste Wolff
 */
public class Statistic extends JPanel {
	/** interestAreas : The list of InterestArea defined by the user */
	private List<InterestArea> interestAreas = new ArrayList<InterestArea>();

	/**
	 * listChartNbPpl : the list of the Chart which correspond to different
	 * statistics
	 */
	private List<Chart> listChartNbPpl = new ArrayList<Chart>();

	public Statistic() {
		super();
	}

	/**
	 * add a char to ListChartNbPpl
	 * 
	 * @param e
	 */
	public void addChartNbPpl(Chart e) {
		getListChartNbPpl().add(e);
	}

	/**
	 * Open a new Jframe and display the chart choosen
	 * 
	 * @param i:Index
	 *            of the chart in ListChartNbPpl you want to display
	 */
	public void showGraphique(int i) {
		// On utilise Graphics Environment pour pouvoir adapter la taille des fenetre en
		// fonction des écrans
		// get local graphics environment
		GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
		// get maximum window bounds
		Rectangle maximumWindowBounds = graphicsEnvironment.getMaximumWindowBounds();

		JFrame windowchart = new JFrame();
		windowchart.setLocation((int) Math.round(maximumWindowBounds.getWidth() * 0.5), 0);
		windowchart.add(getListChartNbPpl().get(i));
		windowchart.setTitle("Calcul statistique");
		windowchart.setSize((int) Math.round(maximumWindowBounds.getWidth() * 0.5),
				(int) Math.round(maximumWindowBounds.getHeight()));
		windowchart.setDefaultCloseOperation(windowchart.DISPOSE_ON_CLOSE);
		windowchart.setVisible(true);
	}

	/**
	 * 
	 * @return The interest areas
	 */
	public List<InterestArea> getInterestAreas() {
		return interestAreas;
	}

	/**
	 * 
	 * @param interestareas
	 */
	public void setInterestAreas(List<InterestArea> interestareas) {
		this.interestAreas = interestareas;
	}

	/**
	 * Add an interest area
	 * 
	 * @param iz
	 *            :the interest area you want to add
	 */
	public void addInterestarea(InterestArea iz) {
		interestAreas.add(iz);
		interestAreas.get(interestAreas.size() - 1).setName("Z" + interestAreas.size());
	}

	/**
	 * remove the last Interest Area added to interestAreas
	 */
	public void removelastenter() {
		interestAreas.remove(interestAreas.size() - 1);
	}

	/**
	 * Returns the average number of people per minute in each area.
	 * 
	 * @return list containing the average number of people per minute
	 */
	public List<Float> getNBP() {
		List<Float> listNBP = new ArrayList<Float>();
		if (interestAreas.size() == 0) {
			listNBP.add((float) 0);
		} else {
			for (int i = 0; i < interestAreas.size(); i++) {
				listNBP.add(interestAreas.get(i).getAveragePeopleNumber());
			}
		}
		return (listNBP);
	}

	/**
	 * 
	 * @return the list of Interest areas name
	 */
	public List<String> getNameIZ() {
		List<String> nameList = new ArrayList<String>();
		for (int i = 0; i < interestAreas.size(); i++) {
			nameList.add(interestAreas.get(i).getName());
		}
		return nameList;
	}

	/**
	 * 
	 * @return the listChartNbPpl
	 */
	public List<Chart> getListChartNbPpl() {
		return listChartNbPpl;
	}

	/**
	 * Define the listChartNbPpl that contains all the chart asked by the user by a
	 * defined List of chart
	 * 
	 * @param listChartNbPpl
	 */
	public void setListChartNbPpl(List<Chart> listChartNbPpl) {
		this.listChartNbPpl = listChartNbPpl;
	}

	/**
	 * Process the statistics by counting peoples in each interest area. This also
	 * sets a graphic of the number of people in each interest Area for each minute
	 * proccessed to be displayed later.
	 * 
	 * @param videoProcessing:Data
	 * @author Baptiste Wolff
	 * @author Terenui Rouby
	 */
	public void processStatsNumberPeoplMin(VideoProcessingData videoProcessing) {

		int firstFrame = videoProcessing.getFirstFrame();
		int lastFrame = videoProcessing.getLastFrame();

		List<String> minutes = new ArrayList<String>(); // List containing the minutes
		int minutesSize = ((int) Math.ceil((lastFrame - firstFrame) / (videoProcessing.getFps() * 60)));

		List<Float> peopleNumber = new ArrayList<Float>();
		lastFrame = firstFrame;
		int frameRange = (int) videoProcessing.getFps() * 60;

		float totalPeopleNumber = 0;
		// For each minute we update the number of persons
		for (int i = 0; i < minutesSize; i++) {
			firstFrame = lastFrame;
			lastFrame = firstFrame + frameRange;

			if (lastFrame > videoProcessing.getLastFrame()) {
				lastFrame = videoProcessing.getLastFrame();
			}

			for (int j = 0; j < interestAreas.size(); j++) {
				peopleNumber.add((float) interestAreas.get(j).countPeople(videoProcessing, firstFrame, lastFrame)
						/ (lastFrame - firstFrame) * frameRange);
			}
			totalPeopleNumber += interestAreas.get(0).countPeople(videoProcessing, firstFrame, lastFrame);
			minutes.add(Integer.toString(i + 1));
		}
		float AverageperMinNB = (float) (totalPeopleNumber / minutesSize);
		Chart gNumberPMin = new Chart("Histogramme du Nombre de personnes par minute" + "\n"
				+ "Nombre de personne moyen par minute sur l'ensemble de la vidéo:" + Float.toString(AverageperMinNB),
				"temps en minute", "Nombre de Personne", peopleNumber, Color.white, this.getNameIZ(), minutes, true);
		this.addChartNbPpl(gNumberPMin);
	}

	/**
	 * Process the statistics by counting peoples in each interest area. This also
	 * sets a graphic of the number of people in each interest Area to be displayed
	 * later.
	 * 
	 * @param videoProcessing:Data
	 * @author Baptiste Wolff
	 * @author Terenui Rouby
	 */
	public void processStatsNumberPeopleIZ(VideoProcessingData videoProcessing) {

		int firstFrame = videoProcessing.getFirstFrame();
		int lastFrame = videoProcessing.getLastFrame();
		List<String> EmptyCat = new ArrayList<String>();

		List<Float> peopleNumberTotal = new ArrayList<Float>();
		for (int j = 0; j < interestAreas.size(); j++) {// initiate a range of Interest area that will contains 0 at the
														// beginning for each one of them
			peopleNumberTotal.add((float) 0);
		}

		for (int j = 0; j < interestAreas.size(); j++) {
			peopleNumberTotal.set(j, peopleNumberTotal.get(j)
					+ interestAreas.get(j).countPeople(videoProcessing, firstFrame, lastFrame));// Count the people for
																								// all the duration of
																								// the processingx/
		}

		EmptyCat.add("Zone d'interet");// There is only one kind of data we want to display
		Chart gNumberPIZ = new Chart("Histogramme du nombre de Personne par Zone d'interet", "Zone d'interet",
				"Nombre de Personne", peopleNumberTotal, Color.white, EmptyCat, this.getNameIZ(), true);
		this.addChartNbPpl(gNumberPIZ);
	}

	/**
	 * Process the statistics by counting the mean Time spent in each interest area.
	 * This also sets a graphic of the mean Time spent in each interest Area to be
	 * displayed later.
	 * 
	 * @param videoProcessing
	 * @author Rouby Terenui
	 */
	public void processStatsMeanTimeInInterestArea(VideoProcessingData videoProcessing) {
		List<String> EmptyCat = new ArrayList<String>();
		List<Float> meanTime = new ArrayList<Float>();

		for (int j = 0; j < interestAreas.size(); j++) {
			interestAreas.get(j).setPeopleNumber(videoProcessing);
			interestAreas.get(j).setMeanTime(videoProcessing);
			meanTime.add((float) (interestAreas.get(j).getMeanTime() / videoProcessing.getFps()));// Count the people
																									// for
			// all the duration of
			// the processing/
		}

		EmptyCat.add("Zone d'interet");// There is only one kind of data we want to display
		Chart gNumberPIZ = new Chart("Histogramme du Temps moyen passé par zone d'interet", "Zone d'interet",
				"Temps moyen en seconde", meanTime, Color.white, EmptyCat, this.getNameIZ(), true);
		this.addChartNbPpl(gNumberPIZ);
	}

	/**
	 * Process the statistics by counting peoples in each interest area. Doesn't
	 * create a chart to be displayed
	 * 
	 * @param videoProcessing:VideoProcessingData
	 * @author Baptiste Wolff
	 */
	public void updateInterestAreas(VideoProcessingData videoProcessing) {
		for (int i = 0; i < interestAreas.size(); i++) {
			interestAreas.get(i).setPeopleNumber(videoProcessing);
		}
	}
}
