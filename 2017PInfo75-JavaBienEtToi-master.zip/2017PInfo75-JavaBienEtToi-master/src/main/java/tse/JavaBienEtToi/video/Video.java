package tse.JavaBienEtToi.video;

import org.opencv.core.Mat;
import org.opencv.videoio.VideoCapture;

/**
 * Opens and decodes the frames of a video
 * 
 * @author Baptiste Wolff
 *
 */
public class Video {
	private VideoCapture cap;
	private Mat image = new Mat();
	private String videoName;

	/**
	 * Class constructor
	 * 
	 * @param videoName
	 *            path of the video + name of the file
	 */
	public Video(String videoName) {
		this.cap = new VideoCapture(videoName);
		this.videoName = videoName;
	}

	public boolean isOpened() {
		return cap.isOpened();
	}

	/**
	 * Returns the total number of frames of the video
	 * 
	 * @return The number of frames
	 */

	public int size() {
		return (int) cap.get(7);
	}

	/**
	 * Returns the frame rate of the video in frames per second
	 * 
	 * @return frames per second
	 */
	public double fps() {
		return cap.get(5);
	}

	/**
	 * Returns the current image position. Returns -1 if no frame had been decoded
	 * yet.
	 * 
	 * @return image number of the current frame
	 */
	public int nImg() {
		return (int) (cap.get(1) - 1);
	}

	/**
	 * returns the time of the video
	 * 
	 * @author Rouby Terenui
	 * 
	 * @return String with the time corresponding to the current frame
	 */
	public String time() {
		int duree = (((Double) (this.nImg() / this.fps())).intValue());
		Integer heures = (duree / 3600);
		Integer minutes = ((duree % 3600) / 60);
		Integer secondes = (((duree % 3600) % 60));
		String s = "";
		if (heures <= 9) {
			s = s + "0" + heures.toString() + ":";
		} else {
			s = s + heures.toString() + ":";
		}
		if (minutes <= 9) {
			s = s + "0" + minutes.toString() + ":";
		} else {
			s = s + minutes.toString() + ":";
		}
		if (secondes <= 9) {
			s = s + "0" + secondes.toString();
		} else {
			s = s + secondes.toString();
		}
		return (s);
	}

	/**
	 * Returns a Mat of any image of the video
	 * 
	 * @param nImg
	 *            Number of the image of the video
	 * @return Mat image
	 */
	public Mat getMat(int nImg) {
		cap.set(1, nImg);
		return getNextMat();
	}

	/**
	 * Returns a Mat of the next image of the video
	 * 
	 * @return Mat image
	 */
	public Mat getNextMat() {
		cap.read(image);
		return image;
	}

	public boolean hasNext() {
		return (cap.get(1) < cap.get(7));
	}

	public boolean hasPrev() {
		return (cap.get(1) > 0);
	}

	public Video clone() {
		return new Video(videoName);
	}

	public double getWidth() {
		return cap.get(3);
	}

	public double getHeight() {
		return cap.get(4);
	}
}
