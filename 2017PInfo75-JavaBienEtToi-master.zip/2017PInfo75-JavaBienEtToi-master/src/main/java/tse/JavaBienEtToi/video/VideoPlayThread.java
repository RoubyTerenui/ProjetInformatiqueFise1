package tse.JavaBienEtToi.video;

import tse.JavaBienEtToi.gui.GUI;

/**
 * Class running the thread to play the video into the GUI.
 * 
 * @author Baptiste Wolff
 *
 */
public class VideoPlayThread extends Thread {
	private Video video;

	private GUI gui;

	private boolean play = true;
	private double speed = 1;

	/**
	 * Class constructor
	 *
	 * @param video:Video
	 * @param gui:Gui
	 */
	public VideoPlayThread(Video video, GUI gui) {
		super();
		this.video = video;
		this.gui = gui;
	}

	/**
	 * Stops the video at the current image
	 */
	public void pause() {
		this.play = false;
	}

	/**
	 * Changes the speed rate of the frames to be displayed. By default the speed
	 * rate is 1. You can change the speed when a video is playing.
	 * 
	 * @param speed
	 */
	public void setSpeed(double speed) {
		this.speed = speed;
	}

	public boolean isPlaying() {
		return this.isAlive();
	}

	public void run() {
		long skipTicks = (long) ((1000 / video.fps()) / speed);
		long nextFrameTick = System.currentTimeMillis();
		while (video.hasNext() && play) {
			gui.displayNextImage();

			long tot = nextFrameTick + skipTicks;

			while (System.currentTimeMillis() < tot && play) {
			}

			nextFrameTick = System.currentTimeMillis();
			skipTicks = (long) ((1000 / video.fps()) / speed);
		}
	}
}
