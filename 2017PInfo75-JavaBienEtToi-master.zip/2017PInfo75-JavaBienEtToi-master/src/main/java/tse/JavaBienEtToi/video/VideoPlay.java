package tse.JavaBienEtToi.video;

import tse.JavaBienEtToi.gui.GUI;

/**
 * Class used to play a video into a GUI. Decodes and display the frames of a
 * video.
 * 
 * @author Baptiste Wolff
 *
 */
public class VideoPlay {
	private GUI gui;
	private Video video = new Video("");
	private VideoPlayThread playPauseThread;
	private boolean playing = false;
	private double speed = 1;

	/**
	 * Class construtor. The images of a video will be displayed on the GUI.
	 * 
	 * @param gui
	 */
	public VideoPlay(GUI gui) {
		this.gui = gui;
	}

	public boolean isPlaying() {
		return playing;
	}

	/**
	 * Changes the speed rate of the frames to be displayed. By default the speed
	 * rate is 1. You can change the speed when a video is playing.
	 * 
	 * @param speed
	 */
	public void setSpeed(double speed) {
		if (playing) {
			playPauseThread.setSpeed(speed);
		} else {
			this.speed = speed;
		}
	}

	/**
	 * Sets a new video. If a video is still playing, stops it before setting the
	 * new one.
	 * 
	 * @param video
	 */
	public void setVideo(Video video) {
		if (playing) {
			playPauseThread.pause();
			playing = false;
		}
		this.video = video;
	}

	/**
	 * Plays or pauses the video.
	 */
	public void toggle() {
		if (video.size() > 0) {
			if (playing) {
				playPauseThread.pause();
			} else {
				playPauseThread = new VideoPlayThread(video, gui);
				playPauseThread.setSpeed(this.speed);
				playPauseThread.start();
			}
			playing = !playing;
		}
	}

	/**
	 * Returns true if the last frame returned was the last frame of the video.
	 * 
	 * @return reachedEnd
	 */
	public boolean reachedEnd() {
		return (video.size() == video.nImg() + 1);
	}
}
