package tse.JavaBienEtToi.person;

/**
 * Contains all the persons detected on all the images of the video
 * 
 * @author Baptiste Wolff
 *
 */
public class PersonVideo {
	PersonList[] persons;

	/**
	 * Class constructor
	 * 
	 * @param videoSize
	 */
	public PersonVideo(int videoSize) {
		persons = new PersonList[videoSize];
	}

	/**
	 * Sets the persons of an image.
	 * 
	 * @param i
	 * @param persons
	 */
	public void set(int i, PersonList persons) {
		this.persons[i] = persons;
	}

	/**
	 * Gets the persons of an image.
	 * 
	 * @param i
	 * @return
	 */
	public PersonList get(int i) {
		if (i > persons.length - 1 || persons[i] == null) {
			return new PersonList();
		}
		return persons[i];
	}

	public int size() {
		return persons.length;
	}
}
