package tse.JavaBienEtToi.person;

import java.util.ArrayList;
import java.util.List;

import tse.JavaBienEtToi.person.Person;

/**
 * Class containing all the person on a single image.
 * 
 * @author Terenui Rouby
 * @author Baptiste Wolff
 * @author Corentin Renault
 */
public class PersonList {

	private List<Person> persons = new ArrayList<Person>();

	public PersonList(ArrayList<Person> persons) {
		this.persons.addAll(persons);
	}

	public PersonList() {
	}

	public PersonList(PersonList pl) {
		this.persons = pl.getPersonList();
	}

	public List<Person> getPersonList() {
		return persons;
	}

	public void setPersonList(List<Person> persons) {
		this.persons = persons;
	}

	public Person get(int i) {
		return persons.get(i);
	}

	public void set(int i, Person person) {
		persons.set(i, person);
	}

	public int size() {
		return persons.size();
	}

	public void add(PersonList personList) {
		List<Person> temp = new ArrayList<Person>();
		temp = personList.getPersonList();
		for (int i = 0; i < temp.size(); i++) {

			this.persons.add(temp.get(i));
		}
	}

	public void add(Person p) {
		persons.add(p);
	}

	public void clear() {
		this.persons.clear();
	}

}
