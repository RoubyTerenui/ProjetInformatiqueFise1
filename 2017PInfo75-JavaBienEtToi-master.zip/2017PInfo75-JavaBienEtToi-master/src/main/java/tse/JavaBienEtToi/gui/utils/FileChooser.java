package tse.JavaBienEtToi.gui.utils;

import javax.swing.*;
/**
 * Class used to open a File Chooser that will help you and the user to choose the location of the files
 * you want to use in your project
 *
 * @author RoubyTerenui
 */
public class FileChooser {
	/**
	 Open a fileChooser and get the path of the file selected in application
	 * @param parent:the parent of the fileChooser (used in order to pass the TeamLogo to the Filechooser)
	 * @return a string which correspond to the path of the selected files 
	 */
	public static String getpath(JFrame parent) 
	{
		String realPath = "";
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setAcceptAllFileFilterUsed(false);//Enleve le filtre par défaut
		fileChooser.addChoosableFileFilter(new VideoFilter());// Deinit le type de fichier accepter par le fileChooser voir VideoFilter pour
															  //Pour plus de détail
		if (fileChooser.showOpenDialog(parent) == JFileChooser.APPROVE_OPTION) {
			// Récupère le chemin absolu du fichier
			String path = fileChooser.getSelectedFile().getAbsolutePath();
			// String file = fileChooser.getSelectedFile().getName();
			// Pour ouvrir un fichier video, on remplace dans le chemin les '\' par des '\\'
			realPath = path.replaceAll("\\\\", "\\\\\\\\");
		}
		return (realPath);
	}
	/**
	 Same as the method getpath with the difference that it has different component to indicate that is is used to Save data
	 * @param parent:the parent of the fileChooser (used in order to pass the TeamLogo to the Filechooser)
	 * @return a string which correspond to the path of the selected repository where you want to save the data
	 */
	public static String pathS(JFrame parent) {
		String realPath = "";
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setDialogTitle("Save");
		fileChooser.setApproveButtonText("Save");
		if (fileChooser.showOpenDialog(parent) == JFileChooser.APPROVE_OPTION) {
			// Récupère le chemin absolu du fichier
			String path = fileChooser.getSelectedFile().getAbsolutePath();
			// String file = fileChooser.getSelectedFile().getName();
			// Pour ouvrir un fichier video, on remplace dans le chemin les '\' par des '\\'
			realPath = path.replaceAll("\\\\", "\\\\\\\\");
		}
		return (realPath);
	}
	/**
	 Same as the method getpath with the difference that it has no filter (used in the first method to restrict the files you want to load)
	 * @param parent:the parent of the fileChooser (used in order to pass the TeamLogo to the Filechooser)
	 * @return a string which correspond to the path of the selected files that you want to load
	 */
	public static String pathR(JFrame parent) {
		String realPath = "";
		JFileChooser fileChooser = new JFileChooser();
		// fileChooser.setAcceptAllFileFilterUsed(false);
		// fileChooser.addChoosableFileFilter(new VideoFilter());
		if (fileChooser.showOpenDialog(parent) == JFileChooser.APPROVE_OPTION) {
			// Récupère le chemin absolu du fichier
			String path = fileChooser.getSelectedFile().getAbsolutePath();
			// String file = fileChooser.getSelectedFile().getName();
			// Pour ouvrir un fichier video, on remplace dans le chemin les '\' par des '\\'
			realPath = path.replaceAll("\\\\", "\\\\\\\\");
		}
		return (realPath);
	}
}
