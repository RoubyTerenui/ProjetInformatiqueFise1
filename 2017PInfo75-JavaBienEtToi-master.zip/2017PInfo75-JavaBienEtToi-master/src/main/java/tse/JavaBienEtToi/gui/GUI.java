package tse.JavaBienEtToi.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.SwingConstants;
import javax.swing.SwingWorker;
import javax.swing.border.EtchedBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.opencv.core.Mat;

import tse.JavaBienEtToi.gui.utils.FileChooser;
import tse.JavaBienEtToi.gui.utils.ImagePanel;
import tse.JavaBienEtToi.gui.utils.Jlabelmouse;
import tse.JavaBienEtToi.gui.utils.StretchIcon;
import tse.JavaBienEtToi.gui.utils.slider.RangeSlider;
import tse.JavaBienEtToi.image.Image;
import tse.JavaBienEtToi.processing.Parameters;
import tse.JavaBienEtToi.processing.VideoProcessingData;
import tse.JavaBienEtToi.save.Load;
import tse.JavaBienEtToi.save.Save;
import tse.JavaBienEtToi.statistics.Statistic;
import tse.JavaBienEtToi.video.VideoPlay;
import tse.JavaBienEtToi.video.Video;

/**
 * The main window. Display the video and handles most user interactions.
 * 
 * @author RaphaelChevasson
 * @author Terenui Rouby
 * @author Baptiste Wolff
 */
public class GUI extends JFrame implements ActionListener, ChangeListener {

	// Booleans used to allow the access to UI elements
	/**
	 * determine the display of the developer mode
	 */
	private boolean displayDevMode = true;
	private boolean displayStat = false;
	/**
	 * determine the display of the buttons which use are useful only when the video
	 * is loaded
	 */
	private boolean isVideoLoaded = false;

	// Video
	private VideoPlay videoPlay;
	private Video video;

	// Statistics
	private Statistic stats = new Statistic();

	// Processing
	/**
	 * Processing parameters
	 */
	private Parameters param = new Parameters();
	/**
	 * Processing data. Can run the processing.
	 */
	private VideoProcessingData videoProcessing = new VideoProcessingData();
	/**
	 * Slider for choosing the frames to be processed
	 */
	private RangeSlider slider_processing;

	// UI elements
	private JFrame window = new JFrame();
	private JPanel mainPanel, toolsPanel, devPanel;
	private JPanel videoPanel;
	private JPanel videoNavSliderPanel;
	private JPanel videoNavButtonsPanel;
	private ImagePanel imagePanel;
	/**
	 * Detections tools buttons
	 */
	private JButton button_displayInterestZones, button_startDetection, button_createInterestZone,
			button_resetInterestZones;
	/**
	 * Navigation buttons
	 */
	private JButton button_nextFrame, button_previousFrame, button_pauseVideo, button_lastFrame, button_firstFrame;
	/**
	 * Stat and Dev buttons
	 */
	private JButton button_processStatisticsHistMin, button_processStatisticsNPZI, button_processStatisticsMeanTime,
			button_openDevModeWindow;
	private JLabel label_time;
	private JSlider slider_time;
	private Jlabelmouse displayedImageLabel = new Jlabelmouse(this);
	/**
	 * Save buttons
	 */
	private JButton button_saveImage, button_saveInterestZones, button_saveStatistics, button_generateReport;
	/**
	 * Load buttons
	 */
	private JButton button_loadInterestZones, button_loadVideo, button_loadExempleVideo, button_loadStatistics;

	// Definition of the different colors used for the Background of the Buttons.
	/**
	 * Define the different Colors used for the Background of the Buttons
	 */
	/**
	 * Button of the left panel and that can be used
	 */
	private Color c1 = Color.decode("#006699");
	/**
	 * Button of the navigation Panel
	 */
	private Color c2 = Color.decode("#FF6666");
	/**
	 * Button of the left panel and that cannot be used
	 */
	private Color c3 = Color.decode("#778899");
	/**
	 * Background of the left panel and of the waiting panel
	 */
	private Color c4 = Color.decode("#3399CC");

	/**
	 * Creates the GUI object and the main app window
	 */
	public GUI() {
		//// Video
		window.setIconImage(new ImageIcon("JavaBienEtToilogo.png").getImage());
		videoPlay = new VideoPlay(this);
		// see https://docs.oracle.com/javase/tutorial/uiswing/components/panel.html

		//// UI elements
		// main panel
		mainPanel = new JPanel(new BorderLayout());
		window.add(mainPanel);

		// tools panel
		JPanel leftPanel = new JPanel(new BorderLayout());
		mainPanel.add(leftPanel, BorderLayout.WEST);
		toolsPanel = new JPanel(new GridLayout(0, 1, 0, 1)); // (rox, col, HGap, VGap)
																// here, we layout vertically
		imagePanel = new ImagePanel();
		leftPanel.add(imagePanel, BorderLayout.NORTH);
		// verticalement
		leftPanel.add(toolsPanel, BorderLayout.CENTER);
		toolsPanel.add(addLabel("Charger", 20, 2));

		// Load
		button_loadVideo = addButton("Ouvrir une vidéo", toolsPanel, c1);
		button_loadExempleVideo = addButton("Utiliser la vidéo d'exemple", toolsPanel, c1);
		button_loadInterestZones = addButton("Charger des zones d'interêt", toolsPanel, c3);
		button_loadInterestZones.setEnabled(false);// disable while the video is not loaded
		button_loadStatistics = addButton("Charger des statistiques", toolsPanel, c3);
		button_loadStatistics.setEnabled(false);

		// Save
		toolsPanel.add(addLabel("Sauvegarder", 20, 2));
		button_saveImage = addButton("Sauvegarder l'image actuelle", toolsPanel, c3);
		button_saveImage.setEnabled(false);// disable while the video is not loaded
		button_saveInterestZones = addButton("Sauvegarder les zones d'intérêt", toolsPanel, c3);
		button_saveInterestZones.setEnabled(false);// disable while the video is not loaded
		button_saveStatistics = addButton("Sauvegarder les statistiques", toolsPanel, c3);
		button_saveStatistics.setEnabled(false);
		button_generateReport = addButton("Générer un rapport", toolsPanel, c3);
		button_generateReport.setEnabled(false);

		// Statistics processing
		toolsPanel.add(addLabel("CalculStatistique", 20, 2));
		button_processStatisticsHistMin = addButton("Nombres moyens de Personnes/min", toolsPanel, c3);
		button_processStatisticsHistMin.setEnabled(false);// disable while the video is not loaded
		button_processStatisticsMeanTime = addButton("Temps moyens/Zone(s)", toolsPanel, c3);
		button_processStatisticsMeanTime.setEnabled(false);// disable while the video is not loaded
		button_processStatisticsNPZI = addButton("Nombre de personnes/Zone(s)", toolsPanel, c3);
		button_processStatisticsNPZI.setEnabled(false);// disable while the video is not loaded
		toolsPanel.add(addLabel("Zone d'Interet", 20, 2));
		button_displayInterestZones = addButton("Afficher les zones d'intérêt", toolsPanel, c3);
		button_displayInterestZones.setEnabled(false);// disable while the video is not loaded
		button_createInterestZone = addButton("Nouvelle zone d'intérêt", toolsPanel, c3);
		button_createInterestZone.setEnabled(false);// disable while the video is not loaded
		// creerZoneInteret.setIcon(new ImageIcon("new.png"));//icone google design
		button_resetInterestZones = addButton("Supprimer les zones d'intérêt", toolsPanel, c3);
		button_resetInterestZones.setEnabled(false);// disable while the video is not loaded
		// resetZoneInteret.setIcon(new ImageIcon("del.png"));
		toolsPanel.add(addLabel("Detection", 20, 2));
		button_startDetection = addButton("Détection de personnes", toolsPanel, c3);
		button_startDetection.setEnabled(false);// disable while the video is not loaded

		// dev panel (below tools)
		if (displayDevMode) {
			devPanel = new JPanel(new GridLayout(0, 1, 0, 1)); // (rox, col, HGap, VGap) le tout sera ordonné //
																// verticalement
			leftPanel.add(devPanel, BorderLayout.SOUTH);
			devPanel.add(addLabel("Mode developpeur", 20, 2));
			button_openDevModeWindow = addButton("Regler la détection", devPanel, c1);
		} else {
			devPanel = new JPanel();
			button_openDevModeWindow = new JButton();
		}
		// color
		leftPanel.setBackground(Color.white);
		toolsPanel.setBackground(c4);
		devPanel.setBackground(c4);

		// video panel
		videoPanel = new JPanel(new BorderLayout());
		mainPanel.add(getVideoPanel(), BorderLayout.CENTER);
		videoPanel.add(displayedImageLabel, BorderLayout.CENTER);
		// videoPanel.setBackground(Color.decode("#BBF136"));
		// video navigation panel
		JPanel videoNavPanel = new JPanel(new GridLayout(0, 1)); // le tout sera ordonné verticalement
		getVideoPanel().add(videoNavPanel, BorderLayout.SOUTH);
		// buttons
		videoNavButtonsPanel = new JPanel();
		videoNavPanel.add(videoNavButtonsPanel);
		// Bouton de Navigation de la vidéo dont les boutons sont des images provenant
		// de google design
		button_firstFrame = addButton(videoNavButtonsPanel, c2);
		button_firstFrame.setIcon(new ImageIcon("reset.png"));
		button_previousFrame = addButton(videoNavButtonsPanel, c2);
		button_previousFrame.setIcon(new ImageIcon("fastrewind.png"));
		button_pauseVideo = addButton(videoNavButtonsPanel, c2);
		button_pauseVideo.setIcon(new ImageIcon("play.png"));
		button_nextFrame = addButton(videoNavButtonsPanel, c2);
		button_nextFrame.setIcon(new ImageIcon("fastforward.png"));
		button_lastFrame = addButton(videoNavButtonsPanel, c2);
		button_lastFrame.setIcon(new ImageIcon("lastframe.png"));
		label_time = new JLabel();
		videoNavButtonsPanel.add(label_time, BorderLayout.EAST);
		// time slider and processing slider
		videoNavSliderPanel = new JPanel(new BorderLayout());
		videoNavPanel.add(videoNavSliderPanel);
		int initialValue = 0;
		slider_time = new JSlider(JSlider.HORIZONTAL, 0, 50, initialValue);
		slider_processing = new RangeSlider(0, 50);
		videoNavSliderPanel.add(slider_time, BorderLayout.NORTH);
		videoNavSliderPanel.add(slider_processing, BorderLayout.CENTER);
		slider_time.addChangeListener(this);
		// slider_processing.addChangeListener(this);
		slider_time.setEnabled(false); // disables while video is not loaded
		slider_processing.setEnabled(false);
		videoNavSliderPanel.setVisible(false);// disables while video is not loaded
		videoNavButtonsPanel.setVisible(false);// disables while video is not loaded
		// // color
		// videoNavButtonsPanel.setBackground(Color.decode("#FF0000"));
		// timeSlider.setBackground(Color.decode("#FF0000"));

		// Window
		// We use Graphics Environment to adapt the window size to the display size.
		// get local graphics environment
		GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
		// get maximum window bounds
		Rectangle maximumWindowBounds = graphicsEnvironment.getMaximumWindowBounds();
		window.setTitle("Détection de personnes");
		window.setLocation(0, 0);// Set the location of the window on the left of the screen
		window.setSize((int) Math.round(maximumWindowBounds.getWidth() * 0.7),
				(int) Math.round(maximumWindowBounds.getHeight()));
		// fenetre.setLocationRelativeTo(null); // centrer la fenêtre
		// fenetre.setUndecorated(true); // masquer les contours et les boutons de
		// contrôle
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setVisible(true);
	}

	/**
	 * Adds and return a button with given text to the given JPanel. If button is
	 * already declared, you have to erase it with the return value - ex : b =
	 * addButton("foo", panel,Color.Blue).
	 * 
	 * @param text
	 *            text contained by the button
	 * @param parent
	 *            the JPanel containing the button
	 * @param c
	 *            the color you want for the background of the button
	 * @return the created button
	 */
	private JButton addButton(String text, JPanel parent, Color c) {
		JButton b = new JButton(text); // create button
		Font f = new Font(Font.DIALOG, Font.PLAIN, 15);
		b.setFont(f);
		b.setBackground(c);
		b.setForeground(Color.white);
		b.setBorder(BorderFactory.createRaisedBevelBorder());
		parent.add(b); // add it to the GUI parent object
		b.addActionListener(this); // listen to its events
		return (b);
	}

	/**
	 * Enable all the button that are disable while the video is not loaded if the
	 * video is loaded
	 */
	private void enable_videoLoaded() {
		isVideoLoaded = true;
		button_loadInterestZones.setEnabled(isVideoLoaded);
		button_loadStatistics.setEnabled(isVideoLoaded);
		button_saveImage.setEnabled(isVideoLoaded);
		button_saveInterestZones.setEnabled(isVideoLoaded);
		button_saveStatistics.setEnabled(isVideoLoaded);
		button_generateReport.setEnabled(isVideoLoaded);
		button_displayInterestZones.setEnabled(isVideoLoaded);
		button_createInterestZone.setEnabled(isVideoLoaded);
		button_resetInterestZones.setEnabled(isVideoLoaded);
		button_startDetection.setEnabled(isVideoLoaded);
		button_loadInterestZones.setBackground(c1);
		button_loadStatistics.setBackground(c1);
		button_saveImage.setBackground(c1);
		button_saveInterestZones.setBackground(c1);
		button_saveStatistics.setBackground(c1);
		button_generateReport.setBackground(c1);
		button_displayInterestZones.setBackground(c1);
		button_createInterestZone.setBackground(c1);
		button_resetInterestZones.setBackground(c1);
		button_startDetection.setBackground(c1);
		;
	}

	/**
	 * adds a button without text to the JPanel "parent" it will be used when the
	 * button will get a google design for example. If button is already declared,
	 * you have to erase it with the return value - ex : b = addButton(
	 * panel,Color.Blue).
	 *
	 * @param parent
	 * @param c
	 *            the color you want for the background of the button
	 * @return button
	 */
	private JButton addButton(JPanel parent, Color c) {
		JButton b = new JButton(); // create button
		b.setBackground(c);
		b.setBorder(BorderFactory.createEtchedBorder(EtchedBorder.RAISED));
		parent.add(b); // add it to the GUI parent object
		b.addActionListener(this); // listen to its events
		return (b);
	}

	/**
	 * when a button is clicked
	 */
	public void actionPerformed(ActionEvent e) {
		// tools :
		if (e.getSource().equals(button_loadVideo)) {
			String file = FileChooser.getpath(window);
			if (file != "") {
				button_processStatisticsHistMin.setBackground(c3);
				button_processStatisticsHistMin
						.setEnabled(false);/* To be sure that process Statistic is reset when a new video is loaded */
				button_processStatisticsMeanTime.setBackground(c3);
				button_processStatisticsMeanTime
						.setEnabled(false);/* To be sure that process Statistic is reset when a new video is loaded */
				button_processStatisticsNPZI.setBackground(c3);
				button_processStatisticsNPZI
						.setEnabled(false);/* To be sure that process Statistic is reset when a new video is loaded */
				videoProcessing = new VideoProcessingData();
				stats = new Statistic();
				loadVideo(file);
				label_time.setText(video.time());
				displayImage(0);
			}
		}
		if (e.getSource().equals(button_loadExempleVideo)) {
			button_processStatisticsHistMin.setBackground(c3);
			button_processStatisticsHistMin
					.setEnabled(false);/* To be sure that process Statistic is reset when a new video is loaded */
			button_processStatisticsMeanTime.setBackground(c3);
			button_processStatisticsMeanTime
					.setEnabled(false);/* To be sure that process Statistic is reset when a new video is loaded */
			button_processStatisticsNPZI.setBackground(c3);
			button_processStatisticsNPZI
					.setEnabled(false);/* To be sure that process Statistic is reset when a new video is loaded */
			loadVideo("test.avi");
		}

		if (e.getSource().equals(button_displayInterestZones)) {
			displayStat = !displayStat;
			displayImage(video.nImg());
		}
		if (e.getSource().equals(button_createInterestZone)) {
			pauseVideo();
			displayedImageLabel.activateClicking();
		}
		if (e.getSource().equals(button_resetInterestZones)) {
			displayedImageLabel.supressInterestArea();
			displayImage(video.nImg());
		}
		if (e.getSource().equals(button_openDevModeWindow)) {
			DevMode devMode = new DevMode(param);
			devMode.setVisible(true);
			devMode.setLocation(1000, 200);
		}
		// navigation :
		if (e.getSource().equals(button_pauseVideo)) {
			playPauseVideo();
		}
		if (e.getSource().equals(button_nextFrame)) {
			pauseVideo();
			if (video.hasNext()) {
				displayImage(video.getNextMat());
			}
		}
		if (e.getSource().equals(button_previousFrame)) {
			pauseVideo();
			if (video.hasPrev()) {
				displayImage(video.getMat(video.nImg() - 1));
			}
		}
		if (e.getSource().equals(button_processStatisticsMeanTime)) {
			stats.processStatsMeanTimeInInterestArea(getVideoProcessing());
			stats.showGraphique(stats.getListChartNbPpl().size() - 1);
		}
		if (e.getSource().equals(button_processStatisticsHistMin)) {
			stats.processStatsNumberPeoplMin(getVideoProcessing());
			stats.showGraphique(stats.getListChartNbPpl().size() - 1);
		}
		if (e.getSource().equals(button_processStatisticsNPZI)) {
			stats.processStatsNumberPeopleIZ(getVideoProcessing());
			stats.showGraphique(stats.getListChartNbPpl().size() - 1);
		}
		if (e.getSource().equals(button_firstFrame)) {
			pauseVideo();
			displayImage(video.getMat(0));
		}
		if (e.getSource().equals(button_lastFrame)) {
			pauseVideo();
			displayImage(video.getMat(video.size() - 1));
		}

		// Save
		if (e.getSource().equals(button_saveImage)) {
			pauseVideo();
			int frameNumber = video.nImg();
			Mat image = video.getMat(frameNumber);
			Image.drawTraitement(image, videoProcessing.getPersons().get(frameNumber));
			Image.drawStatistics(image, stats, frameNumber);
			BufferedImage bufferedImage = Image.Mat2bufferedImage(image);
			Save.image(bufferedImage, window);
		}
		if (e.getSource().equals(button_saveInterestZones)) {
			pauseVideo();
			Save.interestArea(stats.getInterestAreas(), window);
		}
		if (e.getSource().equals(button_saveStatistics)) {
			pauseVideo();
			// Cloning the stats
			Statistic statsTemp = new Statistic();
			statsTemp.setInterestAreas(stats.getInterestAreas());
			statsTemp.updateInterestAreas(getVideoProcessing());

			// Reprocessing the stats to ensure the save of the right ones
			statsTemp.processStatsMeanTimeInInterestArea(getVideoProcessing());
			statsTemp.processStatsNumberPeoplMin(getVideoProcessing());
			statsTemp.processStatsNumberPeopleIZ(getVideoProcessing());

			Save.statistics(statsTemp, window);
		}
		if (e.getSource().equals(button_generateReport)) {
			pauseVideo();
			// Cloning the stats
			Statistic statsTemp = new Statistic();
			statsTemp.setInterestAreas(stats.getInterestAreas());
			statsTemp.updateInterestAreas(getVideoProcessing());

			// Reprocessing the stats to ensure the save of the right ones
			statsTemp.processStatsMeanTimeInInterestArea(getVideoProcessing());
			statsTemp.processStatsNumberPeoplMin(getVideoProcessing());
			statsTemp.processStatsNumberPeopleIZ(getVideoProcessing());

			// Setting an image
			int frameNumber = video.nImg();
			Mat image = video.getMat(frameNumber);
			Image.drawTraitement(image, videoProcessing.getPersons().get(frameNumber));
			Image.drawStatistics(image, stats, frameNumber);
			BufferedImage bufferedImage = Image.Mat2bufferedImage(image);

			Save.report(statsTemp, bufferedImage, videoProcessing, window);
		}

		// Load
		if (e.getSource().equals(button_loadInterestZones)) {
			pauseVideo();
			stats.setInterestAreas(Load.interestsArea(window));
			displayStat = true;
			refreshImage();
		}

		if (e.getSource().equals(button_loadStatistics)) {
			stats.setInterestAreas(Load.statistics(window));
			displayStat = true;
			refreshImage();
		}

		// Detection
		if (e.getSource().equals(button_startDetection)) {
			button_startDetection.setEnabled(false);
			button_startDetection.setBackground(c3);/* To launch another Detection you must first stop the Detection */
			final JDialog loading = new JDialog(window);
			JPanel p1 = new JPanel(new BorderLayout());
			JLabel waiting = new JLabel("Veuillez patienter...");
			waiting.setHorizontalAlignment(SwingConstants.CENTER);
			waiting.setForeground(Color.white);
			Font f = new Font(Font.DIALOG, Font.PLAIN, 30);
			waiting.setFont(f);
			p1.add(waiting, BorderLayout.CENTER);
			loading.setUndecorated(true);
			p1.setBackground(c4);
			loading.getContentPane().add(p1);
			loading.pack();
			// Window
			// We use Graphics Environment to adapt the window size to the display size.
			// get local graphics environment
			GraphicsEnvironment graphicsEnvironment = GraphicsEnvironment.getLocalGraphicsEnvironment();
			// get maximum window bounds
			Rectangle maximumWindowBounds = graphicsEnvironment.getMaximumWindowBounds();
			loading.setSize((int) Math.round(maximumWindowBounds.getWidth() * 0.2),
					(int) Math.round(maximumWindowBounds.getHeight() * 0.2));
			loading.setLocationRelativeTo(window);
			loading.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
			loading.setModal(true);

			SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
				@Override
				protected Void doInBackground() {
					// Change the frames to be processed here
					getVideoProcessing().runProcessing(param, video, slider_processing.getValue(),
							slider_processing.getUpperValue());

					return null;
				}

				@Override
				protected void done() {
					loading.dispose();
					button_startDetection.setEnabled(true);
					button_startDetection.setBackground(c1);
					button_processStatisticsHistMin.setBackground(c1);
					button_processStatisticsHistMin
							.setEnabled(true);/* To be able to use the stat Button a Detection must be launched */
					button_processStatisticsNPZI.setBackground(c1);
					button_processStatisticsNPZI
							.setEnabled(true);/* To be able to use the stat Button a Detection must be launched */
					button_processStatisticsMeanTime.setBackground(c1);
					button_processStatisticsMeanTime
							.setEnabled(true);/* To be able to use the stat Button a Detection must be launched */

				}
			};
			worker.execute();
			loading.setVisible(true);
			/*
			 * try { worker.get(); } catch (Exception e1) { e1.printStackTrace(); }
			 */

			stats.updateInterestAreas(getVideoProcessing());
			refreshImage();
		}

	}

	public void stateChanged(ChangeEvent e) {
		if (!isNextFrameNumber(slider_time.getValue() + 1))
			pauseVideo();
		if (e.getSource().equals(slider_time) && !videoPlay.isPlaying()) {
			displayImage(video.getMat(slider_time.getValue()));
		}
	}

	private void loadVideo(String chemin) {
		video = new Video(chemin);
		videoPlay.setVideo(video);
		displayedImageLabel.supressInterestArea();
		if (!video.isOpened()) {
			System.out.println(
					"Echec de l'ouverture de la video.\nAvez-vous suivi toutes les instructions au-dessus du main ?");
			return;
		}

		displayImage(video.getMat(0));
		enable_videoLoaded();
		slider_time.setValue(0);
		slider_time.setMinimum(0);
		slider_time.setMaximum(video.size() - 1);
		slider_time.setEnabled(true);

		slider_processing.setValue(0);
		slider_processing.setMinimum(0);
		slider_processing.setMaximum(video.size() - 1);
		//slider_processing.setUpperValue(4000);
		slider_processing.setUpperValue(video.size() - 1);
		slider_processing.setEnabled(true);

		videoNavSliderPanel.setVisible(true);
		videoNavButtonsPanel.setVisible(true);
	}

	private void pauseVideo() {
		if (videoPlay.isPlaying()) {
			videoPlay.toggle();
			button_pauseVideo.setIcon(new ImageIcon("play.png"));
		}
	}

	/**
	 * Plays or pauses the video.
	 */
	private void playPauseVideo() {
		videoPlay.toggle();
		if (videoPlay.isPlaying()) {
			button_pauseVideo.setIcon(new ImageIcon("pause.png"));
		} else {
			button_pauseVideo.setIcon(new ImageIcon("play.png"));
		}
	}

	/**
	 * Displays an image into the GUI. Draws also the square representing the people
	 * detected or the interest areas
	 * 
	 * @param image
	 */
	private void displayImage(Mat image) {
		if (image.width() == 0) {
			return;
		}
		label_time.setFont(new Font(Font.DIALOG, Font.PLAIN, 25));
		label_time.setText(video.time());

		Image.drawTraitement(image, getVideoProcessing().getPersons().get(video.nImg()));

		if (displayStat) {
			Image.drawStatistics(image, stats, video.nImg());
		}

		BufferedImage bi = Image.Mat2bufferedImage(image);
		displayedImageLabel.setIcon(new StretchIcon(bi));
		// videoPanel.repaint();
		// window.validate();

		slider_time.setValue(video.nImg());
	}

	/**
	 * Returns true if n == (video's image number) + 1
	 * 
	 * @param n
	 * @return
	 */
	private boolean isNextFrameNumber(int n) {
		return (video.nImg() + 1 == n);
	}

	/**
	 * Displays the image number n in the GUI
	 * 
	 * @param n
	 */
	public void displayImage(int n) {
		displayImage(video.getMat(n));
	}

	/**
	 * Displays the next image of the video.
	 */
	public void displayNextImage() {
		displayImage(video.getNextMat());
	}

	/**
	 * Refresh the current displayed image.
	 */
	public void refreshImage() {
		displayImage(video.nImg());
	}

	public Video getVideo() {
		return video;
	}

	/**
	 * JDialog to confirm the creation of an interest area
	 */
	public void confirmchoice() {
		JDialog.setDefaultLookAndFeelDecorated(true);
		int response = JOptionPane.showConfirmDialog(null, "Voulez-vous créer cette zone d'interet?", "Confirmer",
				JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
		if (response == JOptionPane.YES_OPTION) {

		} else if (response == JOptionPane.CLOSED_OPTION || response == JOptionPane.NO_OPTION) {
			displayedImageLabel.destroylastIZ();
		}

	}

	// Statistics
	public Statistic getStat() {
		return stats;
	}

	public void setStat(Statistic stat) {
		this.stats = stat;
	}

	public void setDisplayStat(boolean displayStat) {
		this.displayStat = displayStat;
	}

	/**
	 * Fonction to add a Jlabel of given font, font size and font type
	 * 
	 * @param name
	 *            the text to displayed
	 * @param size
	 *            the font size
	 * @param type
	 *            the font type
	 * 
	 * @author Terenui Rouby
	 * @return Jlabel
	 */
	public JLabel addLabel(String name, int size, int type) {
		JLabel b = new JLabel(name, JLabel.CENTER);
		b.setFont(new Font(Font.DIALOG, type, size));
		return (b);
	}

	public JPanel getVideoPanel() {
		return videoPanel;
	}

	public VideoProcessingData getVideoProcessing() {
		return videoProcessing;
	}

}
