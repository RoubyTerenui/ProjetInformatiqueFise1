package tse.JavaBienEtToi.gui.utils;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

import javax.swing.JLabel;

import org.opencv.core.Point;

import tse.JavaBienEtToi.gui.GUI;
import tse.JavaBienEtToi.statistics.InterestArea;

/**
 * Class used to handle the action of clicking when the cursor is situated on the video Panel
 * 
 *
 * @author Rouby Terenui,
 * @author Wolff Baptiste
 */

public class Jlabelmouse extends JLabel implements MouseListener, MouseMotionListener {
	/** Boolean that will allow when activate to draw Interest areas on the video Panel */
	private boolean MouseListeneractivate = false;// champ ajouté pour pouvoir cliquer
	/** An Interest area that will be define by the action of the mouse */
	private InterestArea z1 = new InterestArea(null, null);
	/** The Gui where the video Panel is defined*/
	GUI gui;
	
	public Jlabelmouse(GUI gui) {
		super();
		this.addMouseListener(this);
		this.addMouseMotionListener(this);
		this.gui = gui;
	}

	// Suite de méthode pour pouvoir selectionner des points dans la vidéo
	/** Change the value of MouseListeneractivate to true */
	public void activateClicking() {
		MouseListeneractivate = true;
	}
	/** Change the value of MouseListeneractivate to false */
	public void desactivateClicking() {
		MouseListeneractivate = false;
	}

	public void mouseClicked(MouseEvent e) {

	}

	public void mouseEntered(MouseEvent e) {

	}

	public void mouseExited(MouseEvent e) {

	}
	/**
	 * Handle the event mousePressed that get the first Point of the rectangle used to define interest areas 
	 * @param e
	 */
	public void mousePressed(MouseEvent e) {
		if (MouseListeneractivate) {
			double x = (double) e.getX();
			double y = (double) e.getY();
			Point p1 = label2Point(x, y);
			z1 = new InterestArea(p1, p1);
			gui.getStat().addInterestarea(z1);
			gui.setDisplayStat(true);
		}
	}
	/**
	 * Handle the event mouseReleased that get the second Point of the rectangle used to define interest areas 
	 * and launch a window to confirm the selection
	 * @param e
	 */
	public void mouseReleased(MouseEvent e) {
		if (MouseListeneractivate) {
			double x = (double) e.getX();
			double y = (double) e.getY();
			Point p2 = label2Point(x, y);
			z1.setP2(p2);
			desactivateClicking();
			gui.confirmchoice();
			gui.getStat().updateInterestAreas(gui.getVideoProcessing());
			gui.refreshImage();
		}
	}
	/**
	 * Destroy the last interest area created
	 */
	public void destroylastIZ() {
		gui.getStat().removelastenter();
	}
	/**
	 * Method that create the first Interest area corresponding to the whole Video this Interest Area will not be displayed and supressed when clicking on the button
	 */
	private void addInitIZ() {
		Point bottom_right=label2Point(gui.getVideoPanel().getBounds().getX()+gui.getVideoPanel().getWidth(),gui.getVideoPanel().getBounds().getY()+gui.getVideoPanel().getHeight());
		Point top_left=new Point(0,0);
		InterestArea globalInterestArea=new InterestArea(top_left,bottom_right);
		gui.getStat().addInterestarea(globalInterestArea);
	}
	public void supressInterestArea() {// reset toutes les zones d'interet
		gui.getStat().setInterestAreas(new ArrayList<InterestArea>());
		addInitIZ();
	}
	/**
	 * Handle the event mouseDragged that will allow the user to follow the evolution of the interest area 
	 * @param e
	 */
	public void mouseDragged(MouseEvent e) {
		if (MouseListeneractivate) {
			double x = (double) e.getX();
			double y = (double) e.getY();
			Point p2 = label2Point(x, y);
			z1.setP2(p2);

			gui.refreshImage();
		}
	}

	public void mouseMoved(MouseEvent e) {

	}

	/**
	 * Returns a point with coordinates representing position in the original image.
	 * 
	 * @param x:the first coordinate of the point
	 * @param y:the second coordinate of the point
	 * @return Point(p.x / labelWidth, p.y / labelHeight)
	 */
	private Point label2Point(double x, double y) {//passage a public pour pouvoir être utilisé dans le GUI

		double width = gui.getVideo().getWidth();
		double height = gui.getVideo().getHeight();

		double xGap = 0;
		double yGap = 0;

		if (this.getHeight() / height > this.getWidth() / width) {
			yGap = this.getHeight() - this.getWidth() * height / width;
		} else {
			xGap = this.getWidth() - this.getHeight() * width / height;
		}

		x = width * (x - xGap / 2) / (this.getWidth() - xGap);
		y = height * (y - yGap / 2) / (this.getHeight() - yGap);

		if (x < 0) {
			x = 0;
		} else if (x > width) {
			x = width;
		}

		if (y < 0) {
			y = 0;
		} else if (y > height) {
			y = height;
		}

		return new Point(x, y);
	}
}
