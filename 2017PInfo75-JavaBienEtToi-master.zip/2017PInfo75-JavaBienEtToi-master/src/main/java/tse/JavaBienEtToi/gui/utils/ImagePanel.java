package tse.JavaBienEtToi.gui.utils;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;
/**
 * Class used to draw the logo of the school in a JPanel
 * 
 *
 * @author RoubyTerenui
 */
public class ImagePanel extends JPanel {
	 /** Buffer d'image pour stocker les images a dessiner dans le Jpanel	  */
    private BufferedImage img;

    public ImagePanel() {
        super();
        this.setMinimumSize(new Dimension(200, 190));
        this.setPreferredSize(new Dimension(200, 190));
        
        this.setBackground(Color.white);
        // chargement image
        try {
			this.img = ImageIO.read(new File("Logo_Telecom_Saint-Etienne.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
    /**
     * Method used to draw the rectangle and the logo inside
     */
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
         
        g.drawRect(0, 0, 238, 189);
        // affichage image
        g.drawImage(img, 0, 0, img.getWidth(), img.getHeight(), null);
    }
}
