package tse.JavaBienEtToi.image;

import java.awt.image.BufferedImage;
import java.util.List;

import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;

import tse.JavaBienEtToi.person.PersonList;
import tse.JavaBienEtToi.statistics.InterestArea;
import tse.JavaBienEtToi.statistics.Statistic;

/**
 * 
 * @author Baptiste Wolff
 *
 */
public class Image {
	/**
	 * Transforms any Mat into a BufferedImage
	 * 
	 * @param in:
	 *            Mat
	 * @return BufferedImage
	 */
	public static BufferedImage Mat2bufferedImage(Mat in) {
		int width = in.width();
		int height = in.height();
		BufferedImage out;
		Mat in2 = new Mat();
		Imgproc.cvtColor(in, in2, Imgproc.COLOR_RGB2BGR);
		byte[] data = new byte[width * height * (int) in2.elemSize()];
		int type;
		in2.get(0, 0, data);

		if (in2.channels() == 1)
			type = BufferedImage.TYPE_BYTE_GRAY;
		else
			type = BufferedImage.TYPE_3BYTE_BGR;

		out = new BufferedImage(width, height, type);

		out.getRaster().setDataElements(0, 0, width, height, data);
		return out;

	}

	/**
	 * Draws rectangles representing the peoples on a Mat
	 * 
	 * @param image
	 * @param personList
	 */
	public static void drawTraitement(Mat image, PersonList personList) {
		// PersonList persons = personList.getPersons();
		for (int i = 0; i < personList.size(); i++) {
			Imgproc.rectangle(image, new Point(personList.get(i).getX(), personList.get(i).getY()),
					new Point(personList.get(i).getX() + personList.get(i).getWidth(),
							personList.get(i).getY() + personList.get(i).getHeight()),
					new Scalar(0, 255, 0, 255), 2);
		}
	}

	/**
	 * Draws rectangles representing the interest areas and the statistics relative
	 * to it on a Mat
	 * 
	 * @param image
	 * @param statistic
	 * @param frameNumber
	 */
	public static void drawStatistics(Mat image, Statistic statistic, int frameNumber) {
		List<InterestArea> interestArea = statistic.getInterestAreas();
		for (int i = 1; i < interestArea.size(); i++) {
			Point p1 = interestArea.get(i).getP1();
			Point p2 = interestArea.get(i).getP2();
			Imgproc.rectangle(image, p1, p2, new Scalar(255, 0, 0, 255), 2);

			String name = statistic.getInterestAreas().get(i).getName();
			String personNumber = Integer.toString(statistic.getInterestAreas().get(i).getPeopleNumber(frameNumber));
			Point p3 = new Point(Math.min(p1.x, p2.x) + 3, Math.min(p1.y, p2.y) + 12);

			Imgproc.putText(image, name + " - " + personNumber, p3, 0, 0.5, new Scalar(0, 0, 0, 255), 2);
		}
	}
}
