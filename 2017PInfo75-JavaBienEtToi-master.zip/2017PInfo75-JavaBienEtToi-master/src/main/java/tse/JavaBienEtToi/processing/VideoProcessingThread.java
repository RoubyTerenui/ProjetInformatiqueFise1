package tse.JavaBienEtToi.processing;

import java.util.ArrayList;

import tse.JavaBienEtToi.person.PersonList;
import tse.JavaBienEtToi.video.Video;

/**
 * Class running the video processing on a thread.
 * 
 * @author Baptiste Wolff
 *
 */
public class VideoProcessingThread extends Thread {
	private Parameters param;
	private Video video;
	private int firstFrame;
	private int lastFrame;
	private VideoProcessing videoProcessing;

	/**
	 * Class constructor
	 * 
	 * @param param
	 * 			  The parameters of the videoProcessing
	 * @param video
	 *            The video being processed
	 * @param firstFrame
	 * @param lastFrame
	 */
	public VideoProcessingThread(Parameters param, Video video, int firstFrame, int lastFrame) {
		this.param = param;
		this.video = video;
		this.firstFrame = firstFrame;
		this.lastFrame = lastFrame;
	}

	public void run() {
		if (lastFrame - firstFrame - 2 < param.getStack()) {
			param = param.clone();
			param.setStack(lastFrame - firstFrame - 2);
			if (param.getStack() <= 0) {
				param.setStack(1);
			}
			
		}
		videoProcessing = new VideoProcessing(param, video.clone(), firstFrame, lastFrame);
	}

	public ArrayList<PersonList> getPersons() {
		return videoProcessing.getPersons();
	}

	public int getFirstFrame() {
		return firstFrame;
	}

	public int getLastFrame() {
		return lastFrame;
	}
}
