package tse.JavaBienEtToi.processing;

import org.opencv.video.Video;
import org.opencv.videoio.VideoCapture;

import tse.JavaBienEtToi.image.Image;

import org.opencv.core.Mat;
import org.opencv.core.Point;

import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import org.opencv.core.Core;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;

public class Flow {
	
	private Mat prev;
	private Mat flow;
	private boolean hasFlow = false;
	private double pyramidScale = 0.5;
	private int nLevels = 4;
	private int windowSize = 8;
	private int nIterations = 2;
	private int polyN = 7;
	private double polySigma = 1.5;
	private int runningFlags = Video.OPTFLOW_FARNEBACK_GAUSSIAN;

	public Flow() {
		flow = new Mat();
	}
	  
	public int width(){
		return flow.width();
	}
	  
	public int height(){
		return flow.height();
	}

	public boolean hasFlow(){
		return hasFlow;
	}
	
	public Mat getFlowMat(){
		return flow;
	}

	public void calculateOpticalFlow(Mat m) {
		int flags = runningFlags;
	    if (!hasFlow) {
	      prev = m.clone();
	      flags = Video.OPTFLOW_USE_INITIAL_FLOW;
	      hasFlow = true;
	    }
	    System.out.println(prev);
	    System.out.println(m);
	    Video.calcOpticalFlowFarneback(prev, m, flow, pyramidScale, nLevels, windowSize, nIterations, polyN, polySigma, flags);
	    prev = m.clone();
	}

	public Point getTotalFlowInRegion(int x, int y, int w, int h) {
		Mat region = flow.submat(y, y+h, x, x+w);
	    Scalar total = Core.sumElems(region);
	    return new Point((float)total.val[0], (float)total.val[1]);
	}

	public Point getAverageFlowInRegion(int x, int y, int w, int h) {
	    Point total = getTotalFlowInRegion(x, y, w, h);
	    return new Point(total.x/(w*h), total.y/(w*h));
	}

	public Point getTotalFlow() {
	    return getTotalFlowInRegion(0, 0, flow.width(), flow.height());
	}

	public Point getAverageFlow() {
	    return getAverageFlowInRegion(0, 0, flow.width(), flow.height());
	}
	  
	public Point getFlowAt(int x, int y){
	    return new Point((float)flow.get(y, x)[0], (float)flow.get(y, x)[1]);
	}
	
	public void setPyramidScale(double v){
		pyramidScale = v;
	}
	
	public double getPyramidScale(){
		return pyramidScale;
	}
	
	public void setLevels(int n){
		nLevels = n;
	}
	
	public int getLevels(){
		return nLevels;
	}
	
	public void setWindowSize(int s){
		windowSize = s;
	}
	
	public int getWindowSize(){
		return windowSize;
	}

	public void setIterations(int i){
		nIterations = i;
	}
	
	public int getIterations(){
		return nIterations;
	}
	
	public void setPolyN(int n){
		polyN = n;
	}
	
	public int getPolyN(){
		return polyN;
	}

	public void setPolySigma(double s){
		polySigma = s;
	}
	
	public double getPolySigma(){
		return polySigma;
	}
	
	public static void main(String[] args) {
		System.loadLibrary("opencv_java331");
		
		Flow flow = new Flow();

		Mat frame = new Mat();
		VideoCapture camera = new VideoCapture("test_2.mp4");
		System.out.println(camera.isOpened());
		JFrame jframe = new JFrame("Title");
		jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JLabel vidpanel = new JLabel();
		jframe.setContentPane(vidpanel);
		jframe.setVisible(true);

		while (true) {
			if (camera.read(frame)) {
				
				Mat mGray = new Mat();
				Imgproc.cvtColor(frame,mGray,Imgproc.COLOR_RGB2GRAY);

				flow.calculateOpticalFlow(mGray);
				Mat flowComplexMat = flow.getFlowMat();
				final int CV_8U = 24; // found here : http://ninghang.blogspot.fr/2012/11/list-of-mat-type-in-opencv.html
				List<Mat> flowsMats = new ArrayList<Mat>(3);
				Core.split(flowComplexMat, flowsMats);
				Mat flowRealPartMat = flowsMats.get(0);
				Mat flowImaginaryPartMat = flowsMats.get(1);
				System.out.println(flowRealPartMat);
				Mat f = new Mat();
				flowRealPartMat.convertTo(f, CV_8U);
				System.out.println(f);
				// autres pistes :
				// Mat f = new MatOfFloat(flowComplexMat);
				//cvtColor();

				ImageIcon image = new ImageIcon(Image.Mat2bufferedImage(f));
				vidpanel.setIcon(image);
				vidpanel.repaint();

			}
		}
		
	}
}