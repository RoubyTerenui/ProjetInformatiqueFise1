package tse.JavaBienEtToi.processing;

import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import tse.JavaBienEtToi.person.PersonList;
import tse.JavaBienEtToi.person.PersonVideo;
import tse.JavaBienEtToi.video.Video;

/**
 * Class containing the data of the video processing. This class can also run
 * the video processing.
 * 
 * @author Baptiste Wolff
 *
 */
public class VideoProcessingData {
	private PersonVideo persons;
	private int firstFrame = 0;
	private int lastFrame = 0;
	private double fps = 0;

	/**
	 * Class constructor.
	 */
	public VideoProcessingData() {
		this.persons = new PersonVideo(0);
	}

	/**
	 * Runs the threads for the processing.
	 * 
	 * @param video
	 * @param firstFrame
	 * @param lastFrame
	 */
	public void runProcessing(Parameters param, Video video, int firstFrame, int lastFrame) {
		this.firstFrame = firstFrame;
		this.lastFrame = lastFrame;
		this.fps = video.fps();

		long start = System.currentTimeMillis();

		ArrayList<PersonList> persons2 = new ArrayList<PersonList>();
		this.persons = new PersonVideo(video.size());

		// The number of threads is determined by the number of logical cores of the
		// CPU.
		int threadNumber = Runtime.getRuntime().availableProcessors();
		System.out.println("Thread number : " + threadNumber);

		// The work is divided between each thread.
		int frameNumber = firstFrame;
		float frameRange = (float) (lastFrame - firstFrame) / (float) threadNumber;
		int[] framesDistribution = new int[threadNumber + 1];

		for (int i = 0; i < threadNumber; i++) {
			framesDistribution[i] = frameNumber;
			frameNumber += frameRange;
			if (frameNumber > lastFrame) {
				frameNumber = lastFrame;
			}
		}
		if (frameNumber < lastFrame) {
			frameNumber = lastFrame;
		}
		if (frameNumber == 0) {
			frameNumber = 1;
		}
		framesDistribution[threadNumber] = frameNumber;

		// Runs the threads
		ExecutorService service = Executors.newFixedThreadPool(threadNumber);
		VideoProcessingThread[] processing = new VideoProcessingThread[threadNumber];

		for (int i = 0; i < threadNumber; i++) {
			processing[i] = new VideoProcessingThread(param, video, framesDistribution[i], framesDistribution[i + 1]);
			service.execute(processing[i]);
		}

		// Wait for processing to finish
		int timeNeeded = 2 * (lastFrame - firstFrame) / param.getN() + 60;
		// more or less 1 second to compute a picture (depends on the computation power
		// of the CPU). We add 60 second for safety.
		shutdownAndAwaitTermination(service, timeNeeded, TimeUnit.SECONDS);

		// Pair each calculated frame with its right frame.
		int stack = param.getStack();
		for (int i = 0; i < threadNumber; i++) {
			VideoProcessingThread process = processing[i];
			persons2 = process.getPersons();

			if (persons2.size() > 0) {
				for (int j = process.getFirstFrame(); j < process.getLastFrame(); j++) {
					int stackIndex = (int) Math.floor((j - process.getFirstFrame()) / stack);
					if (stackIndex > persons2.size() - 1) {
						stackIndex = persons2.size() - 1;
					}
					persons.set(j, persons2.get(stackIndex));
				}
			}
		}

		long last = System.currentTimeMillis();
		System.out.println("Total time elapsed : " + (last - start));
		System.out.println("Processing finished");
	}

	public PersonVideo getPersons() {
		return persons;
	}

	public int getFirstFrame() {
		return firstFrame;
	}

	public int getLastFrame() {
		return lastFrame;
	}

	/**
	 * Good practice: code imported from Oracle example
	 * 
	 * @param pool
	 * @param timeout
	 *            the maximum time to wait
	 * @param unit
	 *            the time unit of the timeout argument
	 */
	static void shutdownAndAwaitTermination(ExecutorService pool, long timeout, TimeUnit unit) {
		pool.shutdown(); // Disable new tasks from being submitted
		try {
			// Wait a while for existing tasks to terminate
			if (!pool.awaitTermination(timeout, unit)) {
				pool.shutdownNow(); // Cancel currently executing tasks
				// Wait a while for tasks to respond to being cancelled
				if (!pool.awaitTermination(60, TimeUnit.SECONDS))
					System.err.println("Pool did not terminate");
			}
		} catch (InterruptedException ie) {
			// (Re-)Cancel if current thread also interrupted
			pool.shutdownNow();
			// Preserve interrupt status
			Thread.currentThread().interrupt();
		}
	}

	public double getFps() {
		return fps;
	}
}
