package tse.JavaBienEtToi.processing;

import java.util.HashMap;
import java.util.Map;

import org.opencv.core.Size;
import org.opencv.objdetect.Objdetect;

/**
 * POJO which holds all tweakable parameters within the app.
 * 
 * @author RaphaelChevasson some parameters explanation by @author
 *         CorentinRenault
 */
public class Parameters {

	/**
	 * n -1 est le nombre de frames que l'on ne traite pas, soit n-1/n % de la video
	 */
	private int n;
	/** number of frames we use to replicate persons */
	private int stack;

	/** hMin is the minimum size of a person */
	private int hMin;
	/**
	 * parameter specifying how much the image size is reduced at each image scale.
	 */
	private double scaleFactor;
	/**
	 * minNeighbors is the number of points to match to confirm that the element we
	 * are looking at is one of the element we are looking for, in this case: a
	 * person
	 */
	private int minNeighbors;
	/**
	 * parameter with the same meaning for an old cascade as in the function
	 * cvHaarDetectObjects. It is not used for a new cascade
	 */
	private int flags;
	/** minSize is the minimum size of a person */
	private Size minSize;
	/** maxSize is the maximum size of a person */
	private Size maxSize;
	/** for each classifier name, tells if we are currently using it */
	private Map<String, Boolean> useClassifier;
	/** frequency at which we compute the detection */
	private double compPerSec;
	/** whether to use a mask to prevent detection on specific image areas */
	private boolean useMask;
	/** whether to display the mask on top of the video */
	private boolean displayMask;

	public Parameters() {
		n = 5;
		stack = 20;
		hMin = 5; // 20;
		scaleFactor = 1.05;
		minNeighbors = 4;
		flags = 0 | Objdetect.CASCADE_SCALE_IMAGE;
		minSize = new Size(hMin * 4 / scaleFactor, hMin * 4 / scaleFactor);
		maxSize = new Size(25 * hMin / 2, 25 * hMin);
		compPerSec = 2;
		useMask = true;
		displayMask = false;
		useClassifier = new HashMap<String, Boolean>();
		useClassifier.put("fullbody", true);
		useClassifier.put("upperbody", true);
		useClassifier.put("lowerbody", false);
		useClassifier.put("frontalface_default", true);

	}

	public int getN() {
		return n;
	}

	public void setN(int n) {
		this.n = n;
	}

	/**
	 * Class constructor used for cloning
	 * 
	 * @param stack
	 * @param hMin
	 * @param scaleFactor
	 * @param minNeighbors
	 * @param flags
	 * @param minSize
	 * @param maxSize
	 * @param useClassifier
	 * @param compPerSec
	 * @param useMask
	 * @param displayMask
	 */
	private Parameters(int n, int stack, int hMin, double scaleFactor, int minNeighbors, int flags, Size minSize,
			Size maxSize, Map<String, Boolean> useClassifier, double compPerSec, boolean useMask, boolean displayMask) {
		super();
		this.n = n;
		this.stack = stack;
		this.hMin = hMin;
		this.scaleFactor = scaleFactor;
		this.minNeighbors = minNeighbors;
		this.flags = flags;
		this.minSize = minSize;
		this.maxSize = maxSize;
		this.useClassifier = useClassifier;
		this.compPerSec = compPerSec;
		this.useMask = useMask;
		this.displayMask = displayMask;
	}

	public void useClassifier(String classifierName, boolean useClassifier) {
		this.useClassifier.put(classifierName, useClassifier);
	}

	public boolean isClassifierUsed(String classifierName) {
		return useClassifier.get(classifierName);
	}

	public double getCompPerSec() {
		return compPerSec;
	}

	public void setCompPerSec(double compPerSec) {
		this.compPerSec = compPerSec;
	}

	public boolean isDisplayMask() {
		return displayMask;
	}

	public void setDisplayMask(boolean displayMask) {
		this.displayMask = displayMask;
	}

	public void setHMin(int hMin) {
		this.hMin = hMin;
	}

	public int getHMin() {
		return hMin;
	}

	public double getScaleFactor() {
		return scaleFactor;
	}

	public void setScaleFactor(double scaleFactor) {
		this.scaleFactor = scaleFactor;
	}

	public int getMinNeighbors() {
		return minNeighbors;
	}

	public void setMinNeighbors(int minNeighbors) {
		this.minNeighbors = minNeighbors;
	}

	public int getFlags() {
		return flags;
	}

	public void setFlags(int flags) {
		this.flags = flags;
	}

	public Size getMinSize() {
		return minSize;
	}

	public void setMinSize(Size minSize) {
		this.minSize = minSize;
	}

	public Size getMaxSize() {
		return maxSize;
	}

	public void setMaxSize(Size maxSize) {
		this.maxSize = maxSize;
	}

	public boolean isUseMask() {
		return useMask;
	}

	public void setUseMask(boolean useMask) {
		this.useMask = useMask;
	}

	public int getStack() {
		return stack;
	}

	public void setStack(int stack) {
		this.stack = stack;
	}

	public Parameters clone() {
		return new Parameters(n, stack, hMin, scaleFactor, minNeighbors, flags, minSize, maxSize, useClassifier,
				compPerSec, useMask, displayMask);
	}
}
