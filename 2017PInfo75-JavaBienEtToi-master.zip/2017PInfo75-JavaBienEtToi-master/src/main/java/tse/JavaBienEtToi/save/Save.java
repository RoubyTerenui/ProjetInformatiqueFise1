package tse.JavaBienEtToi.save;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JFrame;

import org.jfree.chart.JFreeChart;

import tse.JavaBienEtToi.gui.utils.FileChooser;
import tse.JavaBienEtToi.processing.VideoProcessingData;
import tse.JavaBienEtToi.statistics.Chart;
import tse.JavaBienEtToi.statistics.InterestArea;
import tse.JavaBienEtToi.statistics.Statistic;

/**
 * Class managing all the saves
 * 
 * @author Baptiste Wolff
 *
 */
public class Save {
	/**
	 * Saves an image
	 * 
	 * @param image
	 * @param fileName
	 */
	public static void image(BufferedImage image, String fileName) {
		File fichier = new File(fileName + ".jpg");// or jpg

		try {
			ImageIO.write(image, "JPG", fichier); // or JPG
		} catch (IOException e) {
			System.out.println("Unable to save file");
			e.printStackTrace();
		}
	}

	/**
	 * Opens a dialog box and saves the image
	 * 
	 * @param image
	 */
	public static void image(BufferedImage image, JFrame parent) {
		String path = FileChooser.pathS(parent);
		if (path != "") {
			image(image, path);
		}
	}

	/**
	 * Opens a dialog box and saves interest areas
	 * 
	 * @param parent
	 * @param interestArea
	 */
	public static void interestArea(List<InterestArea> interestArea, JFrame parent) {
		String fileName = FileChooser.pathS(parent);
		if (fileName != "") {
			interestArea(fileName, interestArea);
		}
	}

	/**
	 * Saves the interest areas on a file
	 * 
	 * @param fileName
	 * @param interestArea
	 */
	public static void interestArea(String fileName, List<InterestArea> interestArea) {
		try {
			DataOutputStream out = new DataOutputStream(new FileOutputStream(fileName));
			for (int i = 0; i < interestArea.size(); i++) {
				InterestArea zoneInteret = interestArea.get(i);
				out.writeInt((int) zoneInteret.getP1().x);
				out.writeInt((int) zoneInteret.getP1().y);
				out.writeInt((int) zoneInteret.getP2().x);
				out.writeInt((int) zoneInteret.getP2().y);
			}
			// Always close files.
			out.close();

		} catch (IOException ex) {
			System.out.println("Error writing file '" + fileName + "'");
			// Or we could just do this:
			// ex.printStackTrace();
		}
	}

	/**
	 * Saves the last 3 graphs of stats
	 * 
	 * @param stats
	 *            Statistics with at least 3 graphs generated
	 * @param parent
	 */
	public static void statistics(Statistic stats, JFrame parent) {
		String fileName = FileChooser.pathS(parent);
		if (fileName != "") {
			try {
				DataOutputStream out = new DataOutputStream(new FileOutputStream(fileName));
				for (int j = 1; j < 4; j++) {
					Chart chart = stats.getListChartNbPpl().get(stats.getListChartNbPpl().size() - j);

					out.writeUTF(chart.getTitle());
					out.writeUTF(chart.getNorthing());
					out.writeUTF(chart.getEasting());

					List<Float> values = chart.getValues();
					out.writeInt(values.size());
					for (int i = 0; i < values.size(); i++) {
						out.writeFloat(values.get(i));
					}

					List<String> series = chart.getSeries();
					out.writeInt(series.size());
					for (int i = 0; i < series.size(); i++) {
						out.writeUTF(series.get(i));
					}

					List<String> type = chart.getType();
					out.writeInt(type.size());
					for (int i = 0; i < type.size(); i++) {
						out.writeUTF(type.get(i));
					}

					out.writeBoolean(chart.isLegend());

					Color background = chart.getBackground();
					out.writeInt(background.getRGB());
				}

				List<InterestArea> interestArea = stats.getInterestAreas();
				out.writeInt(interestArea.size());
				for (int i = 0; i < interestArea.size(); i++) {
					InterestArea zoneInteret = interestArea.get(i);
					out.writeInt((int) zoneInteret.getP1().x);
					out.writeInt((int) zoneInteret.getP1().y);
					out.writeInt((int) zoneInteret.getP2().x);
					out.writeInt((int) zoneInteret.getP2().y);
				}

				// Always close files.
				out.close();

			} catch (IOException ex) {
				System.out.println("Error writing file '" + fileName + "'");
				// Or we could just do this:
				// ex.printStackTrace();
			}
		}
	}

	/**
	 * Generates a report on the processing
	 * 
	 * @param stats
	 * @param videoScreenshot
	 * @param videoProcessingData
	 * @param parent
	 */
	public static void report(Statistic stats, BufferedImage videoScreenshot, VideoProcessingData videoProcessingData,
			JFrame parent) {
		String fileName = FileChooser.pathS(parent);
		if (fileName != "") {
			Save.image(videoScreenshot, fileName + "_videoScreenshot");
			for (int i = 1; i < 4; i++) {
				JFreeChart chart = stats.getListChartNbPpl().get(stats.getListChartNbPpl().size() - i).getJfreeChart();

				// Saves the images of the graphs
				int width = 1280;
				int height = 720;
				BufferedImage chartBufferedImage = draw(chart, width, height);
				Save.image(chartBufferedImage, fileName + "_chart" + i);
			}

			// Get only the name of the absolute path
			File f = new File(fileName);
			String name = f.getName();
			BufferedWriter out = null;
			try {
				out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(fileName + ".html"), "UTF-16"));
				out.write("<!DOCTYPE html>");
				out.write("<html>");
				out.write("<head>");
				out.write("<link rel=\"stylesheet\" href=\"" + name + ".css \" type=\"text/css\" media=\"all\" />");
				out.write("<title>Rapport statistique</title>");
				out.write("</head>");

				// Body
				out.write("<body>");

				// Head
				out.write("<div id=\"head\">");
				out.write("<h1>Rapport statistique : détection de personnes</h1>");
				out.write("</div>");

				// Main
				out.write("<div id=\"main\">");
				out.write("<div id=\"interestAreas\">");
				out.write("<h1>Zones d'intérêts :</h1></br>");
				out.write("<div id=\"screenshot\">");
				out.write("<img src='" + name + "_videoScreenshot" + ".jpg'" + " alt='chart1'>");
				out.write("</div>");
				out.write("</div>");

				out.write("<div id=\"processingPeriod\">");
				out.write("<h1>Période de Traitement :</h1></br>");
				out.write(" <p>De l'image n°" + videoProcessingData.getFirstFrame() + " à l'image n°"
						+ videoProcessingData.getLastFrame() + "</p>");

				NumberFormat nf = new DecimalFormat("0.##");

				out.write(" <p>De " + nf.format(videoProcessingData.getFirstFrame() / videoProcessingData.getFps())
						+ "s à " + nf.format(videoProcessingData.getLastFrame() / videoProcessingData.getFps())
						+ "s</p>");
				out.write("</div>");

				out.write("<div id=\"graphs\">");
				out.write("<h1>Histogrammes :</h1></br>");
				for (int i = (stats.getListChartNbPpl().size()) - 1; i >= 0; i--) {
					out.write("<div id=\"graphImage\">");
					out.write("<img src='" + name + "_chart" + (i + 1) + ".jpg'" + " alt='chart1'>");
					out.write("</div>");

				}
				out.write("</div>");
				out.write("</div>");
				out.write("</body></html>");
				out.close();

				// Finally the .css
				File source = new File("report.css");
				File dest = new File(fileName + ".css");
				Files.copy(source.toPath(), dest.toPath());
			} catch (IOException ex) {
				System.out.println("Error writing file '" + fileName + "'");
				// ex.printStackTrace();
			} finally {
				if (out != null)
					try {
						out.close();
					} catch (IOException logOrIgnore) {
					}
			}
		}

	}

	private static BufferedImage draw(JFreeChart chart, int width, int height) {
		BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
		Graphics2D g2 = img.createGraphics();
		chart.draw(g2, new Rectangle2D.Double(0, 0, width, height));
		g2.dispose();
		return img;
	}
}
