package tse.JavaBienEtToi.save;

import java.awt.Color;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JFrame;

import org.opencv.core.Point;

import tse.JavaBienEtToi.gui.utils.FileChooser;
import tse.JavaBienEtToi.statistics.Chart;
import tse.JavaBienEtToi.statistics.InterestArea;
import tse.JavaBienEtToi.statistics.Statistic;

/**
 * Class used for loading the parameters previously saved
 * 
 * @author Baptiste Wolff
 *
 */
public class Load {
	/**
	 * Reads the interest area file
	 * 
	 * @param parent
	 * @return zoneInteret:List of InterestArea
	 */
	public static List<InterestArea> interestsArea(JFrame parent) {
		String fileName = FileChooser.pathR(parent);
		return interestsarea(fileName);
	}

	public static List<InterestArea> interestsarea(String fileName) {
		List<InterestArea> interestArea = new ArrayList<InterestArea>();
		try {
			FileInputStream fin = new FileInputStream(fileName);
			BufferedInputStream bin = new BufferedInputStream(fin);
			DataInputStream in = new DataInputStream(bin);

			while (in.available() > 3) {
				for (int i = 0; i < 4; i++) {
					Point p1 = new Point(in.readInt(), in.readInt());
					Point p2 = new Point(in.readInt(), in.readInt());
					interestArea.add(new InterestArea(p1, p2));
				}
			}

			in.close();
		} catch (FileNotFoundException ex) {
			System.out.println("Unable to open file '" + fileName + "'");
		} catch (IOException ex) {
			System.out.println("Error reading file '" + fileName + "'");
			// Or we could just do this:
			// ex.printStackTrace();
		}
		return interestArea;
	}

	/**
	 * Loads 3 graphs and display them
	 * 
	 * @param parent
	 * @return List of InterestArea
	 */
	public static List<InterestArea> statistics(JFrame parent) {
		String fileName = FileChooser.pathR(parent);
		List<InterestArea> interestArea = new ArrayList<InterestArea>();
		if (fileName != "") {
			try {
				FileInputStream fin = new FileInputStream(fileName);
				BufferedInputStream bin = new BufferedInputStream(fin);
				DataInputStream in = new DataInputStream(bin);

				Statistic stats = new Statistic();

				for (int j = 0; j < 3; j++) {
					String title = in.readUTF();
					String northing = in.readUTF();
					String easting = in.readUTF();

					List<Float> values = new ArrayList<Float>();
					int valuesSize = in.readInt();
					for (int i = 0; i < valuesSize; i++) {
						values.add(in.readFloat());
					}

					List<String> series = new ArrayList<String>();
					int seriesSize = in.readInt();
					for (int i = 0; i < seriesSize; i++) {
						series.add(in.readUTF());
					}

					List<String> type = new ArrayList<String>();
					int typeSize = in.readInt();
					for (int i = 0; i < typeSize; i++) {
						type.add(in.readUTF());
					}

					boolean legend = in.readBoolean();
					Color background = new Color(in.readInt());

					Chart chart = new Chart(title, easting, northing, values, background, series, type, legend);

					stats.addChartNbPpl(chart);
					stats.showGraphique(j);
				}

				int interestAreaSize = in.readInt();
				for (int i = 0; i < interestAreaSize; i++) {
					Point p1 = new Point(in.readInt(), in.readInt());
					Point p2 = new Point(in.readInt(), in.readInt());
					interestArea.add(new InterestArea(p1, p2));
				}

				in.close();
			} catch (FileNotFoundException ex) {
				System.out.println("Unable to open file '" + fileName + "'");
			} catch (IOException ex) {
				System.out.println("Error reading file '" + fileName + "'");
				// Or we could just do this:
				// ex.printStackTrace();
			}
		}
		return interestArea;
	}
}
